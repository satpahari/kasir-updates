<script>
    function showToast(message, type = 'success') {
        let container = document.getElementById('toast-container');
        
        if (container) {
            container.style.zIndex = '999999';
        } else {
            container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'fixed top-4 right-4 flex flex-col gap-2 pointer-events-none';
            container.style.zIndex = '999999';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        const bgColor = type === 'success' ? 'bg-white border-green-500 text-gray-800' : 'bg-white border-red-500 text-gray-800';
        const iconColor = type === 'success' ? 'text-green-500 bg-green-50' : 'text-red-500 bg-red-50';
        const icon = type === 'success' ? 'fa-check' : 'fa-exclamation';
        
        toast.className = `flex items-center p-4 mb-3 border-l-4 rounded-r-xl shadow-[0_20px_60px_-10px_rgba(0,0,0,0.4)] transform transition-transform duration-300 translate-x-full ${bgColor} min-w-[300px] border-y border-r border-gray-100 pointer-events-auto transform-gpu`;
        
        toast.innerHTML = `
            <div class="w-8 h-8 rounded-full ${iconColor} flex items-center justify-center shrink-0 mr-3 shadow-inner">
                <i class="fa-solid ${icon} text-sm"></i>
            </div>
            <span class="font-bold text-sm tracking-wide">${message}</span>
        `;
        container.appendChild(toast);
        
        // Animasi masuk yang lebih mulus dengan RequestAnimationFrame
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                toast.classList.remove('translate-x-full');
            });
        });

        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        
        if (window.innerWidth < 768) {
            sidebar.classList.toggle('-translate-x-full');
            overlay.classList.toggle('hidden');
        } else {
            sidebar.classList.toggle('md:-ml-72');
        }
    }

    function toggleNotif() {
        const dropdown = document.getElementById('notif-dropdown');
        dropdown.classList.toggle('hidden');
    }

    window.addEventListener('click', function(e) {
        const dropdown = document.getElementById('notif-dropdown');
        if (dropdown && !dropdown.contains(e.target) && !e.target.closest('button[onclick="toggleNotif()"]')) {
            if (!dropdown.classList.contains('hidden')) {
                dropdown.classList.add('hidden');
            }
        }
    });

    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('date-display').textContent = new Date().toLocaleDateString('id-ID', options);

    const tabTitles = {
        'dashboard': 'Dashboard Point of Sales',
        'transaksi': 'Transaksi Kasir',
        'barang': 'Manajemen Data Barang',
        'rekap': 'Laporan Penjualan',
        'pengeluaran': 'Laporan Pengeluaran Toko',
        'akun': 'Manajemen Akun Pengguna', 
        'database': 'Sistem Database (Backup/Restore)'
    };

    // FUNGSI BARU: Menutup semua jendela Pop-Up/Modal secara otomatis
    function tutupSemuaModal() {
        const daftarModal = [
            'modal-barang', 'modal-checkout', 'modal-detail-trx', 'modal-gdrive', 
            'modal-akun', 'modal-konfirmasi', 'modal-upload-csv', 'modal-sync', 
            'modal-pengeluaran'
        ];
        daftarModal.forEach(id => {
            const el = document.getElementById(id);
            if (el && !el.classList.contains('hidden')) {
                el.classList.add('hidden');
            }
        });
    }

    function switchTab(tabId, isLoad = false) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('bg-gray-800', 'text-white', 'border-gray-500', 'bg-brand-500/10', 'text-brand-400', 'border-brand-500');
            btn.classList.add('text-slate-400', 'border-transparent', 'hover:bg-slate-800', 'hover:text-slate-200');
            if(btn.dataset.target === tabId) {
                btn.classList.add('bg-gray-800', 'text-white', 'border-gray-500');
                btn.classList.remove('text-slate-400', 'border-transparent', 'hover:bg-slate-800', 'hover:text-slate-200');
            }
        });

        if (window.innerWidth < 768) {
            const sidebar = document.getElementById('sidebar');
            if (!sidebar.classList.contains('-translate-x-full')) {
                toggleSidebar();
            }
        }

        if (!isLoad) {
            const currentActive = document.querySelector('.tab-content:not(.hidden)');
            if (currentActive) {
                currentActive.style.opacity = '0';
            }

            // 1. TUTUP SEMUA MODAL YANG TERBUKA (Mencegah jejak form menumpuk)
            tutupSemuaModal();

            // 2. RESET TOTAL STATE KASIR (TRANSAKSI)
            clearCart();
            const searchKasir = document.getElementById('search-barang-kasir');
            if (searchKasir) { 
                searchKasir.value = ''; 
                if (typeof fetchProductsAPI === 'function') {
                    fetchProductsAPI(''); 
                }
            }
            if (typeof activeTrxForReprint !== 'undefined') {
                activeTrxForReprint = null;
            }

            // 3. REFRESH DOM SEMUA MENU DATA (Mereset Kolom Cari, Filter Tanggal, dll ke default)
            const menuPerluRefresh = ['barang', 'rekap', 'pengeluaran', 'akun', 'database'];
            if (menuPerluRefresh.includes(tabId)) {
                const targetView = document.getElementById('view-' + tabId);
                if (targetView) {
                    targetView.classList.add('opacity-50', 'pointer-events-none');
                    
                    fetch('?tab=' + tabId)
                        .then(response => response.text())
                        .then(html => {
                            const parser = new DOMParser();
                            const doc = parser.parseFromString(html, 'text/html');
                            const newContent = doc.getElementById('view-' + tabId);
                            if (newContent) {
                                targetView.innerHTML = newContent.innerHTML;
                            }
                        })
                        .catch(err => console.error("Gagal membersihkan jejak form:", err))
                        .finally(() => {
                            targetView.classList.remove('opacity-50', 'pointer-events-none');
                        });
                }
            }

            // 4. BERSIHKAN SEMUA URL PARAMETER TERSEMBUNYI
            const url = new URL(window.location);
            url.searchParams.delete('cari_brg');
            url.searchParams.delete('page_barang');
            url.searchParams.delete('tgl_awal');
            url.searchParams.delete('tgl_akhir');
            url.searchParams.delete('page_rekap');
            url.searchParams.delete('tgl_awal_pengeluaran');
            url.searchParams.delete('tgl_akhir_pengeluaran');
            url.searchParams.delete('page_pengeluaran');

            url.searchParams.set('tab', tabId);
            window.history.pushState({ tab: tabId }, '', url);

            setTimeout(() => {
                tampilkanTab(tabId);
            }, 150);
            return;
        }

        tampilkanTab(tabId);
    }

    function tampilkanTab(tabId) {
        document.querySelectorAll('.tab-content').forEach(el => {
            el.classList.add('hidden');
            el.style.opacity = ''; 
            el.classList.remove('animate-fade-in-up');
        });
        
        const activeContent = document.getElementById('view-' + tabId);
        if (activeContent) {
            activeContent.classList.remove('hidden');
            void activeContent.offsetWidth; 
            activeContent.classList.add('animate-fade-in-up');
        }

        document.getElementById('header-title').textContent = tabTitles[tabId] || 'Sistem Update Point of Sales';

        if (tabId === 'transaksi') {
            setTimeout(() => {
                const searchInput = document.getElementById('search-barang-kasir');
                if (searchInput) searchInput.focus();
            }, 100); 
        }
    }
    
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    if(tabParam) {
        switchTab(tabParam, true);
    } else {
        switchTab('dashboard', true);
    }

    window.addEventListener('popstate', () => {
        const params = new URLSearchParams(window.location.search);
        const tab = params.get('tab') || 'dashboard';
        tampilkanTab(tab);
    });

    // FUNGSI MELOMPAT KE DATA BARANG (DARI TOMBOL PENSIL STOK HABIS)
    function editStokLangsung(kodeBarang) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('bg-gray-800', 'text-white', 'border-gray-500', 'bg-brand-500/10', 'text-brand-400', 'border-brand-500');
            btn.classList.add('text-slate-400', 'border-transparent', 'hover:bg-slate-800', 'hover:text-slate-200');
            if(btn.dataset.target === 'barang') {
                btn.classList.add('bg-gray-800', 'text-white', 'border-gray-500');
                btn.classList.remove('text-slate-400', 'border-transparent', 'hover:bg-slate-800', 'hover:text-slate-200');
            }
        });

        if (window.innerWidth < 768) {
            const sidebar = document.getElementById('sidebar');
            if (!sidebar.classList.contains('-translate-x-full')) {
                toggleSidebar();
            }
        }

        const currentActive = document.querySelector('.tab-content:not(.hidden)');
        if (currentActive) {
            currentActive.style.opacity = '0';
        }

        const targetView = document.getElementById('view-barang');
        if (targetView) {
            targetView.classList.add('opacity-50', 'pointer-events-none');
            
            fetch(`?tab=barang&cari_brg=${encodeURIComponent(kodeBarang)}`)
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newContent = doc.getElementById('view-barang');
                    if (newContent) {
                        targetView.innerHTML = newContent.innerHTML;
                    }
                })
                .catch(err => console.error("Gagal meload form barang:", err))
                .finally(() => {
                    targetView.classList.remove('opacity-50', 'pointer-events-none');
                });
        }

        const url = new URL(window.location);
        url.searchParams.delete('page_barang');
        url.searchParams.set('tab', 'barang');
        url.searchParams.set('cari_brg', kodeBarang);
        window.history.pushState({ tab: 'barang' }, '', url);

        setTimeout(() => {
            tampilkanTab('barang');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }, 150);
    }

    const pesanNotif = urlParams.get('pesan');
    if (pesanNotif) {
        setTimeout(() => {
            if (pesanNotif === 'kode_duplikat') { showToast("Gagal! Kode Barang tersebut sudah terdaftar.", "error"); } 
            else if (pesanNotif === 'sukses_tambah') { showToast("Barang baru berhasil ditambahkan.", "success"); } 
            else if (pesanNotif === 'sukses_edit') { showToast("Data barang berhasil diperbarui.", "success"); } 
            else if (pesanNotif === 'sukses_hapus') { showToast("Data barang berhasil dihapus.", "success"); }
            else if (pesanNotif === 'sukses_import') { showToast("Data barang berhasil di-import dari CSV.", "success"); }
            else if (pesanNotif === 'error_import_ekstensi') { showToast("Gagal! Format file harus .csv", "error"); }
            else if (pesanNotif === 'error_import_kosong') { showToast("Gagal! File CSV kosong atau rusak.", "error"); }
            else if (pesanNotif === 'sukses_restore') { showToast("Sistem Berhasil Dipulihkan dari Backup!", "success"); }
            else if (pesanNotif === 'error_format') { showToast("Gagal! Format file harus .sql", "error"); }
            else if (pesanNotif === 'error_kosong') { showToast("Gagal! File sql yang diunggah kosong.", "error"); }
            else if (pesanNotif === 'error_restore') { showToast("Terjadi kesalahan pada saat memulihkan database.", "error"); }
            else if (pesanNotif === 'sukses_tambah_akun') { showToast("Akun pengguna baru berhasil dibuat.", "success"); }
            else if (pesanNotif === 'sukses_edit_akun') { showToast("Data akun berhasil diperbarui.", "success"); }
            else if (pesanNotif === 'sukses_hapus_akun') { showToast("Akun pengguna berhasil dihapus.", "success"); }
            else if (pesanNotif === 'username_duplikat') { showToast("Gagal! Username tersebut sudah digunakan.", "error"); }
            else if (pesanNotif === 'error_hapus_sendiri') { showToast("Gagal! Anda tidak bisa menghapus akun Anda sendiri.", "error"); }
            else if (pesanNotif === 'error_hapus_terpakai') { 
                showToast("Ditolak! Barang sudah masuk riwayat transaksi. Cukup jadikan stok 0 jika tak dijual lagi.", "error"); 
            }
            else if (pesanNotif === 'hapus_sukses') { 
                showToast("Transaksi dihapus! Pendapatan & Stok Barang telah berhasil dipulihkan.", "success"); 
            }
            else if (pesanNotif === 'sukses_tambah_pengeluaran') { 
                showToast("Pengeluaran berhasil dicatat!", "success"); 
            }
            else if (pesanNotif === 'sukses_hapus_pengeluaran') { 
                showToast("Catatan pengeluaran dibatalkan!", "success"); 
            }
        }, 300);

        const urlBaru = new URL(window.location);
        urlBaru.searchParams.delete('pesan');
        window.history.replaceState({}, document.title, urlBaru);
    }

    function hitungOtomatisEceran() {
        const stokGrosir = parseInt(document.getElementById('form-stok').value) || 0;
        const konversi = parseInt(document.getElementById('form-konversi').value) || 1;
        const inputEceran = document.getElementById('form-stok-eceran');
        
        inputEceran.value = stokGrosir * konversi;
    }

    function validasiFormBarang(form) {
        const hargaGrosirStr = document.getElementById('form-harga').value.replace(/\./g, '');
        const isEceran = document.getElementById('toggle-eceran').checked;
        const hargaEceranStr = document.getElementById('form-harga-eceran') ? document.getElementById('form-harga-eceran').value.replace(/\./g, '') : '';

        const hargaGrosir = parseInt(hargaGrosirStr) || 0;
        const hargaEceran = parseInt(hargaEceranStr) || 0;

        if (hargaGrosir <= 0 && (!isEceran || hargaEceran <= 0)) {
            showToast("Gagal! Anda harus mengisi minimal Harga Grosir atau Harga Eceran.", "error");
            return false;
        }

        document.getElementById('form-harga').value = hargaGrosir;
        if (isEceran && document.getElementById('form-harga-eceran')) {
            document.getElementById('form-harga-eceran').value = hargaEceran;
        }

        return true;
    }

    function bukaModalBarang(aksi, data = null) {
        document.getElementById('modal-barang').classList.remove('hidden');
        document.getElementById('form-aksi').value = aksi;
        
        const toggleEceran = document.getElementById('toggle-eceran');
        const containerEceran = document.getElementById('container-eceran');
        const inputHargaEcer = document.getElementById('form-harga-eceran');
        const inputKonversi = document.getElementById('form-konversi');
        const inputStokEcer = document.getElementById('form-stok-eceran');

        const inputKategori = document.getElementById('form-kategori');
        const textKategori = document.getElementById('kategori-text');
        const triggerKategori = document.getElementById('kategori-trigger');

        tutupDropdownKategori();

        if (aksi === 'edit' && data) {
            document.getElementById('modal-title').textContent = 'EDIT DATA BARANG';
            document.getElementById('form-id').value = data.id;
            document.getElementById('form-kode').value = data.kode.toUpperCase();
            document.getElementById('form-nama').value = data.nama_barang.toUpperCase();
            document.getElementById('form-stok').value = data.stok;
            
            const hargaDb = parseInt(data.harga) || 0;
            document.getElementById('form-harga').value = hargaDb > 0 ? hargaDb.toLocaleString('id-ID') : '';
            
            document.getElementById('form-min-qty-diskon').value = data.min_qty_diskon || 0;
            const hargaDiskonDb = parseInt(data.harga_diskon) || 0;
            document.getElementById('form-harga-diskon').value = hargaDiskonDb > 0 ? hargaDiskonDb.toLocaleString('id-ID') : '';

            inputKategori.value = data.kategori || '';
            textKategori.textContent = data.kategori || 'Pilih Kategori Barang';
            if (data.kategori) {
                triggerKategori.classList.remove('text-gray-400');
                triggerKategori.classList.add('text-gray-800', 'bg-white');
            } else {
                triggerKategori.classList.add('text-gray-400');
                triggerKategori.classList.remove('text-gray-800');
            }
            
            const hargaEcer = parseInt(data.harga_eceran) || 0;
            if(hargaEcer > 0) {
                toggleEceran.checked = true;
                containerEceran.classList.remove('hidden');
                inputHargaEcer.value = hargaEcer.toLocaleString('id-ID');
                
                inputKonversi.value = data.konversi || 1;
                inputStokEcer.value = data.stok_eceran || (data.stok * (data.konversi || 1));
            } else {
                toggleEceran.checked = false;
                containerEceran.classList.add('hidden');
                inputHargaEcer.value = '';
                inputKonversi.value = 1;
                inputStokEcer.value = 0;
            }
        } else {
            document.getElementById('modal-title').textContent = 'TAMBAH BARANG BARU';
            document.getElementById('form-id').value = '';
            document.getElementById('form-kode').value = '';
            document.getElementById('form-nama').value = '';
            document.getElementById('form-stok').value = '0';
            document.getElementById('form-harga').value = '';
            
            document.getElementById('form-min-qty-diskon').value = '0';
            document.getElementById('form-harga-diskon').value = '';
            
            inputKategori.value = '';
            textKategori.textContent = 'Pilih Kategori Barang';
            triggerKategori.classList.add('text-gray-400');
            triggerKategori.classList.remove('text-gray-800', 'bg-white');
            
            toggleEceran.checked = false;
            containerEceran.classList.add('hidden');
            inputHargaEcer.value = '';
            inputKonversi.value = 1;
            inputStokEcer.value = 0;
        }
    }

    function toggleDropdownKategori(e) {
        if(e) e.stopPropagation();
        const menu = document.getElementById('kategori-menu');
        const icon = document.getElementById('kategori-icon');
        const trigger = document.getElementById('kategori-trigger');

        if (menu.classList.contains('invisible')) {
            menu.classList.remove('invisible', 'opacity-0', '-translate-y-2');
            icon.classList.add('rotate-180', 'text-brand-500');
            trigger.classList.add('border-brand-500', 'ring-2', 'ring-brand-500', 'bg-white');
        } else {
            tutupDropdownKategori();
        }
    }

    function tutupDropdownKategori() {
        const menu = document.getElementById('kategori-menu');
        const icon = document.getElementById('kategori-icon');
        const trigger = document.getElementById('kategori-trigger');

        if(menu && !menu.classList.contains('invisible')) {
            menu.classList.add('invisible', 'opacity-0', '-translate-y-2');
            icon.classList.remove('rotate-180', 'text-brand-500');
            trigger.classList.remove('border-brand-500', 'ring-2', 'ring-brand-500');
            if(document.getElementById('form-kategori').value === '') {
                trigger.classList.remove('bg-white');
            }
        }
    }

    function pilihKategori(val) {
        const input = document.getElementById('form-kategori');
        const text = document.getElementById('kategori-text');
        const trigger = document.getElementById('kategori-trigger');

        input.value = val;
        text.textContent = val;
        trigger.classList.remove('text-gray-400');
        trigger.classList.add('text-gray-800', 'bg-white');

        tutupDropdownKategori();
    }

    document.addEventListener('click', function(e) {
        const wrapperKategori = document.getElementById('kategori-wrapper');
        if (wrapperKategori && !wrapperKategori.contains(e.target)) {
            tutupDropdownKategori();
        }
        
        const wrapperRole = document.getElementById('role-wrapper');
        if (wrapperRole && !wrapperRole.contains(e.target)) {
            if(typeof tutupDropdownRole === "function") tutupDropdownRole();
        }
    });

    function tutupModalBarang() { 
        document.getElementById('modal-barang').classList.add('hidden'); 
    }

    function bukaModalUploadCsv() {
        document.getElementById('modal-upload-csv').classList.remove('hidden');
    }

    function tutupModalUploadCsv() {
        document.getElementById('modal-upload-csv').classList.add('hidden');
    }

    function bukaModalAkun(aksi, data = null) {
        document.getElementById('modal-akun').classList.remove('hidden');
        document.getElementById('form-aksi-akun').value = aksi;
        
        const passInput = document.getElementById('form-password-akun');
        const passHint = document.getElementById('password-hint');
        
        const inputRole = document.getElementById('form-role-akun');
        const textRole = document.getElementById('role-text');
        
        tutupDropdownRole();

        if (aksi === 'edit' && data) {
            document.getElementById('modal-title-akun').textContent = 'EDIT DATA AKUN';
            document.getElementById('form-id-akun').value = data.id;
            document.getElementById('form-nama-akun').value = data.nama_lengkap;
            document.getElementById('form-username-akun').value = data.username;
            
            inputRole.value = data.role;
            textRole.textContent = data.role === 'admin' ? 'Administrator' : 'Petugas Kasir';
            
            passInput.value = '';
            passInput.required = false; 
            passHint.classList.remove('hidden'); 
        } else {
            document.getElementById('modal-title-akun').textContent = 'BUAT AKUN BARU';
            document.getElementById('form-id-akun').value = '';
            document.getElementById('form-nama-akun').value = '';
            document.getElementById('form-username-akun').value = '';
            
            inputRole.value = 'kasir';
            textRole.textContent = 'Petugas Kasir';
            
            passInput.value = '';
            passInput.required = true; 
            passHint.classList.add('hidden'); 
        }
    }

    function tutupModalAkun() { 
        document.getElementById('modal-akun').classList.add('hidden'); 
    }

    function toggleDropdownRole(e) {
        if(e) e.stopPropagation();
        const menu = document.getElementById('role-menu');
        const icon = document.getElementById('role-icon');
        const trigger = document.getElementById('role-trigger');

        if (menu.classList.contains('invisible')) {
            menu.classList.remove('invisible', 'opacity-0', '-translate-y-2');
            icon.classList.add('rotate-180', 'text-brand-500');
            trigger.classList.add('border-brand-500', 'ring-2', 'ring-brand-500', 'bg-white');
        } else {
            tutupDropdownRole();
        }
    }

    function tutupDropdownRole() {
        const menu = document.getElementById('role-menu');
        const icon = document.getElementById('role-icon');
        const trigger = document.getElementById('role-trigger');

        if(menu && !menu.classList.contains('invisible')) {
            menu.classList.add('invisible', 'opacity-0', '-translate-y-2');
            icon.classList.remove('rotate-180', 'text-brand-500');
            trigger.classList.remove('border-brand-500', 'ring-2', 'ring-brand-500');
        }
    }

    function pilihRole(val, textLabel) {
        const input = document.getElementById('form-role-akun');
        const text = document.getElementById('role-text');
        
        input.value = val;
        text.textContent = textLabel;

        tutupDropdownRole();
    }

    function toggleFormEceran() {
        const toggle = document.getElementById('toggle-eceran');
        const container = document.getElementById('container-eceran');
        const inputEceran = document.getElementById('form-harga-eceran');
        
        if(toggle.checked) {
            container.classList.remove('hidden');
            hitungOtomatisEceran(); 
        } else {
            container.classList.add('hidden');
            inputEceran.value = ''; 
            document.getElementById('form-konversi').value = 1;
            document.getElementById('form-stok-eceran').value = 0;
        }
    }

    function generateKode() {
        const randomNum = Math.floor(1000000000 + Math.random() * 9000000000);
        const newCode = 'BRG' + randomNum;
        
        const inputKode = document.getElementById('form-kode');
        inputKode.value = newCode;
        
        inputKode.classList.add('ring-2', 'ring-brand-500', 'bg-white');
        setTimeout(() => {
            inputKode.classList.remove('ring-2', 'ring-brand-500', 'bg-white');
        }, 400);
        
        showToast("Kode barang berhasil dibuat otomatis!", "success");
    }

    function formatInputUang(input) {
        let val = input.value.replace(/\D/g, ''); 
        if(val !== '') {
            input.value = parseInt(val, 10).toLocaleString('id-ID'); 
        } else {
            input.value = '';
        }
    }

    function bukaModalKonfirmasi(url, pesan) {
        document.getElementById('teks-konfirmasi').innerHTML = pesan;
        document.getElementById('modal-konfirmasi').classList.remove('hidden');
        
        const btnEksekusi = document.getElementById('btn-eksekusi-konfirmasi');
        btnEksekusi.onclick = function() {
            btnEksekusi.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Memproses...';
            btnEksekusi.disabled = true;
            window.location.href = url;
        };
    }

    function bukaModalKonfirmasiForm(formId, pesan) {
        const form = document.getElementById(formId);
        
        // TAMBAHAN: Cek validasi atribut 'required' pada form sebelum membuka modal
        if (form && !form.checkValidity()) {
            form.reportValidity(); // Memunculkan tooltip peringatan bawaan browser ("Please select a file")
            return; // Hentikan proses, modal tidak akan dibuka
        }

        document.getElementById('teks-konfirmasi').innerHTML = pesan;
        document.getElementById('modal-konfirmasi').classList.remove('hidden');
        
        const btnEksekusi = document.getElementById('btn-eksekusi-konfirmasi');
        btnEksekusi.onclick = function() {
            btnEksekusi.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Memproses...';
            btnEksekusi.disabled = true;
            form.submit();
        };
    }

    function tutupModalKonfirmasi() {
        document.getElementById('modal-konfirmasi').classList.add('hidden');
        const btnEksekusi = document.getElementById('btn-eksekusi-konfirmasi');
        btnEksekusi.innerHTML = 'Ya, Lanjutkan';
        btnEksekusi.disabled = false;
    }

    function bukaModalPengeluaran() {
        document.getElementById('modal-pengeluaran').classList.remove('hidden');
        const txtKet = document.querySelector('#modal-pengeluaran textarea[name="keterangan"]');
        if (txtKet) txtKet.value = '';
        const inpNom = document.querySelector('#modal-pengeluaran input[name="nominal"]');
        if (inpNom) inpNom.value = '';
    }

    function tutupModalPengeluaran() {
        document.getElementById('modal-pengeluaran').classList.add('hidden');
    }

    // STATE KASIR (Client-Side)
    let products = []; 
    const rekapTransaksis = <?= isset($rekap_transaksi_map) ? json_encode($rekap_transaksi_map) : '{}' ?>;
    const detailTransaksis = <?= isset($detail_trx_map) ? json_encode($detail_trx_map) : '{}' ?>;
    let cart = [];
    let diskonCart = 0;
    let subtotalCart = 0;

    function updateDiskonCart() {
        const inputDiskon = document.getElementById('input-diskon-cart');
        let val = parseInt(inputDiskon.value.replace(/\./g, '')) || 0;
        diskonCart = val;
        renderCart();
    }

    const productGrid = document.getElementById('product-grid');
    function renderProducts(dataToRender) {
        if (!productGrid) return;
        
        // OPTIMIZATION: Accumulate HTML string instead of innerHTML += loop
        if (dataToRender.length === 0) {
            productGrid.innerHTML = '<tr><td colspan="6" class="text-center py-16 text-gray-400"><i class="fa-solid fa-box-open text-4xl mb-3 opacity-30"></i><p class="font-medium text-sm">Barang tidak ditemukan.</p></td></tr>';
            return;
        }
        
        let htmlContent = '';
        dataToRender.forEach(p => {
            const hGrosir = parseInt(p.harga) || 0;
            const hEceran = parseInt(p.harga_eceran) || 0;
            const sGrosir = parseInt(p.stok);
            const sEceran = parseInt(p.stok_eceran);
            
            const isHabisGrosir = (hGrosir > 0 && sGrosir <= 0);
            const isHabisEceran = (hEceran > 0 && sEceran <= 0);
            
            const totalDijualGrosir = hGrosir > 0;
            const totalDijualEceran = hEceran > 0;
            
            let isHabisTotal = false;
            if (totalDijualGrosir && totalDijualEceran) {
                isHabisTotal = isHabisGrosir && isHabisEceran;
            } else if (totalDijualGrosir) {
                isHabisTotal = isHabisGrosir;
            } else if (totalDijualEceran) {
                isHabisTotal = isHabisEceran;
            }

            const rowClass = isHabisTotal ? 'bg-gray-50 opacity-60 cursor-not-allowed' : 'hover:bg-gray-100/50 transition group cursor-pointer bg-white';
            const clickEvent = isHabisTotal ? `onclick="showToast('Stok barang ini sedang habis!', 'error')"` : `onclick="addToCart(${p.id})"`;
            const btnClass = isHabisTotal ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-gray-50 border border-gray-200 text-gray-600 group-hover:bg-gray-700 group-hover:text-white group-hover:border-gray-700 transition shadow-sm';

            let hargaGrosirHtml = '<span class="text-gray-400 text-[11px] font-medium">-</span>';
            let hargaEceranHtml = '<span class="text-gray-400 text-[11px] font-medium">-</span>';

            if (hGrosir > 0) {
                hargaGrosirHtml = `<div class="${isHabisTotal ? 'text-gray-400' : 'text-brand-600'} font-black text-[11px] sm:text-[13px] truncate">Rp ${hGrosir.toLocaleString('id-ID')}</div>`;
            }
            if (hEceran > 0) {
                hargaEceranHtml = `<div class="${isHabisTotal ? 'text-gray-400' : 'text-brand-600'} font-black text-[11px] sm:text-[13px] truncate">Rp ${hEceran.toLocaleString('id-ID')}</div>`;
            }

            let stokGrosirHtml = '<span class="text-gray-400 text-[11px] sm:text-xs font-medium">-</span>';
            if (hGrosir > 0) {
                stokGrosirHtml = `<span class="inline-block px-1.5 py-1 rounded-md text-[10px] sm:text-[11px] font-black border ${sGrosir <= 0 ? 'bg-red-50 text-red-500 border-red-200' : 'bg-green-50 text-green-700 border-green-200'}">${sGrosir}</span>`;
            }
            
            let stokEceranHtml = '<span class="text-gray-400 text-[11px] font-medium">-</span>';
            if (hEceran > 0) {
                stokEceranHtml = `<span class="inline-block px-1.5 py-1 rounded-md text-[10px] sm:text-[11px] font-black border ${sEceran <= 0 ? 'bg-red-50 text-red-500 border-red-200' : 'bg-blue-50 text-blue-600 border-blue-200'}">${sEceran}</span>`;
            }

            htmlContent += `
                <tr ${clickEvent} class="${rowClass}">
                    <td class="py-2.5 px-2 overflow-hidden">
                        <div class="flex items-center">
                            <div class="w-8 h-8 rounded-lg ${isHabisTotal ? 'bg-gray-300' : p.warna_bg} mr-3 hidden sm:flex items-center justify-center text-white/90 text-xs shrink-0 shadow-sm border border-black/5"><i class="fa-solid fa-box"></i></div>
                            <div class="flex flex-col min-w-0">
                                <span class="text-[10px] font-bold text-brand-500 tracking-wider mb-0.5 truncate uppercase" title="${p.kode}">${p.kode}</span>
                                <span class="font-bold ${isHabisTotal ? 'text-gray-500' : 'text-gray-800'} text-[12px] sm:text-[13px] whitespace-normal line-clamp-2 leading-tight uppercase" title="${p.nama_barang}">${p.nama_barang}</span>
                            </div>
                        </div>
                    </td>
                    <td class="py-2.5 px-2 text-center align-middle">
                        ${stokGrosirHtml}
                    </td>
                    <td class="py-2.5 px-2 text-center align-middle">
                        ${stokEceranHtml}
                    </td>
                    <td class="py-2.5 px-2 text-right align-middle">
                        ${hargaGrosirHtml}
                    </td>
                    <td class="py-2.5 px-2 text-right align-middle">
                        ${hargaEceranHtml}
                    </td>
                    <td class="py-2.5 px-2 text-center">
                        <button class="w-6 h-6 sm:w-7 sm:h-7 rounded-lg ${btnClass} flex items-center justify-center mx-auto" title="${isHabisTotal ? 'Stok Habis' : 'Tambah ke Keranjang'}" ${isHabisTotal ? 'disabled' : ''}>
                            <i class="fa-solid ${isHabisTotal ? 'fa-ban' : 'fa-plus'} text-[10px] sm:text-xs"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        
        // Assign once for much better performance
        productGrid.innerHTML = htmlContent;
    }

    // SERVER-SIDE PENCARIAN BARANG KASIR
    async function fetchProductsAPI(keyword) {
        try {
            const response = await fetch('api_cari_barang.php?q=' + encodeURIComponent(keyword));
            const data = await response.json();
            
            products = data; 
            renderProducts(products);
        } catch (error) {
            console.error("Gagal mengambil data dari server", error);
        } finally {
            const iconSearch = document.querySelector('.fa-spinner');
            if(iconSearch) iconSearch.className = 'fa-solid fa-barcode text-gray-400 text-lg group-focus-within:text-brand-500';
        }
    }

    // Eksekusi Pemuatan Pertama
    if(document.getElementById('search-barang-kasir')) {
        fetchProductsAPI('');
    }

    const searchInputKasir = document.getElementById('search-barang-kasir');
    let debounceTimer; 
    
    if(searchInputKasir) {
        searchInputKasir.addEventListener('input', function(e) {
            clearTimeout(debounceTimer); 
            const iconSearch = document.querySelector('#search-barang-kasir ~ i, .fa-barcode');
            if(iconSearch) iconSearch.className = 'fa-solid fa-spinner fa-spin text-brand-500 text-lg';
            
            debounceTimer = setTimeout(() => {
                const keyword = e.target.value.trim();
                fetchProductsAPI(keyword);
            }, 300); 
        });

        searchInputKasir.addEventListener('focus', function() {
            this.select();
        });

        searchInputKasir.addEventListener('keydown', async function(e) {
            if (e.key === 'Enter' || e.keyCode === 13) {
                e.preventDefault(); 
                clearTimeout(debounceTimer); 
                
                const keyword = this.value.trim();
                if (!keyword) return;

                const response = await fetch('api_cari_barang.php?q=' + encodeURIComponent(keyword));
                const data = await response.json();
                products = data;
                
                const exactMatch = products.find(p => p.kode.toLowerCase() === keyword.toLowerCase());
                
                if (exactMatch) {
                    const hG = parseInt(exactMatch.harga) || 0;
                    const hE = parseInt(exactMatch.harga_eceran) || 0;
                    let isLudes = false;
                    if(hG > 0 && hE > 0) { isLudes = exactMatch.stok <= 0 && exactMatch.stok_eceran <= 0; }
                    else if(hG > 0) { isLudes = exactMatch.stok <= 0; }
                    else if(hE > 0) { isLudes = exactMatch.stok_eceran <= 0; }

                    if (isLudes) {
                        showToast("Stok barang ini sedang habis!", "error");
                        renderProducts([exactMatch]); 
                        this.select(); 
                        return;
                    }
                    addToCart(exactMatch.id); 
                    renderProducts([exactMatch]); 
                    this.select(); 
                    showToast("Ditambahkan: " + exactMatch.nama_barang.toUpperCase(), "success");
                } else {
                    showToast("Barang tidak terdaftar / kode barcode salah!", "error");
                    renderProducts([]);
                    this.select(); 
                }
                this.focus(); 
            }
        });
    }

    function addToCart(id) {
        const product = products.find(p => p.id == id);
        const existing = cart.find(c => c.id == id);
        
        if (existing) {
            const maxStok = existing.tipe_harga === 'grosir' ? existing.stok_grosir_asli : existing.stok_eceran_asli;
            
            if(existing.qty >= maxStok) {
                showToast(`Sisa Stok ${existing.tipe_harga === 'grosir' ? 'Grosir' : 'Eceran'} tidak mencukupi!`, "error"); 
                return;
            }
            existing.qty++;

            if (existing.tipe_harga === 'eceran') {
                if (existing.min_qty_diskon > 0 && existing.harga_diskon_asli > 0 && existing.qty >= existing.min_qty_diskon) {
                    existing.harga_aktif = existing.harga_diskon_asli;
                } else {
                    existing.harga_aktif = existing.harga_eceran_asli;
                }
            } else {
                existing.harga_aktif = existing.harga_grosir_asli;
            }
        } else {
            const hGrosir = parseInt(product.harga) || 0;
            const hEceran = parseInt(product.harga_eceran) || 0;
            const sGrosir = parseInt(product.stok) || 0;
            const sEceran = parseInt(product.stok_eceran) || 0;
            
            let tipeAwal = 'grosir';
            let hargaAwal = hGrosir;

            if (sGrosir > 0 && hGrosir > 0) {
                tipeAwal = 'grosir';
                hargaAwal = hGrosir;
            } else if (sEceran > 0 && hEceran > 0) {
                tipeAwal = 'eceran';
                hargaAwal = hEceran;
            } else if (hGrosir > 0) {
                tipeAwal = 'grosir';
                hargaAwal = hGrosir;
            } else if (hEceran > 0) {
                tipeAwal = 'eceran';
                hargaAwal = hEceran;
            } else {
                showToast("Stok / Harga barang belum diatur dengan benar!", "error");
                return;
            }

            cart.push({ 
                ...product, 
                qty: 1,
                stok_grosir_asli: sGrosir,
                stok_eceran_asli: sEceran,
                konversi: parseInt(product.konversi) || 1,
                harga_grosir_asli: hGrosir,
                harga_eceran_asli: hEceran,
                tipe_harga: tipeAwal,
                harga_aktif: hargaAwal,
                min_qty_diskon: parseInt(product.min_qty_diskon) || 0,
                harga_diskon_asli: parseInt(product.harga_diskon) || 0
            });

            const newlyAdded = cart[cart.length - 1];
            if (newlyAdded.tipe_harga === 'eceran' && newlyAdded.min_qty_diskon > 0 && newlyAdded.harga_diskon_asli > 0 && newlyAdded.qty >= newlyAdded.min_qty_diskon) {
                newlyAdded.harga_aktif = newlyAdded.harga_diskon_asli;
            }
        }
        renderCart();
    }

    function updateTipeHarga(id, tipe) {
        const index = cart.findIndex(c => c.id == id);
        if (index !== -1) {
            let item = cart[index];
            const maxStokBaru = tipe === 'grosir' ? item.stok_grosir_asli : item.stok_eceran_asli;
            
            if (maxStokBaru <= 0) {
                showToast(`Stok ${tipe === 'grosir' ? 'Grosir' : 'Eceran'} sedang kosong.`, "error");
                renderCart(); 
                return;
            }

            item.tipe_harga = tipe;
            
            if (item.qty > maxStokBaru) {
                item.qty = maxStokBaru;
                showToast(`QTY disesuaikan ke maksimal stok ${tipe === 'grosir' ? 'Grosir' : 'Eceran'}`, "error");
            }
            
            if (tipe === 'eceran') {
                if (item.min_qty_diskon > 0 && item.harga_diskon_asli > 0 && item.qty >= item.min_qty_diskon) {
                    item.harga_aktif = item.harga_diskon_asli;
                } else {
                    item.harga_aktif = item.harga_eceran_asli;
                }
            } else {
                item.harga_aktif = item.harga_grosir_asli;
            }
            
            renderCart();
        }
    }

    function updateHargaItem(id, newHarga) {
        const index = cart.findIndex(c => c.id == id);
        if (index !== -1) {
            let harga = parseInt(String(newHarga).replace(/\./g, ''));
            if (isNaN(harga) || harga < 0) { harga = 0; }
            cart[index].harga_aktif = harga; 
            renderCart();
        }
    }

    function renderCart() {
        const tbody = document.getElementById('cart-items');
        if (!tbody) return;
        
        let total = 0;
        let totalItems = 0;
        
        // OPTIMIZATION: Accumulate HTML string to prevent reflow looping
        if (cart.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center align-middle">
                        <div class="flex flex-col items-center justify-center h-56 text-gray-400">
                            <i class="fa-solid fa-cart-arrow-down text-5xl mb-4 opacity-20"></i>
                            <span class="font-medium text-sm">Keranjang kosong</span>
                        </div>
                    </td>
                </tr>
            `;
        } else {
            let htmlContent = '';
            cart.forEach(item => {
                const hargaInt = parseInt(item.harga_aktif); 
                const subtotal = hargaInt * item.qty;
                total += subtotal;
                totalItems += parseInt(item.qty);
                
                const currentMax = item.tipe_harga === 'grosir' ? item.stok_grosir_asli : item.stok_eceran_asli;
                
                let toggleHtml = '';
                if (item.harga_eceran_asli > 0 && item.harga_grosir_asli > 0) {
                    toggleHtml = `
                        <div class="mt-1.5">
                            <select onchange="updateTipeHarga(${item.id}, this.value)" class="w-full bg-brand-50 text-brand-700 border border-brand-200 text-[10px] font-bold py-1 px-1.5 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 cursor-pointer shadow-sm">
                                <option value="grosir" ${item.tipe_harga === 'grosir' ? 'selected' : ''}>Harga Grosir</option>
                                <option value="eceran" ${item.tipe_harga === 'eceran' ? 'selected' : ''}>Harga Eceran</option>
                            </select>
                        </div>
                    `;
                }

                htmlContent += `
                    <tr class="border-b border-gray-100 last:border-0">
                        <td class="py-3 pr-2">
                            <div class="font-bold text-gray-800 text-[13px] leading-tight uppercase">${item.nama_barang}</div>
                            
                            <div class="mt-1.5 flex items-center">
                                <span class="text-[10px] text-gray-400 font-bold mr-0 bg-gray-50 border border-gray-200 border-r-0 px-1.5 py-1 rounded-l h-7 flex items-center">Rp</span>
                                <input type="text" inputmode="numeric" value="${hargaInt.toLocaleString('id-ID')}" oninput="formatInputUang(this)" onchange="updateHargaItem(${item.id}, this.value)" class="w-20 h-7 text-[11px] font-bold border border-gray-200 bg-white rounded-r px-2 py-1 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 text-gray-800 transition shadow-sm m-0" title="Ubah Harga Manual">
                            </div>
                            
                            ${toggleHtml}
                        </td>
                        <td class="py-3 px-1 text-center align-middle">
                            <div class="flex items-center justify-center bg-gray-50 rounded-lg border border-gray-200 w-fit mx-auto overflow-hidden">
                                <button onclick="updateQty(${item.id}, ${item.qty - 1})" class="w-7 h-8 flex items-center justify-center text-gray-500 hover:text-white hover:bg-gray-700 transition"><i class="fa-solid fa-minus text-[10px]"></i></button>
                                <input type="number" min="1" max="${currentMax}" value="${item.qty}" onchange="updateQty(${item.id}, this.value)" class="w-10 h-8 text-center bg-transparent text-sm font-black text-gray-800 focus:outline-none focus:bg-white" title="Maks: ${currentMax}">
                                <button onclick="updateQty(${item.id}, ${item.qty + 1})" class="w-7 h-8 flex items-center justify-center text-gray-500 hover:text-white hover:bg-gray-700 transition"><i class="fa-solid fa-plus text-[10px]"></i></button>
                            </div>
                        </td>
                        <td class="py-3 pl-2 text-right font-black text-gray-800 align-middle text-sm">${subtotal.toLocaleString('id-ID')}</td>
                        <td class="py-3 pl-2 align-middle text-center w-10">
                            <button onclick="hapusItemCart(${item.id})" class="w-8 h-8 rounded-lg bg-red-50 text-red-500 hover:bg-red-500 hover:text-white transition flex items-center justify-center mx-auto" title="Hapus Item"><i class="fa-solid fa-trash-can text-xs"></i></button>
                        </td>
                    </tr>
                `;
            });
            // Assign once for high speed
            tbody.innerHTML = htmlContent;
        }
        
        subtotalCart = total;
        
        if (diskonCart > subtotalCart) {
            diskonCart = subtotalCart;
            const inputDiskon = document.getElementById('input-diskon-cart');
            if(inputDiskon) inputDiskon.value = diskonCart.toLocaleString('id-ID');
        }
        
        let grandTotal = subtotalCart - diskonCart;
        
        document.getElementById('cart-subtotal').textContent = 'Rp ' + subtotalCart.toLocaleString('id-ID');
        document.getElementById('cart-total').textContent = 'Rp ' + grandTotal.toLocaleString('id-ID');
        document.getElementById('cart-badge').textContent = totalItems + ' Item';
    }

    function clearCart() { 
        cart = []; 
        diskonCart = 0;
        const inputDiskon = document.getElementById('input-diskon-cart');
        if(inputDiskon) inputDiskon.value = '0';
        renderCart(); 
    }

    function updateQty(id, newQty) {
        const index = cart.findIndex(c => c.id == id);
        if (index !== -1) {
            let item = cart[index];
            let qty = parseInt(newQty);
            if (isNaN(qty) || qty < 1) { hapusItemCart(id); return; } 
            
            const currentMax = item.tipe_harga === 'grosir' ? item.stok_grosir_asli : item.stok_eceran_asli;
            
            if (qty > currentMax) {
                showToast(`Sisa stok ${item.tipe_harga === 'grosir' ? 'Grosir' : 'Eceran'} hanya ${currentMax}`, "error");
                qty = currentMax;
            }
            
            item.qty = qty;

            if (item.tipe_harga === 'eceran') {
                if (item.min_qty_diskon > 0 && item.harga_diskon_asli > 0 && item.qty >= item.min_qty_diskon) {
                    item.harga_aktif = item.harga_diskon_asli;
                } else {
                    item.harga_aktif = item.harga_eceran_asli;
                }
            } else {
                item.harga_aktif = item.harga_grosir_asli;
            }

            renderCart();
        }
    }

    function hapusItemCart(id) {
        const index = cart.findIndex(c => c.id == id);
        if (index !== -1) {
            cart.splice(index, 1);
            renderCart();
        }
    }

    let totalBelanjaSaatIni = 0;

    function bukaModalCheckout() {
        try {
            if (cart.length === 0) { showToast("Keranjang belanja masih kosong!", "error"); return; }
            totalBelanjaSaatIni = subtotalCart - diskonCart;
            
            const listTbody = document.getElementById('checkout-item-list');
            if(!listTbody) throw new Error("Elemen tbody checkout tidak ditemukan");
            
            // OPTIMIZATION: Build HTML first
            let htmlContent = '';
            cart.forEach(item => {
                const subtotal = item.harga_aktif * item.qty;
                const tipeLabel = item.tipe_harga === 'grosir' ? ' (Grosir)' : ' (Eceran)';
                
                htmlContent += `
                    <tr class="hover:bg-white transition group">
                        <td class="py-2.5 px-3 text-left">
                            <div class="font-bold text-gray-800 text-[13px] mb-0.5 uppercase">${item.nama_barang}</div>
                            <div class="text-[11px] font-medium text-gray-500">${item.qty} x Rp ${parseInt(item.harga_aktif).toLocaleString('id-ID')}${tipeLabel}</div>
                        </td>
                        <td class="py-2.5 px-3 text-right font-black text-gray-700 text-sm align-middle">
                            Rp ${subtotal.toLocaleString('id-ID')}
                        </td>
                    </tr>
                `;
            });
            listTbody.innerHTML = htmlContent;

            document.getElementById('checkout-subtotal').textContent = 'Rp ' + subtotalCart.toLocaleString('id-ID');
            document.getElementById('checkout-diskon').textContent = '- Rp ' + diskonCart.toLocaleString('id-ID');
            document.getElementById('checkout-total-tagihan').textContent = 'Rp ' + totalBelanjaSaatIni.toLocaleString('id-ID');
            
            const inputBayar = document.getElementById('input-bayar');
            const kembalianInput = document.getElementById('input-kembalian');
            const btnKonfirm = document.getElementById('btn-konfirmasi-bayar');
            
            if(inputBayar) inputBayar.value = '';
            if(kembalianInput) {
                kembalianInput.value = '0';
                kembalianInput.classList.remove('text-red-500');
                kembalianInput.classList.add('text-gray-800');
            }
            
            if(btnKonfirm) {
                btnKonfirm.disabled = true;
                btnKonfirm.classList.add('opacity-50', 'cursor-not-allowed');
            }

            const radioTunai = document.querySelector('input[name="metode_bayar"][value="tunai"]');
            if (radioTunai) {
                radioTunai.checked = true;
                toggleMetodeBayar();
            }
            
            const modalCheck = document.getElementById('modal-checkout');
            if(!modalCheck) throw new Error("Elemen utama modal checkout tidak ada di modals.php");
            modalCheck.classList.remove('hidden');
            
            setTimeout(() => { if(inputBayar && document.getElementById('container-tunai').classList.contains('hidden') === false) inputBayar.focus(); }, 100);
            
        } catch (err) {
            console.error(err);
            showToast("Gagal memuat proses bayar. Periksa konsol browser.", "error");
        }
    }

    function tutupModalCheckout() { document.getElementById('modal-checkout').classList.add('hidden'); }

    function toggleMetodeBayar() {
        const metodeRadio = document.querySelector('input[name="metode_bayar"]:checked');
        if (!metodeRadio) return;
        
        const metode = metodeRadio.value;
        const containerTunai = document.getElementById('container-tunai');
        const btnKonfirm = document.getElementById('btn-konfirmasi-bayar');
        const inputBayar = document.getElementById('input-bayar');
        
        if (metode === 'tunai') {
            containerTunai.classList.remove('hidden');
            hitungKembalian(); 
            setTimeout(() => { if(inputBayar) inputBayar.focus(); }, 50);
        } else {
            containerTunai.classList.add('hidden');
            btnKonfirm.disabled = false;
            btnKonfirm.classList.remove('opacity-50', 'cursor-not-allowed');
        }
    }

    function hitungKembalian() {
        const metode = document.querySelector('input[name="metode_bayar"]:checked')?.value;
        if (metode === 'qris') return;

        const rawBayar = document.getElementById('input-bayar').value.replace(/\./g, '');
        const bayar = parseInt(rawBayar) || 0;
        const kembalian = bayar - totalBelanjaSaatIni;
        const kembalianInput = document.getElementById('input-kembalian');
        const btnKonfirm = document.getElementById('btn-konfirmasi-bayar');
        
        if (bayar >= totalBelanjaSaatIni) {
            kembalianInput.value = kembalian.toLocaleString('id-ID');
            kembalianInput.classList.remove('text-red-500');
            kembalianInput.classList.add('text-gray-800');
            btnKonfirm.disabled = false;
            btnKonfirm.classList.remove('opacity-50', 'cursor-not-allowed');
        } else {
            kembalianInput.value = kembalian.toLocaleString('id-ID');
            kembalianInput.classList.remove('text-gray-800');
            kembalianInput.classList.add('text-red-500');
            btnKonfirm.disabled = true;
            btnKonfirm.classList.add('opacity-50', 'cursor-not-allowed');
        }
    }

    async function konfirmasiPembayaran() {
        const metode = document.querySelector('input[name="metode_bayar"]:checked').value;
        let bayar = 0;
        let kembalian = 0;

        if (metode === 'tunai') {
            const rawBayar = document.getElementById('input-bayar').value.replace(/\./g, '');
            bayar = parseInt(rawBayar) || 0;
            kembalian = bayar - totalBelanjaSaatIni;
        } else {
            bayar = totalBelanjaSaatIni;
            kembalian = 0;
        }
        
        tutupModalCheckout();
        
        const payloadCart = cart.map(c => ({
            id: c.id,
            qty: c.qty,
            harga: c.harga_aktif,
            tipe_harga: c.tipe_harga 
        }));

        const btnKonfirm = document.getElementById('btn-konfirmasi-bayar');
        btnKonfirm.disabled = true;

        try {
            const response = await fetch('proses_checkout.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    cart: payloadCart, 
                    total: totalBelanjaSaatIni, 
                    diskon: diskonCart, 
                    tunai: bayar, 
                    kembalian: kembalian,
                    metode: metode 
                })
            });
            const result = await response.json();
            
            if(result.success) {
                cetakStrukHidden('cetak_struk.php?id=' + result.trx_baru.id, function() {
                    showToast("Transaksi berhasil disimpan & dicetak!", "success");
                    updateNotificationBadge();
                    
                    switchTab('transaksi');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                });

                if(result.trx_baru) {
                    const trxBaru = result.trx_baru;
                    
                    // Pastikan metode pembayaran baru masuk ke memori JS
                    if(!trxBaru.metode) trxBaru.metode = metode;
                    
                    rekapTransaksis[trxBaru.id] = trxBaru;
                    detailTransaksis[trxBaru.id] = cart.map(item => ({
                        nama_barang: item.nama_barang,
                        qty: item.qty,
                        harga: item.harga_aktif,
                        subtotal: item.harga_aktif * item.qty,
                        harga_eceran_db: item.harga_eceran_asli,
                        harga_diskon_db: item.harga_diskon_asli,
                        min_qty_diskon: item.min_qty_diskon
                    }));

                    const tbodyRekap = document.getElementById('tbody-rekap');
                    if (tbodyRekap) {
                        const barisKosong = tbodyRekap.querySelector('td[colspan="5"]');
                        if(barisKosong) barisKosong.parentElement.remove(); 

                        const tParts = trxBaru.tanggal.split(/[- :]/);
                        const tglObj = new Date(tParts[0], tParts[1]-1, tParts[2], tParts[3], tParts[4], tParts[5]);
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Ags", "Sep", "Okt", "Nov", "Des"];
                        const strTgl = String(tglObj.getDate()).padStart(2, '0') + ' ' + monthNames[tglObj.getMonth()] + ' ' + tglObj.getFullYear() + ', ' + String(tglObj.getHours()).padStart(2, '0') + ':' + String(tglObj.getMinutes()).padStart(2, '0');

                        const newRow = document.createElement('tr');
                        newRow.className = 'hover:bg-gray-50/40 transition group bg-white'; 
                        newRow.innerHTML = `
                            <td class="py-3 px-6 text-sm font-bold text-gray-700 truncate">TRX-${String(trxBaru.id).padStart(5, '0')}</td>
                            <td class="py-3 px-6 text-sm text-gray-500 font-medium truncate">${strTgl}</td>
                            <td class="py-3 px-6 text-sm text-gray-600 flex items-center font-medium overflow-hidden">
                                <div class="w-6 h-6 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-[10px] mr-2 font-black uppercase shrink-0">${trxBaru.nama_lengkap.substring(0,1)}</div>
                                <span class="truncate">${trxBaru.nama_lengkap}</span>
                            </td>
                            <td class="py-3 px-6 text-sm font-bold text-right text-gray-900 truncate">Rp ${parseInt(trxBaru.total).toLocaleString('id-ID')}</td>
                            <td class="py-3 px-6 text-center no-print">
                                <div class="flex justify-center items-center gap-2">
                                    <button onclick="bukaDetailTrx(${trxBaru.id})" class="text-gray-500 hover:text-gray-700 bg-white border border-gray-200 hover:border-gray-400 shadow-sm px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0">Detail</button>
                                    <?php if($_SESSION['role'] == 'admin'): ?>
                                    <button onclick="bukaModalKonfirmasi('hapus_transaksi.php?id=' + trxBaru.id, 'PERINGATAN KRITIS:<br>Apakah Anda yakin ingin menghapus transaksi <b>TRX-' + String(trxBaru.id).padStart(5, '0') + '</b>?<br><br>Data tidak dapat dikembalikan. Stok barang akan dipulihkan dan total pendapatan akan otomatis dikurangi.')" class="w-7 h-7 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white border border-red-100 hover:border-red-600 rounded-lg flex items-center justify-center transition shadow-sm shrink-0" title="Hapus Transaksi (Void)">
                                        <i class="fa-solid fa-trash-can text-[10px]"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        `;
                        tbodyRekap.insertBefore(newRow, tbodyRekap.firstChild);
                    }

                    const gTotalElem = document.getElementById('grand-total-rekap');
                    if(gTotalElem) {
                        let currTotal = parseInt(gTotalElem.getAttribute('data-value')) || 0;
                        currTotal += parseInt(trxBaru.total);
                        gTotalElem.setAttribute('data-value', currTotal);
                        gTotalElem.textContent = 'Rp ' + currTotal.toLocaleString('id-ID');
                    }

                    const dashPendHarian = document.getElementById('dash-pendapatan-harian');
                    if(dashPendHarian) {
                        let currentVal = parseInt(dashPendHarian.getAttribute('data-value'));
                        if(isNaN(currentVal)) currentVal = parseInt(dashPendHarian.textContent.replace(/\D/g, '')) || 0;
                        let val = currentVal + parseInt(trxBaru.total);
                        dashPendHarian.setAttribute('data-value', val);
                        dashPendHarian.textContent = 'Rp ' + val.toLocaleString('id-ID');
                    }
                    const dashPendTotal = document.getElementById('dash-pendapatan-total');
                    if(dashPendTotal) {
                        let currentVal = parseInt(dashPendTotal.getAttribute('data-value'));
                        if(isNaN(currentVal)) currentVal = parseInt(dashPendTotal.textContent.replace(/\D/g, '')) || 0;
                        let val = currentVal + parseInt(trxBaru.total);
                        dashPendTotal.setAttribute('data-value', val);
                        dashPendTotal.textContent = 'Rp ' + val.toLocaleString('id-ID');
                    }

                    // --- TAMBAHAN FIX: UPDATE LABA BERSIH SECARA REALTIME ---
                    const dashLabaBersih = document.getElementById('dash-laba-bersih');
                    if(dashLabaBersih) {
                        let currentVal = parseInt(dashLabaBersih.getAttribute('data-value'));
                        if(isNaN(currentVal)) currentVal = parseInt(dashLabaBersih.textContent.replace(/\D/g, '')) || 0;
                        let val = currentVal + parseInt(trxBaru.total);
                        dashLabaBersih.setAttribute('data-value', val);
                        dashLabaBersih.textContent = 'Rp ' + val.toLocaleString('id-ID');
                    }
                    // --------------------------------------------------------

                    const dashTotTrx = document.getElementById('dash-total-trx');
                    if(dashTotTrx) {
                        let currentVal = parseInt(dashTotTrx.getAttribute('data-value'));
                        if(isNaN(currentVal)) currentVal = parseInt(dashTotTrx.textContent.replace(/\D/g, '')) || 0;
                        let val = currentVal + 1;
                        dashTotTrx.setAttribute('data-value', val);
                        dashTotTrx.innerHTML = val.toLocaleString('id-ID') + ' <span class="text-xs font-bold text-gray-400">STRUK</span>';
                    }
                    const dashTotBarang = document.getElementById('dash-total-barang');
                    if(dashTotBarang) {
                        let qtyTerjual = cart.reduce((sum, item) => sum + parseInt(item.qty), 0);
                        let currentVal = parseInt(dashTotBarang.getAttribute('data-value'));
                        if(isNaN(currentVal)) currentVal = parseInt(dashTotBarang.textContent.replace(/\D/g, '')) || 0;
                        let val = currentVal + qtyTerjual;
                        dashTotBarang.setAttribute('data-value', val);
                        dashTotBarang.innerHTML = val.toLocaleString('id-ID') + ' <span class="text-xs font-bold text-gray-400">ITEM</span>';
                    }
                    
                    if (window.salesChartInstance) {
                        const chartData = window.salesChartInstance.data.datasets[0].data;
                        const lastIndex = chartData.length - 1; 
                        if (lastIndex >= 0) {
                            chartData[lastIndex] = Number(chartData[lastIndex]) + parseInt(trxBaru.total);
                            window.salesChartInstance.update(); 
                        }
                    }

                    // UPDATE PIE CHART (BARANG TERLARIS) SECARA REALTIME
                    if (window.topItemChartInstance) {
                        // Jika sebelumnya kosong (placeholder), bersihkan pengaturan defaultnya
                        if (window.topItemChartInstance.data.labels[0] === 'Belum Ada Penjualan') {
                            window.topItemChartInstance.data.labels = [];
                            window.topItemChartInstance.data.datasets[0].data = [];
                            window.topItemChartInstance.data.datasets[0].backgroundColor = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
                            window.topItemChartInstance.data.datasets[0].hoverOffset = 4;
                            window.topItemChartInstance.options.plugins.legend.display = true;
                            window.topItemChartInstance.options.plugins.tooltip.enabled = true;
                        }

                        let currentLabels = window.topItemChartInstance.data.labels;
                        let currentData = window.topItemChartInstance.data.datasets[0].data;
                        
                        cart.forEach(item => {
                            const itemName = item.nama_barang.toUpperCase();
                            const qty = parseInt(item.qty);
                            
                            let foundIndex = -1;
                            for(let i=0; i<currentLabels.length; i++){
                                if(currentLabels[i].toUpperCase() === itemName) {
                                    foundIndex = i; break;
                                }
                            }

                            if (foundIndex !== -1) {
                                currentData[foundIndex] += qty; // Jika barang sudah ada di chart, tambahkan jumlahnya
                            } else {
                                currentLabels.push(itemName); // Jika barang belum ada, masukkan ke chart
                                currentData.push(qty);
                            }
                        });

                        // Menggabungkan untuk diurutkan
                        let combined = [];
                        for (let i = 0; i < currentLabels.length; i++) {
                            combined.push({ label: currentLabels[i], data: currentData[i] });
                        }
                        
                        // Urutkan dari yang paling laris ke kurang laris
                        combined.sort((a, b) => b.data - a.data);
                        
                        // Batasi hanya menampilkan top 5
                        combined = combined.slice(0, 5);
                        
                        // Kembalikan datanya ke chart
                        window.topItemChartInstance.data.labels = combined.map(item => item.label);
                        window.topItemChartInstance.data.datasets[0].data = combined.map(item => item.data);
                        
                        // Render ulang chart
                        window.topItemChartInstance.update();
                    }
                }

            } else {
                showToast("Gagal memproses transaksi: " + result.message, "error");
            }
        } catch (error) { 
            showToast("Terjadi kesalahan server database.", "error"); 
        } finally {
            btnKonfirm.disabled = false;
        }
    }

    let activeTrxForReprint = null;

    function bukaDetailTrx(idTrx) {
        activeTrxForReprint = idTrx;
        const trx = rekapTransaksis[idTrx];
        const details = detailTransaksis[idTrx] || [];
        document.getElementById('dtl-id').textContent = 'TRX-' + String(idTrx).padStart(5, '0');
        document.getElementById('dtl-tgl').textContent = new Date(trx.tanggal.replace(' ', 'T')).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
        document.getElementById('dtl-kasir').textContent = trx.nama_lengkap;
        
        const grandTotal = parseInt(trx.total);
        const diskon = trx.diskon ? parseInt(trx.diskon) : 0;
        const subtotal = grandTotal + diskon;
        
        document.getElementById('dtl-subtotal').textContent = 'Rp ' + subtotal.toLocaleString('id-ID');
        document.getElementById('dtl-diskon').textContent = '- Rp ' + diskon.toLocaleString('id-ID');
        document.getElementById('dtl-total').textContent = 'Rp ' + grandTotal.toLocaleString('id-ID');
        
        const tunai = trx.tunai ? parseInt(trx.tunai) : grandTotal;
        const kemb = trx.kembalian ? parseInt(trx.kembalian) : 0;
        
        // Tampilkan Metode Pembayaran di bagian atas (Memaksa agar teks tidak case-sensitive)
        const metodeBayar = String(trx.metode || 'tunai').toLowerCase();
        const dtlMetode = document.getElementById('dtl-metode');
        if(dtlMetode) {
            dtlMetode.innerHTML = metodeBayar === 'qris' 
                ? '<i class="fa-solid fa-qrcode mr-1"></i> QRIS / e-Wallet' 
                : '<i class="fa-solid fa-money-bill-wave mr-1"></i> Tunai / Cash';
        }

        document.getElementById('dtl-tunai').textContent = 'Rp ' + tunai.toLocaleString('id-ID');
        document.getElementById('dtl-kembalian').textContent = 'Rp ' + kemb.toLocaleString('id-ID');
        
        const tbody = document.getElementById('dtl-items');
        
        // OPTIMIZATION: Build HTML first
        let htmlContent = '';
        details.forEach(d => {
            const harga = parseInt(d.harga);
            const subtotal = parseInt(d.subtotal);
            const qtyStr = parseInt(d.qty);
            
            let tipeLabel = ' (G)';
            const hEceranDb = parseInt(d.harga_eceran_db) || 0;
            const hDiskonDb = parseInt(d.harga_diskon_db) || 0;
            const minQtyDiskon = parseInt(d.min_qty_diskon) || 0;
            
            if (hEceranDb > 0) {
                if (harga === hEceranDb) {
                    tipeLabel = ' (E)';
                } else if (hDiskonDb > 0 && harga === hDiskonDb && qtyStr >= minQtyDiskon) {
                    tipeLabel = ' (E)'; 
                }
            }

            htmlContent += `
                <tr class="hover:bg-gray-50 border-b border-gray-100 last:border-0">
                    <td class="px-4 py-3 text-gray-800 font-bold text-sm uppercase">${d.nama_barang}${tipeLabel}</td>
                    <td class="px-4 py-3 text-center text-sm font-medium">${d.qty}</td>
                    <td class="px-4 py-3 text-right text-gray-500 font-medium text-sm">Rp ${subtotal.toLocaleString('id-ID')}</td>
                </tr>
            `;
        });
        tbody.innerHTML = htmlContent;
        
        document.getElementById('modal-detail-trx').classList.remove('hidden');
    }

    function tutupDetailTrx() { document.getElementById('modal-detail-trx').classList.add('hidden'); }

    let printCallback = null;

    function updateNotificationBadge() {
        fetch(window.location.href)
        .then(res => res.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const newBtn = doc.getElementById('notif-btn-container');
            const newDropdown = doc.getElementById('notif-dropdown');
            
            if(newBtn && newDropdown) {
                document.getElementById('notif-btn-container').innerHTML = newBtn.innerHTML;
                document.getElementById('notif-dropdown').innerHTML = newDropdown.innerHTML;
            }
        })
        .catch(err => console.log('Gagal update notifikasi secara background', err));
    }

    function onPrintFinished() {
        if (printCallback) {
            printCallback();
            printCallback = null;
        }
    }

    function cetakStrukHidden(url, callback) {
        printCallback = callback;
        let frame = document.getElementById('iframe-printer');
        if (!frame) {
            frame = document.createElement('iframe');
            frame.id = 'iframe-printer';
            frame.style.position = 'absolute';
            frame.style.width = '0';
            frame.style.height = '0';
            frame.style.border = 'none';
            document.body.appendChild(frame);
        }
        frame.src = url;
    }

    function triggerCetakUlang() {
        if(!activeTrxForReprint) return;
        const trx = rekapTransaksis[activeTrxForReprint];
        
        tutupDetailTrx();
        cetakStrukHidden('cetak_struk.php?id=' + trx.id + '&reprint=1', function() {
            showToast("Berhasil mencetak ulang struk.", "success");
        });
    }

    let pendingSyncParams = null; 

    function bukaModalDrive() {
        const gasUrl = localStorage.getItem('gas_url');
        const inputUrl = document.getElementById('input-gas-url');
        const btnHapus = document.getElementById('btn-hapus-url');

        if (gasUrl) {
            inputUrl.value = gasUrl;
            btnHapus.classList.remove('hidden'); 
        } else {
            inputUrl.value = '';
            btnHapus.classList.add('hidden'); 
        }

        document.getElementById('modal-gdrive').classList.remove('hidden');
        setTimeout(() => inputUrl.focus(), 100);
    }

    function tutupModalDrive() {
        document.getElementById('modal-gdrive').classList.add('hidden');
        pendingSyncParams = null;
    }

    function simpanUrlDrive() {
        const inputUrl = document.getElementById('input-gas-url').value.trim();
        
        if (!inputUrl) {
            localStorage.removeItem('gas_url');
            document.getElementById('btn-hapus-url').classList.add('hidden');
            tutupModalDrive();
            showToast("Konfigurasi URL Google Drive dikosongkan.", "success");
            return;
        }
        
        if (!inputUrl.startsWith('https://script.google.com/')) {
            showToast("URL tidak valid! Harus berawalan https://script.google.com/", "error");
            document.getElementById('input-gas-url').focus();
            return;
        }

        localStorage.setItem('gas_url', inputUrl);
        tutupModalDrive();
        showToast("Konfigurasi Google Drive berhasil disimpan.", "success");

        if (pendingSyncParams) {
            bukaModalSync();
        }
    }

    function hapusUrlDrive() {
        localStorage.removeItem('gas_url');
        document.getElementById('input-gas-url').value = '';
        document.getElementById('btn-hapus-url').classList.add('hidden');
        showToast("Konfigurasi URL Google Drive berhasil dihapus.", "success");
    }

    function bukaModalSync() {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        
        const inputTgl = document.getElementById('input-tgl-sync');
        if(inputTgl) inputTgl.value = `${yyyy}-${mm}-${dd}`;
        
        document.getElementById('modal-sync').classList.remove('hidden');
    }

    function tutupModalSync() {
        document.getElementById('modal-sync').classList.add('hidden');
        
        const actionContainer = document.getElementById('sync-action-buttons');
        const progressContainer = document.getElementById('sync-progress-container');
        const formContainer = document.getElementById('form-sync-container');
        const btnClose = document.getElementById('btn-close-sync');
        const btnEksekusi = document.getElementById('btn-eksekusi-sync');
        
        if (actionContainer) actionContainer.classList.remove('hidden');
        if (formContainer) formContainer.classList.remove('hidden');
        if (btnClose) btnClose.classList.remove('hidden');
        if (progressContainer) progressContainer.classList.add('hidden');
        if (btnEksekusi) {
            btnEksekusi.disabled = false;
            btnEksekusi.innerHTML = '<i class="fa-solid fa-cloud-arrow-up mr-2"></i> Sync Laporan';
        }
        
        updateSyncProgress(0, '');
    }

    function updateSyncProgress(percent, textStatus) {
        const bar = document.getElementById('sync-progress-bar');
        const pctText = document.getElementById('sync-percentage');
        const statusText = document.getElementById('sync-status-text');

        if (bar) bar.style.width = percent + '%';
        if (pctText) pctText.textContent = percent + '%';
        if (statusText) statusText.textContent = textStatus;
    }

    async function prosesModalSync() {
        const tgl = document.getElementById('input-tgl-sync')?.value;
        if (!tgl) {
            showToast("Silakan pilih tanggal terlebih dahulu!", "error");
            return;
        }

        let gasUrl = localStorage.getItem('gas_url');
        const roleUser = '<?= $_SESSION['role'] ?>';
        
        if (!gasUrl) {
            tutupModalSync();
            if (roleUser === 'admin') {
                pendingSyncParams = true;
                bukaModalDrive();
                showToast("Silakan atur URL Google Drive terlebih dahulu.", "error");
            } else {
                showToast("Sistem belum dikonfigurasi. Hubungi Administrator.", "error");
            }
            return;
        }

        const actionContainer = document.getElementById('sync-action-buttons');
        const progressContainer = document.getElementById('sync-progress-container');
        const formContainer = document.getElementById('form-sync-container');
        const btnClose = document.getElementById('btn-close-sync');

        // MENYEMBUNYIKAN SEMUA ELEMEN BAWAH SECARA PENUH AGAR MODAL TIDAK ADA SISA GARIS
        if(formContainer) formContainer.classList.add('hidden');
        if(actionContainer) actionContainer.classList.add('hidden');
        if(btnClose) btnClose.classList.add('hidden'); 
        
        if(progressContainer) progressContainer.classList.remove('hidden');
        
        await new Promise(resolve => setTimeout(resolve, 50));
        
        updateSyncProgress(5, 'Menghubungkan ke server...');

        try {
            updateSyncProgress(15, 'Mengekstrak data transaksi...');
            const responseCek = await fetch(`?tab=rekap&tgl_awal=${tgl}&tgl_akhir=${tgl}`);
            const htmlText = await responseCek.text();
            
            const parser = new DOMParser();
            const doc = parser.parseFromString(htmlText, 'text/html');
            const tbody = doc.getElementById('tbody-rekap');
            
            let hasData = false;
            if (tbody && !tbody.innerHTML.includes('Tidak ada transaksi pada periode')) {
                hasData = true;
            }

            if (!hasData) {
                showToast(`Gagal! Tidak ada transaksi penjualan pada ${tgl}.`, "error");
                
                // MENGEMBALIKAN UI SEPERTI SEMULA JIKA GAGAL
                if (actionContainer) actionContainer.classList.remove('hidden');
                if (formContainer) formContainer.classList.remove('hidden');
                if (btnClose) btnClose.classList.remove('hidden');
                if (progressContainer) progressContainer.classList.add('hidden');
                
                const btnEksekusi = document.getElementById('btn-eksekusi-sync');
                if (btnEksekusi) {
                    btnEksekusi.disabled = false;
                    btnEksekusi.innerHTML = '<i class="fa-solid fa-cloud-arrow-up mr-2"></i> Sync Laporan';
                }
                
                updateSyncProgress(0, '');
                return;
            }

            updateSyncProgress(35, 'Menyusun dokumen PDF...');
            const responseCetak = await fetch(`cetak_laporan.php?tgl_awal=${tgl}&tgl_akhir=${tgl}`);
            if(!responseCetak.ok) throw new Error("Gagal mengambil data laporan");
            let htmlCetak = await responseCetak.text();

            htmlCetak = htmlCetak.replace(/window\.print\(\);?/gi, "");

            const formData = new URLSearchParams();
            formData.append('filename', `Laporan_Transaksi_Toko_${tgl}.pdf`);
            formData.append('html', htmlCetak);

            updateSyncProgress(55, 'Mengunggah ke Google Drive...');
            
            let simProgress = 55;
            const simInterval = setInterval(() => {
                if (simProgress < 95) {
                    simProgress += Math.floor(Math.random() * 4) + 1; 
                    if(simProgress > 95) simProgress = 95; 
                    updateSyncProgress(simProgress, 'Memproses file laporan di Cloud...');
                }
            }, 600);

            await fetch(gasUrl, {
                method: 'POST',
                mode: 'no-cors',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData
            });

            clearInterval(simInterval);
            updateSyncProgress(100, 'Berhasil Diunggah!');
            
            setTimeout(() => {
                showToast(`Sukses! Laporan transaksi tanggal ${tgl} terkirim ke Google Drive.`, "success");
                tutupModalSync();
            }, 1000);
            
        } catch (error) {
            console.error(error);
            showToast("Gagal menyinkronkan. Pastikan koneksi internet stabil.", "error");
            
            // MENGEMBALIKAN UI SEPERTI SEMULA JIKA TERJADI ERROR
            if (actionContainer) actionContainer.classList.remove('hidden');
            if (formContainer) formContainer.classList.remove('hidden');
            if (btnClose) btnClose.classList.remove('hidden');
            if (progressContainer) progressContainer.classList.add('hidden');
            
            const btnEksekusi = document.getElementById('btn-eksekusi-sync');
            if (btnEksekusi) {
                btnEksekusi.disabled = false;
                btnEksekusi.innerHTML = '<i class="fa-solid fa-cloud-arrow-up mr-2"></i> Sync Laporan';
            }
            updateSyncProgress(0, '');
        }
    }

    window.salesChartInstance = null;

    if (document.getElementById('salesChart')) {
        Chart.defaults.font.family = 'Roboto, sans-serif';
        const ctxChart = document.getElementById('salesChart').getContext('2d');
        window.salesChartInstance = new Chart(ctxChart, {
            type: 'line',
            data: {
                labels: <?= isset($chart_labels) ? json_encode($chart_labels) : '[]' ?>,
                datasets: [{
                    label: 'Pendapatan Harian',
                    data: <?= isset($chart_data) ? json_encode($chart_data) : '[]' ?>,
                    borderColor: '#4b5563', 
                    backgroundColor: 'rgba(75, 85, 99, 0.08)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#4b5563',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1e293b',
                        padding: 12,
                        titleFont: { size: 13, weight: 'bold' },
                        bodyFont: { size: 14, weight: 'bold' },
                        callbacks: {
                            label: function(context) {
                                let label = '';
                                if (context.parsed.y !== null) { label += 'Rp ' + context.parsed.y.toLocaleString('id-ID'); }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { weight: '500' } } },
                    y: { 
                        beginAtZero: true,
                        border: { display: false },
                        grid: { color: '#f1f5f9' },
                        ticks: { 
                            font: { weight: '500' },
                            callback: function(value) { return 'Rp ' + value.toLocaleString('id-ID'); } 
                        }
                    }
                }
            }
        });
    }

    // INISIALISASI GRAFIK BARANG TERLARIS (PIE CHART)
    window.topItemChartInstance = null;
    if (document.getElementById('topItemChart')) {
        const ctxTop = document.getElementById('topItemChart').getContext('2d');
        
        const rawLabels = <?= isset($top_barang_labels) ? json_encode($top_barang_labels) : '[]' ?>;
        const rawData = <?= isset($top_barang_data) ? json_encode($top_barang_data) : '[]' ?>;
        
        // Mengecek apakah sudah ada data penjualan atau masih kosong
        const hasData = rawData.length > 0 && rawData.some(val => val > 0);

        window.topItemChartInstance = new Chart(ctxTop, {
            type: 'doughnut',
            data: {
                labels: hasData ? rawLabels : ['Belum Ada Penjualan'],
                datasets: [{
                    data: hasData ? rawData : [1],
                    backgroundColor: hasData ? [
                        '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'
                    ] : ['#e2e8f0'],
                    borderWidth: 0,
                    hoverOffset: hasData ? 4 : 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '65%',
                layout: {
                    padding: { top: 10, bottom: 10, left: 10, right: 10 }
                },
                plugins: {
                    legend: { 
                        position: 'bottom',
                        align: 'center',
                        display: hasData,
                        labels: { 
                            font: { size: 11, weight: 'bold' },
                            boxWidth: 12,
                            usePointStyle: true,
                            padding: 15
                        }
                    },
                    tooltip: {
                        enabled: hasData,
                        backgroundColor: '#1e293b',
                        padding: 12,
                        titleFont: { size: 12 },
                        bodyFont: { size: 13, weight: 'bold' },
                        callbacks: {
                            title: function(context) {
                                return context[0].label;
                            },
                            label: function(context) {
                                return ' Terjual ' + context.parsed;
                            }
                        }
                    }
                }
            }
        });
    }

    // ==========================================
    // 11. SISTEM AUTO UPDATE
    // ==========================================
    document.addEventListener("DOMContentLoaded", function() {
        const localVer = document.getElementById('local-version-display');
        const updateDisplays = document.querySelectorAll('.app-version-text');
        if(localVer) {
            updateDisplays.forEach(el => el.textContent = localVer.textContent);
        }
    });

    async function cekUpdateAplikasi() {
        const btn = document.getElementById('btn-cek-update');
        const infoArea = document.getElementById('update-info-area');
        const warningArea = document.getElementById('update-warning-area');
        
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Mengecek server...';
        btn.disabled = true;
        
        if (warningArea) warningArea.classList.add('hidden'); // Sembunyikan peringatan saat mengecek

        try {
            // Memanggil file update.php yang tadi kita buat
            const response = await fetch('../update.php?action=check'); 
            const result = await response.json();

            if (result.update_available) {
                // Jika update tersedia
                showToast("Versi baru tersedia!", "success");
                infoArea.innerHTML = `
                    <span class="bg-red-50 text-red-600 text-[11px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider mb-2 border border-red-200">Update Versi Baru Tersedia!</span>
                    <span class="bg-blue-50 text-blue-600 text-[13px] font-black px-2 py-0.5 rounded-md tracking-wider mb-2 border border-blue-200">Versi App ${result.latest_version}</span>
                    <p class="text-[11px] text-gray-600 mb-2 font-medium">Tanggal Update : ${result.release_date}</p>
                    <div class="w-full bg-gray-50 p-2 rounded border border-gray-200 text-left text-[11px] text-gray-600 h-16 overflow-y-auto custom-scroll">${result.notes}</div>
                `;
                
                if (warningArea) warningArea.classList.remove('hidden'); // Munculkan Kotak Peringatan
                
                btn.innerHTML = '<i class="fa-solid fa-download mr-2"></i> Download & Install';
                btn.classList.remove('bg-emerald-600', 'hover:bg-emerald-700');
                btn.classList.add('bg-gray-800', 'hover:bg-gray-900');
                
                // Ubah fungsi tombol menjadi proses update
                btn.onclick = function() { prosesInstallUpdate(result.download_url, result.latest_version); };
                btn.disabled = false;

            } else if (result.update_available === false) {
                // Jika sudah versi terbaru
                showToast("Sistem Anda sudah dalam versi terbaru.", "success");
                btn.innerHTML = '<i class="fa-solid fa-rotate mr-2"></i> Cek Versi Terbaru';
                btn.disabled = false;
                
                infoArea.innerHTML = `
                    <i class="fa-solid fa-thumbs-up text-emerald-600 text-4xl mb-3"></i>
                    <p class="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Versi Aplikasi Anda Saat Ini Sudah Terbaru</p>
                    <p class="text-sm font-black bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-md tracking-wider border border-emerald-200">Versi App ${result.local_version}</p>
                `;
                if (warningArea) warningArea.classList.add('hidden');
            } else {
                showToast(result.message || "Gagal menghubungi server.", "error");
                btn.innerHTML = '<i class="fa-solid fa-rotate mr-2"></i> Cek Versi Terbaru';
                btn.disabled = false;
            }

        } catch (e) {
            console.error(e);
            showToast("Gagal! Pastikan komputer terhubung ke internet.", "error");
            btn.innerHTML = '<i class="fa-solid fa-rotate mr-2"></i> Cek Versi Terbaru';
            btn.disabled = false;
        }
    }

    async function prosesInstallUpdate(downloadUrl, newVersion) {
        const btn = document.getElementById('btn-cek-update');
        const infoArea = document.getElementById('update-info-area');
        const warningArea = document.getElementById('update-warning-area');
        const progressContainer = document.getElementById('update-progress-container');
        const progressBar = document.getElementById('update-progress-bar');
        const progressText = document.getElementById('update-percentage');
        const statusText = document.getElementById('update-status-text');
        
        // Sembunyikan UI Info dan Peringatan, Munculkan Progress Bar
        if(infoArea) infoArea.classList.add('hidden');
        if(warningArea) warningArea.classList.add('hidden');
        if(progressContainer) progressContainer.classList.remove('hidden');

        btn.innerHTML = '<i class="fa-solid fa-cog fa-spin mr-2"></i> Menginstal Pembaruan Aplikasi...';
        btn.disabled = true;
        btn.classList.add('opacity-75', 'cursor-not-allowed');

        const formData = new FormData();
        formData.append('download_url', downloadUrl);
        formData.append('new_version', newVersion);
        
        function updateProgress(percent, text) {
            if(progressBar) progressBar.style.width = percent + '%';
            if(progressText) progressText.textContent = percent + '%';
            if(statusText) statusText.textContent = text;
        }
        
        updateProgress(5, 'Menghubungi server cloud...');

        try {
            // Simulasi loading bar saat PHP mendownload dan ekstrak di latar belakang
            let simProgress = 5;
            const simInterval = setInterval(() => {
                if (simProgress < 90) {
                    simProgress += Math.floor(Math.random() * 4) + 1; 
                    if(simProgress > 90) simProgress = 90; 
                    updateProgress(simProgress, 'Mengunduh dan mengekstrak pembaruan...');
                }
            }, 600);

            const response = await fetch('../update.php?action=install', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();
            
            clearInterval(simInterval);

            if (result.success) {
                updateProgress(100, 'Berhasil Diperbarui!');
                showToast("Update Berhasil! Aplikasi akan dimuat ulang...", "success");
                setTimeout(() => {
                    window.location.reload(true); // Memaksa browser merefresh cache
                }, 1500);
            } else {
                updateProgress(0, 'Gagal Mengupdate.');
                showToast("Gagal mengupdate: " + result.message, "error");
                btn.innerHTML = '<i class="fa-solid fa-rotate-right mr-2"></i> Coba Lagi';
                btn.disabled = false;
                btn.classList.remove('opacity-75', 'cursor-not-allowed');
                
                // Kembalikan Tampilan Awal setelah gagal
                setTimeout(() => {
                    if(infoArea) infoArea.classList.remove('hidden');
                    if(warningArea) warningArea.classList.remove('hidden');
                    if(progressContainer) progressContainer.classList.add('hidden');
                }, 2000);
            }
        } catch (e) {
            console.error(e);
            updateProgress(0, 'Gagal Terhubung.');
            showToast("Terjadi kesalahan sistem saat mengekstrak file.", "error");
            btn.innerHTML = '<i class="fa-solid fa-rotate-right mr-2"></i> Coba Lagi';
            btn.disabled = false;
            btn.classList.remove('opacity-75', 'cursor-not-allowed');
            
            // Kembalikan Tampilan Awal setelah gagal
            setTimeout(() => {
                if(infoArea) infoArea.classList.remove('hidden');
                if(warningArea) warningArea.classList.remove('hidden');
                if(progressContainer) progressContainer.classList.add('hidden');
            }, 2000);
        }
    }
</script>