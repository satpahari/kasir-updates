<?php
// [AUTO-PATCH] Tambahkan kolom pendukung di database secara otomatis (Satu per satu agar aman)
$cek_kolom_diskon = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'diskon'");
if(mysqli_num_rows($cek_kolom_diskon) == 0) @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN diskon INT DEFAULT 0 AFTER total");

$cek_kolom_tunai = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'tunai'");
if(mysqli_num_rows($cek_kolom_tunai) == 0) @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN tunai INT(11) NULL AFTER diskon");

$cek_kolom_kembalian = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'kembalian'");
if(mysqli_num_rows($cek_kolom_kembalian) == 0) @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN kembalian INT(11) NULL AFTER tunai");

$cek_kolom_metode = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'metode'");
if(mysqli_num_rows($cek_kolom_metode) == 0) @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN metode VARCHAR(50) DEFAULT 'tunai' AFTER kembalian");

// [AUTO-PATCH BARU] Buat tabel pengeluaran jika belum ada
$create_table_pengeluaran = "CREATE TABLE IF NOT EXISTS pengeluaran (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    keterangan VARCHAR(255) NOT NULL,
    nominal INT NOT NULL
)";
@mysqli_query($koneksi, $create_table_pengeluaran);

// 1. MENGAMBIL DATA UNTUK TRANSAKSI KASIR
// DIHAPUS: Kita tidak lagi meload semua barang disini, akan dihandle oleh AJAX di api_cari_barang.php

// 2. MENGAMBIL SELURUH DATA BARANG UNTUK MENU "DATA BARANG" (DENGAN PAGINATION)
$limit_barang = 20; // Tampilkan 20 barang per halaman agar browser tidak berat
$page_barang = isset($_GET['page_barang']) ? (int)$_GET['page_barang'] : 1;
$offset_barang = ($page_barang - 1) * $limit_barang;

// Pencarian khusus di menu tabel barang
$search_brg = isset($_GET['cari_brg']) ? mysqli_real_escape_string($koneksi, $_GET['cari_brg']) : '';
$where_brg = $search_brg != '' ? "WHERE kode LIKE '%$search_brg%' OR nama_barang LIKE '%$search_brg%'" : "";

$q_count_brg = mysqli_query($koneksi, "SELECT COUNT(id) as jml FROM barang $where_brg");
$total_data_barang = mysqli_fetch_assoc($q_count_brg)['jml'];
$total_page_barang = ceil($total_data_barang / $limit_barang);

$q_semua_barang = mysqli_query($koneksi, "SELECT * FROM barang $where_brg ORDER BY id DESC LIMIT $limit_barang OFFSET $offset_barang");

// MENAMBAHKAN PENGHITUNG ABSOLUT UNTUK DASHBOARD (Mencegah bug jumlah berubah saat mencari barang)
$q_count_absolut = mysqli_query($koneksi, "SELECT COUNT(id) as jml FROM barang");
$total_barang_keseluruhan = mysqli_fetch_assoc($q_count_absolut)['jml'];

// 3. FITUR NOTIFIKASI: MENGAMBIL DATA BARANG YANG STOKNYA HABIS
$q_stok_habis = mysqli_query($koneksi, "SELECT * FROM barang WHERE stok <= 0 ORDER BY nama_barang ASC");
$stok_habis_array = [];
while($row = mysqli_fetch_assoc($q_stok_habis)){
    // Modifikasi: Cek juga apakah stok eceran <= 0
    $stok_eceran = isset($row['stok_eceran']) ? (int)$row['stok_eceran'] : 0;
    if ($stok_eceran <= 0) {
        $stok_habis_array[] = $row;
    }
}
$total_stok_habis = count($stok_habis_array);

// 4. PAGINATION & FILTER UNTUK MENU "LAPORAN PENJUALAN"
$tgl_awal = isset($_GET['tgl_awal']) ? $_GET['tgl_awal'] : date('Y-m-01');
$tgl_akhir = isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : date('Y-m-t');

$limit_rekap = 10;
$page_rekap = isset($_GET['page_rekap']) ? (int)$_GET['page_rekap'] : 1;
$offset_rekap = ($page_rekap - 1) * $limit_rekap;

$where_rekap = "WHERE t.tanggal >= '$tgl_awal 00:00:00' AND t.tanggal <= '$tgl_akhir 23:59:59'";

// Hitung total data rekap dan grand total pendapatan seluruh halaman
$q_count_rekap = mysqli_query($koneksi, "SELECT COUNT(t.id) as total, SUM(t.total) as grand_total FROM transaksi t $where_rekap");
$row_count_rekap = mysqli_fetch_assoc($q_count_rekap);

$total_data_rekap = isset($row_count_rekap['total']) ? (int)$row_count_rekap['total'] : 0;
$total_pendapatan_all = isset($row_count_rekap['grand_total']) ? (int)$row_count_rekap['grand_total'] : 0;
$total_page_rekap = ceil($total_data_rekap / $limit_rekap);

$q_rekap = mysqli_query($koneksi, "
    SELECT t.*, u.nama_lengkap 
    FROM transaksi t 
    JOIN users u ON t.id_user = u.id 
    $where_rekap
    ORDER BY t.tanggal DESC
    LIMIT $limit_rekap OFFSET $offset_rekap
");

// --- Fetch Detail Transaksi untuk Modal Rekap ---
$rekap_transaksi_map = [];
$detail_trx_map = [];
if(mysqli_num_rows($q_rekap) > 0) {
    $ids = [];
    while($r = mysqli_fetch_assoc($q_rekap)) {
        $rekap_transaksi_map[$r['id']] = $r;
        $ids[] = $r['id'];
    }
    mysqli_data_seek($q_rekap, 0); 

    $ids_str = implode(',', $ids);
    if(!empty($ids_str)) {
        $q_detail = mysqli_query($koneksi, "
            SELECT dt.*, b.nama_barang, b.harga AS harga_grosir_db, b.harga_eceran AS harga_eceran_db, b.harga_diskon AS harga_diskon_db, b.min_qty_diskon 
            FROM detail_transaksi dt 
            JOIN barang b ON dt.id_barang = b.id 
            WHERE dt.id_transaksi IN ($ids_str)
        ");
        while($d = mysqli_fetch_assoc($q_detail)) {
            $detail_trx_map[$d['id_transaksi']][] = $d;
        }
    }
}

// 5. FITUR BARU: MENGAMBIL DATA PENGELUARAN TOKO
$tgl_awal_pengeluaran = isset($_GET['tgl_awal_pengeluaran']) ? $_GET['tgl_awal_pengeluaran'] : date('Y-m-01');
$tgl_akhir_pengeluaran = isset($_GET['tgl_akhir_pengeluaran']) ? $_GET['tgl_akhir_pengeluaran'] : date('Y-m-t');

$limit_pengeluaran = 15;
$page_pengeluaran = isset($_GET['page_pengeluaran']) ? (int)$_GET['page_pengeluaran'] : 1;
$offset_pengeluaran = ($page_pengeluaran - 1) * $limit_pengeluaran;

$where_pengeluaran = "WHERE p.tanggal >= '$tgl_awal_pengeluaran 00:00:00' AND p.tanggal <= '$tgl_akhir_pengeluaran 23:59:59'";

$q_count_pengeluaran = mysqli_query($koneksi, "SELECT COUNT(p.id) as total, SUM(p.nominal) as grand_total FROM pengeluaran p $where_pengeluaran");
$row_count_pengeluaran = mysqli_fetch_assoc($q_count_pengeluaran);

$total_data_pengeluaran = isset($row_count_pengeluaran['total']) ? (int)$row_count_pengeluaran['total'] : 0;
$total_nominal_pengeluaran = isset($row_count_pengeluaran['grand_total']) ? (int)$row_count_pengeluaran['grand_total'] : 0;
$total_page_pengeluaran = ceil($total_data_pengeluaran / $limit_pengeluaran);

$q_pengeluaran = mysqli_query($koneksi, "
    SELECT p.*, u.nama_lengkap 
    FROM pengeluaran p 
    JOIN users u ON p.id_user = u.id 
    $where_pengeluaran
    ORDER BY p.tanggal DESC
    LIMIT $limit_pengeluaran OFFSET $offset_pengeluaran
");

// --- Data Statistik Dashboard ---
$bulan_ini = date('Y-m');

// Pendapatan & Total TRX
$q_dash_summary = mysqli_query($koneksi, "SELECT COUNT(id) as total_trx, SUM(total) as pendapatan FROM transaksi WHERE DATE_FORMAT(tanggal, '%Y-%m') = '$bulan_ini'");
$dash_summary = mysqli_fetch_assoc($q_dash_summary);
$dash_pendapatan = $dash_summary['pendapatan'] ? $dash_summary['pendapatan'] : 0;
$dash_total_trx = $dash_summary['total_trx'] ? $dash_summary['total_trx'] : 0;

// Pengeluaran Bulanan (Baru)
$q_dash_pengeluaran = mysqli_query($koneksi, "SELECT SUM(nominal) as total_pengeluaran FROM pengeluaran WHERE DATE_FORMAT(tanggal, '%Y-%m') = '$bulan_ini'");
$dash_pengeluaran_summary = mysqli_fetch_assoc($q_dash_pengeluaran);
$dash_pengeluaran = $dash_pengeluaran_summary['total_pengeluaran'] ? $dash_pengeluaran_summary['total_pengeluaran'] : 0;

// Laba Bersih (Baru)
$dash_laba_bersih = $dash_pendapatan - $dash_pengeluaran;

// Barang Terjual
$q_dash_barang = mysqli_query($koneksi, "SELECT SUM(qty) as total_barang FROM detail_transaksi dt JOIN transaksi t ON dt.id_transaksi = t.id WHERE DATE_FORMAT(t.tanggal, '%Y-%m') = '$bulan_ini'");
$dash_barang = mysqli_fetch_assoc($q_dash_barang);
$dash_total_barang = $dash_barang['total_barang'] ? $dash_barang['total_barang'] : 0;

// BARU: Top 5 Barang Terlaris Bulan Ini
$q_top_barang = mysqli_query($koneksi, "
    SELECT b.nama_barang, SUM(dt.qty) as total_qty 
    FROM detail_transaksi dt 
    JOIN transaksi t ON dt.id_transaksi = t.id 
    JOIN barang b ON dt.id_barang = b.id 
    WHERE DATE_FORMAT(t.tanggal, '%Y-%m') = '$bulan_ini' 
    GROUP BY dt.id_barang 
    ORDER BY total_qty DESC 
    LIMIT 5
");
$top_barang_labels = [];
$top_barang_data = [];
while($row = mysqli_fetch_assoc($q_top_barang)) {
    $top_barang_labels[] = $row['nama_barang'];
    $top_barang_data[] = (int)$row['total_qty'];
}

// Hari Ini
$hari_ini = date('Y-m-d');
$q_dash_harian = mysqli_query($koneksi, "SELECT COUNT(id) as total_trx_harian, SUM(total) as pendapatan_harian FROM transaksi WHERE DATE(tanggal) = '$hari_ini'");
$dash_harian = mysqli_fetch_assoc($q_dash_harian);
$dash_pendapatan_harian = isset($dash_harian['pendapatan_harian']) ? $dash_harian['pendapatan_harian'] : 0;
$total_trx_hari_ini = isset($dash_harian['total_trx_harian']) ? (int)$dash_harian['total_trx_harian'] : 0;

// Data Grafik 7 Hari Terakhir
$chart_labels = [];
$chart_data = [];
for ($i = 6; $i >= 0; $i--) {
    $tgl = date('Y-m-d', strtotime("-$i days"));
    $chart_labels[] = date('d M', strtotime($tgl));
    $q_harian = mysqli_query($koneksi, "SELECT SUM(total) as harian FROM transaksi WHERE DATE(tanggal) = '$tgl'");
    $h = mysqli_fetch_assoc($q_harian);
    $chart_data[] = $h['harian'] ? (int)$h['harian'] : 0;
}

// 6. MENGAMBIL DATA AKUN PENGGUNA (HANYA ADMIN)
$q_semua_akun = false;
$total_akun = 0;
if($_SESSION['role'] == 'admin') {
    $q_semua_akun = mysqli_query($koneksi, "SELECT * FROM users ORDER BY role ASC, nama_lengkap ASC");
    $total_akun = mysqli_num_rows($q_semua_akun);
}
?>