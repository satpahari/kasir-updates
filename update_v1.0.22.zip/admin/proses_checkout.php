<?php
session_start();
require '../config/koneksi.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['cart']) || empty($data['cart'])) {
    echo json_encode(["success" => false, "message" => "Keranjang kosong"]);
    exit;
}

// Sanitasi Input & Keamanan
$id_user = (int)$_SESSION['user_id'];
$total = (int)$data['total'];
$diskon = isset($data['diskon']) ? (int)$data['diskon'] : 0;
$tunai = (int)$data['tunai'];
$kembalian = (int)$data['kembalian'];
$metode = isset($data['metode']) ? mysqli_real_escape_string($koneksi, $data['metode']) : 'tunai';

// --- AUTO PATCHING AMAN (Mengecek dan membuat kolom satu per satu) ---
$cek_diskon = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'diskon'");
if(mysqli_num_rows($cek_diskon) == 0) {
    @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN diskon INT DEFAULT 0 AFTER total");
}

$cek_tunai = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'tunai'");
if(mysqli_num_rows($cek_tunai) == 0) {
    @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN tunai INT(11) NULL AFTER diskon");
}

$cek_kembalian = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'kembalian'");
if(mysqli_num_rows($cek_kembalian) == 0) {
    @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN kembalian INT(11) NULL AFTER tunai");
}

$cek_metode = mysqli_query($koneksi, "SHOW COLUMNS FROM transaksi LIKE 'metode'");
if(mysqli_num_rows($cek_metode) == 0) {
    @mysqli_query($koneksi, "ALTER TABLE transaksi ADD COLUMN metode VARCHAR(50) DEFAULT 'tunai' AFTER kembalian");
}
// ---------------------------------------------------------------------

// 1. Simpan ke tabel transaksi utama
$query_transaksi = "INSERT INTO transaksi (id_user, total, diskon, tunai, kembalian, metode) VALUES ('$id_user', '$total', '$diskon', '$tunai', '$kembalian', '$metode')";

if (mysqli_query($koneksi, $query_transaksi)) {
    $id_transaksi = mysqli_insert_id($koneksi);
    
    // Ambil tanggal waktu transaksi dari database
    $q_tgl = mysqli_query($koneksi, "SELECT tanggal FROM transaksi WHERE id = '$id_transaksi'");
    $d_tgl = mysqli_fetch_assoc($q_tgl);
    $tanggal_trx = $d_tgl['tanggal'];

    // 2. Loop setiap item di keranjang
    foreach ($data['cart'] as $item) {
        $id_barang = (int)$item['id'];
        $qty = (int)$item['qty'];
        $harga_final = (int)$item['harga']; 
        $subtotal = $qty * $harga_final;
        $tipe_harga = isset($item['tipe_harga']) ? mysqli_real_escape_string($koneksi, $item['tipe_harga']) : 'grosir';

        mysqli_query($koneksi, "INSERT INTO detail_transaksi (id_transaksi, id_barang, qty, harga, subtotal) VALUES ('$id_transaksi', '$id_barang', '$qty', '$harga_final', '$subtotal')");

        // 3. Logika Pemotongan Stok
        $q_brg = mysqli_query($koneksi, "SELECT stok, konversi, stok_eceran FROM barang WHERE id = '$id_barang'");
        if ($r_brg = mysqli_fetch_assoc($q_brg)) {
            $stok_awal = (int)$r_brg['stok'];
            $konversi = (int)$r_brg['konversi'] > 0 ? (int)$r_brg['konversi'] : 1;
            $stok_eceran_awal = (int)$r_brg['stok_eceran'];

            if ($tipe_harga === 'grosir') {
                $s_grosir_baru = $stok_awal - $qty;
                $s_eceran_baru = $stok_eceran_awal - ($qty * $konversi);
            } else {
                $s_eceran_baru = $stok_eceran_awal - $qty;
                $s_grosir_baru = floor($s_eceran_baru / $konversi);
            }

            if ($s_grosir_baru < 0) $s_grosir_baru = 0;
            if ($s_eceran_baru < 0) $s_eceran_baru = 0;

            mysqli_query($koneksi, "UPDATE barang SET stok = '$s_grosir_baru', stok_eceran = '$s_eceran_baru' WHERE id = '$id_barang'");
        }
    }

    echo json_encode([
        "success" => true, 
        "message" => "Transaksi berhasil dicatat",
        "trx_baru" => [
            "id" => $id_transaksi,
            "tanggal" => $tanggal_trx,
            "total" => $total,
            "diskon" => $diskon,
            "tunai" => $tunai,
            "kembalian" => $kembalian,
            "metode" => $metode,
            "nama_lengkap" => $_SESSION['nama_lengkap']
        ]
    ]);
} else {
    // Memberikan rincian pesan error MySQL langsung ke layar jika tetap gagal
    echo json_encode(["success" => false, "message" => "Gagal menyimpan transaksi: " . mysqli_error($koneksi)]);
}
?>