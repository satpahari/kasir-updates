<?php
session_start();
// Jika sudah login, langsung arahkan ke dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: admin/index.php");
    exit;
}

// 1. Hubungkan ke database untuk mengambil data akun
require 'config/koneksi.php';

// Ambil semua daftar akun, urutkan dari Admin ke Kasir, lalu berdasarkan abjad nama
$query_users = mysqli_query($koneksi, "SELECT * FROM users ORDER BY role ASC, nama_lengkap ASC");
$users = [];
if ($query_users) {
    while($row = mysqli_fetch_assoc($query_users)) {
        $users[] = $row;
    }
}

// Tangkap status error dari URL
$error = isset($_GET['error']) ? $_GET['error'] : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Point of Sales</title>
    
    <!-- Font Roboto Google Fonts -->
    <link rel="stylesheet" href="assets/css/fonts.css">
    
    <script src="assets/js/tailwindcss.js"></script>
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="assets/img/kasir.ico">
    <script>
        tailwind.config = {
            theme: { 
                extend: {
                    fontFamily: {
                        sans: ['Roboto', 'sans-serif'],
                    },
                    animation: {
                        blob: "blob 7s infinite",
                        shake: "shake 0.5s cubic-bezier(.36,.07,.19,.97) both",
                    },
                    keyframes: {
                        blob: {
                            "0%": { transform: "translate(0px, 0px) scale(1)" },
                            "33%": { transform: "translate(30px, -50px) scale(1.1)" },
                            "66%": { transform: "translate(-20px, 20px) scale(0.9)" },
                            "100%": { transform: "translate(0px, 0px) scale(1)" },
                        },
                        shake: {
                            "10%, 90%": { transform: "translate3d(-1px, 0, 0)" },
                            "20%, 80%": { transform: "translate3d(2px, 0, 0)" },
                            "30%, 50%, 70%": { transform: "translate3d(-4px, 0, 0)" },
                            "40%, 60%": { transform: "translate3d(4px, 0, 0)" }
                        }
                    }
                } 
            }
        }
    </script>
    <style>
        .custom-scroll::-webkit-scrollbar { width: 6px; }
        .custom-scroll::-webkit-scrollbar-track { background: transparent; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        
        .glass-panel {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
        }
    </style>
</head>
<body class="bg-slate-50 flex items-center justify-center min-h-screen w-full relative overflow-hidden selection:bg-slate-500 selection:text-white p-4 sm:p-6">
    
    <!-- Animated Background Blobs -->
    <div class="absolute top-0 -left-4 w-72 h-72 bg-indigo-300 rounded-full mix-blend-multiply filter blur-2xl opacity-40 animate-blob pointer-events-none"></div>
    <div class="absolute top-0 -right-4 w-72 h-72 bg-emerald-300 rounded-full mix-blend-multiply filter blur-2xl opacity-40 animate-blob animation-delay-2000 pointer-events-none"></div>
    <div class="absolute -bottom-8 left-20 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-2xl opacity-40 animate-blob animation-delay-4000 pointer-events-none"></div>

    <!-- Main Login Card (Split Screen Design) -->
    <div class="w-full max-w-4xl glass-panel rounded-[2rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] border border-white flex flex-col md:flex-row overflow-hidden relative z-10">
        
        <!-- Kiri: Branding Panel -->
        <div class="md:w-5/12 bg-gradient-to-br from-slate-800 to-slate-900 text-white p-8 md:p-10 flex flex-col justify-between relative overflow-hidden shrink-0">
            <!-- Ornamen Dekoratif -->
            <div class="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20">
                <div class="absolute -top-24 -right-24 w-48 h-48 rounded-full border-4 border-white/20"></div>
                <div class="absolute bottom-10 -left-10 w-32 h-32 rounded-full border-4 border-white/20"></div>
                <div class="absolute top-1/2 left-1/2 w-64 h-64 rounded-full border border-white/10 transform -translate-x-1/2 -translate-y-1/2"></div>
            </div>

            <div class="relative z-10">
                <div class="w-14 h-14 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl flex items-center justify-center text-2xl mb-6 shadow-xl">
                    <i class="fa-solid fa-store text-white"></i>
                </div>
                <h1 class="text-2xl md:text-3xl font-black tracking-tight mb-2 leading-tight">Toko Sembako<br>Berkah Bersama.</h1>
                <p class="text-slate-400 text-sm md:text-base font-medium">Sistem Manajemen Point of Sales terpadu untuk efisiensi transaksi Anda.</p>
            </div>

            <div class="hidden md:block relative z-10 mt-12">
                <div class="bg-white/10 backdrop-blur-md border border-white/10 p-4 rounded-2xl">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center">
                            <i class="fa-solid fa-shield-halved"></i>
                        </div>
                        <div>
                            <p class="text-xs text-slate-300 font-bold uppercase tracking-wider">Akses Terenkripsi</p>
                            <p class="text-[10px] text-slate-400">Data anda terlindungi dengan aman</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kanan: Form Panel -->
        <div class="md:w-7/12 p-8 md:p-12 flex flex-col justify-center relative bg-white/50">
            
            <div class="mb-8 text-center md:text-left">
                <h2 class="text-2xl font-black text-slate-800 tracking-tight">Selamat Datang 👋</h2>
                <p class="text-sm text-slate-500 font-medium mt-1">Silakan pilih akun dan masukkan kata sandi.</p>
            </div>

            <!-- Pesan Error -->
            <?php if($error): ?>
            <div class="mb-6 bg-red-50 border border-red-200 text-red-600 p-4 rounded-2xl flex items-start animate-shake shadow-sm" id="error-alert">
                <i class="fa-solid fa-triangle-exclamation text-lg mt-0.5 mr-3 shrink-0"></i>
                <div class="flex-1">
                    <p class="font-bold text-sm">Akses Ditolak!</p>
                    <p class="text-xs text-red-500 font-medium mt-0.5">
                        <?php
                            if ($error == '1') echo "Password yang Anda masukkan salah.";
                            elseif ($error == '2') echo "Silakan pilih akun Anda terlebih dahulu.";
                            else echo "Terjadi kesalahan sistem.";
                        ?>
                    </p>
                </div>
                <button onclick="document.getElementById('error-alert').style.display='none'" class="text-red-400 hover:text-red-700 transition">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <?php endif; ?>

            <form action="auth/login.php" method="POST" id="loginForm" onsubmit="showLoadingState()">
                
                <!-- CUSTOM DROPDOWN AKUN -->
                <div class="mb-5 relative" id="akun-wrapper">
                    <label class="block text-slate-700 text-xs font-bold mb-2 uppercase tracking-wide">Pilih Profil Akses</label>
                    <input type="hidden" name="username" id="form-username" required>
                    
                    <button type="button" id="akun-trigger" onclick="toggleDropdownAkun(event)" class="w-full text-left px-4 py-3.5 border-2 border-slate-200 rounded-xl bg-white text-slate-400 font-medium text-sm flex justify-between items-center transition-all duration-300 ease-in-out hover:border-slate-300 focus:outline-none focus:border-slate-400 focus:ring-4 focus:ring-slate-500/20 shadow-sm group">
                        <div class="flex items-center gap-3 overflow-hidden">
                            <div class="w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center shrink-0 transition-colors group-hover:bg-slate-200" id="selected-avatar">
                                <i class="fa-solid fa-user text-xs"></i>
                            </div>
                            <span id="akun-text" class="truncate font-bold">Masuk Sebagai?</span>
                        </div>
                        <i id="akun-icon" class="fa-solid fa-chevron-down text-xs transition-transform duration-300 ml-2 shrink-0"></i>
                    </button>
                    
                    <!-- Dropdown Menu -->
                    <div id="akun-menu" class="absolute z-50 w-full mt-2 bg-white border border-slate-100 rounded-xl shadow-2xl opacity-0 invisible scale-95 origin-top transition-all duration-200 ease-out">
                        <?php if (count($users) > 0): ?>
                            <div class="p-2 max-h-64 overflow-y-auto custom-scroll">
                                <?php foreach ($users as $u): ?>
                                    <?php 
                                        $is_admin = $u['role'] == 'admin';
                                        $bg_color = $is_admin ? 'bg-indigo-50 text-indigo-600' : 'bg-emerald-50 text-emerald-600';
                                        $badge_color = $is_admin ? 'bg-indigo-100 text-indigo-700' : 'bg-emerald-100 text-emerald-700';
                                    ?>
                                    <button type="button" onclick="pilihAkun('<?= htmlspecialchars($u['username']) ?>', '<?= htmlspecialchars(addslashes($u['nama_lengkap'])) ?>', '<?= $u['role'] ?>', '<?= $bg_color ?>')" class="w-full text-left p-3 hover:bg-slate-50 rounded-lg transition-colors flex items-center justify-between group/item mb-1 last:mb-0">
                                        <div class="flex items-center gap-3 overflow-hidden">
                                            <div class="w-10 h-10 rounded-full <?= $bg_color ?> flex items-center justify-center font-black text-sm shrink-0 shadow-sm group-hover/item:scale-110 transition-transform">
                                                <?= substr($u['nama_lengkap'], 0, 1) ?>
                                            </div>
                                            <div class="min-w-0">
                                                <div class="font-bold text-slate-800 text-sm truncate"><?= htmlspecialchars($u['nama_lengkap']) ?></div>
                                                <div class="text-[11px] font-medium text-slate-400 truncate">@<?= htmlspecialchars($u['username']) ?></div>
                                            </div>
                                        </div>
                                        <span class="text-[9px] font-black uppercase tracking-wider px-2 py-1 rounded-md <?= $badge_color ?> shrink-0 hidden sm:block">
                                            <?= $u['role'] ?>
                                        </span>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="p-6 text-center text-sm text-slate-500 font-medium flex flex-col items-center">
                                <i class="fa-solid fa-users-slash text-2xl mb-2 opacity-50"></i>
                                Belum ada akun terdaftar.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Input Password -->
                <div class="mb-8">
                    <label class="block text-slate-700 text-xs font-bold mb-2 uppercase tracking-wide">Kata Sandi</label>
                    <div class="relative group">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none transition-colors duration-300 ease-in-out group-focus-within:text-slate-600 text-slate-400">
                            <i class="fa-solid fa-lock text-sm"></i>
                        </div>
                        <input type="password" name="password" id="password" required placeholder="Masukkan kata sandi . . ." class="w-full pl-11 pr-12 py-3.5 border-2 border-slate-200 rounded-xl bg-white text-slate-800 font-bold text-sm focus:outline-none focus:border-slate-400 focus:ring-4 focus:ring-slate-500/20 transition-all duration-300 ease-in-out shadow-sm placeholder:font-medium placeholder:text-slate-400" autocomplete="off" disabled>
                        
                        <button type="button" onclick="togglePassword()" id="btn-eye" class="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 transition-colors duration-300 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                            <i id="eye-icon" class="fa-solid fa-eye transition-all duration-300"></i>
                        </button>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" id="btn-login" class="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-4 rounded-xl transition-all duration-300 shadow-lg shadow-slate-800/25 flex items-center justify-center group overflow-hidden relative">
                    <span id="btn-text" class="flex items-center">
                        Masuk ke Dashboard 
                        <i class="fa-solid fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                    </span>
                    <!-- Loading Spinner (Hidden by default) -->
                    <span id="btn-loader" class="hidden flex items-center justify-center">
                        <i class="fa-solid fa-circle-notch fa-spin text-lg mr-2.5"></i> Proses Login . . .
                    </span>
                </button>
            </form>
            
            <div class="mt-8 text-center md:text-left">
                <p class="text-xs text-slate-400 font-medium">&copy; <?= date('Y') ?> Created by Code from Hari.</p>
            </div>
        </div>
    </div>

    <script>
        // LOGIKA DROPDOWN AKUN
        function toggleDropdownAkun(e) {
            if(e) e.stopPropagation();
            const menu = document.getElementById('akun-menu');
            const icon = document.getElementById('akun-icon');
            const trigger = document.getElementById('akun-trigger');

            if (menu.classList.contains('invisible')) {
                // Buka Dropdown
                menu.classList.remove('invisible', 'opacity-0', 'scale-95');
                menu.classList.add('opacity-100', 'scale-100');
                icon.classList.add('rotate-180', 'text-slate-600');
                trigger.classList.add('border-slate-400', 'ring-4', 'ring-slate-500/20');
            } else {
                tutupDropdownAkun();
            }
        }

        function tutupDropdownAkun() {
            const menu = document.getElementById('akun-menu');
            const icon = document.getElementById('akun-icon');
            const trigger = document.getElementById('akun-trigger');

            if(menu && !menu.classList.contains('invisible')) {
                menu.classList.add('opacity-0', 'scale-95');
                menu.classList.remove('opacity-100', 'scale-100');
                icon.classList.remove('rotate-180', 'text-slate-600');
                trigger.classList.remove('border-slate-400', 'ring-4', 'ring-slate-500/20');
                
                // Tunggu animasi transisi sebelum benar-benar disembunyikan
                setTimeout(() => {
                    menu.classList.add('invisible');
                }, 200);
            }
        }

        function pilihAkun(username, nama, role, bgColor) {
            // 1. Isi form tersembunyi
            document.getElementById('form-username').value = username;

            // 2. Ubah Teks & Style Pemicu (Trigger)
            const textElem = document.getElementById('akun-text');
            const trigger = document.getElementById('akun-trigger');
            const avatar = document.getElementById('selected-avatar');
            
            trigger.classList.remove('text-slate-400');
            trigger.classList.add('text-slate-800');
            textElem.textContent = nama;

            // Ubah Avatar Placeholder menjadi Inisial
            avatar.className = `w-8 h-8 rounded-full ${bgColor} flex items-center justify-center shrink-0 font-black text-xs shadow-sm`;
            avatar.innerHTML = nama.charAt(0).toUpperCase();

            // 3. Aktifkan kolom password
            const passInput = document.getElementById('password');
            const btnEye = document.getElementById('btn-eye');
            passInput.disabled = false;
            btnEye.disabled = false;
            passInput.value = ''; // Kosongkan demi keamanan

            tutupDropdownAkun();
            
            // 4. Fokuskan langsung ke kolom password dengan sedikit jeda
            setTimeout(() => {
                passInput.focus();
            }, 100);
        }

        // Klik di luar area untuk menutup menu
        document.addEventListener('click', function(e) {
            const wrapper = document.getElementById('akun-wrapper');
            if (wrapper && !wrapper.contains(e.target)) {
                tutupDropdownAkun();
            }
        });

        // Fungsi Lihat/Sembunyikan Password
        function togglePassword() {
            const passInput = document.getElementById('password');
            const eyeIcon = document.getElementById('eye-icon');
            
            if (passInput.type === 'password') {
                passInput.type = 'text';
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash', 'text-slate-600');
            } else {
                passInput.type = 'password';
                eyeIcon.classList.remove('fa-eye-slash', 'text-slate-600');
                eyeIcon.classList.add('fa-eye');
            }
        }

        // Animasi Loading Tombol Submit
        function showLoadingState() {
            // Validasi manual agar spinner tidak muncul jika form belum lengkap
            const user = document.getElementById('form-username').value;
            const pass = document.getElementById('password').value;
            
            if (user !== '' && pass !== '') {
                const btnText = document.getElementById('btn-text');
                const btnLoader = document.getElementById('btn-loader');
                const btnLogin = document.getElementById('btn-login');
                
                btnText.classList.add('hidden');
                btnLoader.classList.remove('hidden');
                btnLogin.classList.add('pointer-events-none', 'bg-slate-900');
            }
        }
    </script>
</body>
</html>