<?php
session_start();
require '../config/koneksi.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    die("Akses Ditolak! Silakan login terlebih dahulu.");
}

// Menangkap ID transaksi dari URL
$id_trx = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$is_reprint = isset($_GET['reprint']) && $_GET['reprint'] == '1';

// Ambil data transaksi utama & nama kasir
$q_trx = mysqli_query($koneksi, "
    SELECT t.*, u.nama_lengkap 
    FROM transaksi t 
    JOIN users u ON t.id_user = u.id 
    WHERE t.id = $id_trx
");

if (mysqli_num_rows($q_trx) == 0) {
    die("Data transaksi tidak ditemukan!");
}
$trx = mysqli_fetch_assoc($q_trx);

// Ambil rincian detail barang yang dibeli
$q_dtl = mysqli_query($koneksi, "
    SELECT dt.*, b.nama_barang, b.harga AS harga_grosir_db, b.harga_eceran AS harga_eceran_db, b.harga_diskon AS harga_diskon_db, b.min_qty_diskon AS min_qty_db 
    FROM detail_transaksi dt 
    JOIN barang b ON dt.id_barang = b.id 
    WHERE dt.id_transaksi = $id_trx
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk TRX-<?= str_pad($id_trx, 5, '0', STR_PAD_LEFT) ?></title>
    <link rel="stylesheet" href="../assets/css/fonts.css">
    <style>
        /* CSS MURNI KHUSUS UNTUK KERTAS PRINTER THERMAL 58mm */
        @page { 
            margin: 0; 
            size: 58mm auto; 
        }
        
        body { 
            background: #fff; 
            margin: 0 auto; 
            /* MODIFIKASI: Menambahkan ruang kosong di atas (5mm) dan bawah (15mm) agar tidak terpotong */
            padding: 5mm 3mm 15mm 3mm; 
            width: 100%;
            max-width: 58mm; 
            color: #000; 
            font-family: 'Roboto', 'Helvetica Neue', Arial, sans-serif; 
            font-size: 10px;
            box-sizing: border-box;
            line-height: 1.2;
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: 700; }
        .font-black { font-weight: 900; }
        
        /* HEADER STRUK */
        h3 { font-size: 13px; margin: 0 0 2px 0; font-weight: 900; letter-spacing: 0.5px; }
        p { font-size: 9px; margin: 0 0 2px 0; font-weight: normal; line-height: 1.3; }
        
        .header-area { border-bottom: 1px; padding-bottom: 4px; margin-bottom: 4px; }
        
        /* TABEL BARANG */
        table { width: 100%; font-size: 10px; table-layout: fixed; border-collapse: collapse; margin-bottom: 2px; }
        th { border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 4px 0; font-weight: 900; text-align: left; }
        
        th.col-item { width: 50%; padding-right: 2px; }
        th.col-qty { text-align: center; width: 15%; }
        th.col-harga { text-align: right; width: 35%; }
        
        td { padding: 4px 0; vertical-align: top; word-wrap: break-word; font-weight: normal; }
        td.col-qty { text-align: center; font-weight: 700; }
        td.col-harga { text-align: right; }
        
        .nama-barang { margin-bottom: 2px; line-height: 1.2; }
        
        /* AREA TOTAL TAGIHAN */
        .flex-between { display: flex; justify-content: space-between; margin-bottom: 2px; }
        .total-row { display: flex; justify-content: space-between; padding-top: 3px; margin-bottom: 2px; }
        .dashed-top { border-top: 1px dashed #000; padding-top: 4px; margin-top: 2px; }
        
        /* FOOTER & CETAK ULANG */
        .footer-text { font-size: 9px; font-style: italic; text-align: center; margin-top: 4px; }
        .reprint-badge { font-size: 11px; font-weight: 900; text-align: center; margin-top: 5px; }
        
        /* HIDE PRINT BUTTON SAAT MENCETAK DARI KERTAS */
        @media print {
            #btn-print-manual { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="header-area text-center">
        <h3>TOKO SEMBAKO<br>"BERKAH BERSAMA"</h3>
        <p>Jln. Taman Alamanda Blok H7 No. 15<br>WhatsApp/Telp : 0856 4803 8353</p>
        <p>Waktu dibuat : <?= date('d/m/Y H:i', strtotime($trx['tanggal'])) ?></p>
        <!--p>Kasir : <?= htmlspecialchars($trx['nama_lengkap']) ?></p-->
        <p class="font-bold">TRX-<?= str_pad($id_trx, 5, '0', STR_PAD_LEFT) ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th class="col-item">Barang</th>
                <th class="col-qty">Qty</th>
                <th class="col-harga">Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php while($d = mysqli_fetch_assoc($q_dtl)): ?>
            <?php
            // Modifikasi: Defaultkan label Grosir (G) untuk semua. 
            // Ubah ke Eceran (E) JIKA harga transaksi cocok dengan harga eceran ATAU harga diskon eceran.
            $tipe_label = ' (G)';
            $h_transaksi = (int)$d['harga'];
            $qty_beli = (int)$d['qty'];
            $h_eceran_db = isset($d['harga_eceran_db']) ? (int)$d['harga_eceran_db'] : 0;
            $h_diskon_db = isset($d['harga_diskon_db']) ? (int)$d['harga_diskon_db'] : 0;
            $min_qty_db = isset($d['min_qty_db']) ? (int)$d['min_qty_db'] : 0;
            
            if ($h_eceran_db > 0) {
                if ($h_transaksi == $h_eceran_db) {
                    $tipe_label = ' (E)';
                } else if ($h_diskon_db > 0 && $h_transaksi == $h_diskon_db && $qty_beli >= $min_qty_db) {
                    $tipe_label = ' (E)'; // Tetap kenali sebagai Eceran jika mendapat potongan diskon qty
                }
            }
            ?>
            <tr>
                <td class="col-item">
                    <div class="nama-barang" style="text-transform: uppercase;">
                        <?= strtoupper(htmlspecialchars($d['nama_barang'])) . $tipe_label ?>
                    </div>
                    <div>@ <?= number_format($h_transaksi, 0, ',', '.') ?></div>
                </td>
                <td class="col-qty"><?= $d['qty'] ?></td>
                <td class="col-harga"><?= number_format($d['subtotal'], 0, ',', '.') ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php
    $grand_total = (int)$trx['total'];
    $diskon = isset($trx['diskon']) ? (int)$trx['diskon'] : 0;
    $subtotal = $grand_total + $diskon;
    $tunai = (int)$trx['tunai'];
    $kembalian = (int)$trx['kembalian'];
    
    // Logika pembacaan metode bayar untuk Struk
    $metode = isset($trx['metode']) ? strtolower($trx['metode']) : 'tunai';
    $teks_metode = ($metode == 'qris') ? 'QRIS' : 'Tunai';
    ?>
    <div style="margin-top: 4px;">
        <div class="flex-between dashed-top">
            <span>Subtotal :</span><span>Rp <?= number_format($subtotal, 0, ',', '.') ?></span>
        </div>
        <div class="flex-between">
            <span>Diskon :</span><span>- Rp <?= number_format($diskon, 0, ',', '.') ?></span>
        </div>
        
        <div class="flex-between dashed-top">
            <span>Total Tagihan :</span><span>Rp <?= number_format($grand_total, 0, ',', '.') ?></span>
        </div>

        <div class="flex-between">
            <span>Bayar ( <?= $teks_metode ?> ) :</span><span>Rp <?= number_format($tunai, 0, ',', '.') ?></span>
        </div>
        <div class="flex-between dashed-top">
            <span>Kembalian :</span><span>Rp <?= number_format($kembalian, 0, ',', '.') ?></span>
        </div>
        
        <div class="dashed-top">
            <p class="footer-text">Terima kasih atas kunjungan Anda. Barang yang sudah dibeli tidak dapat ditukar/dikembalikan jika sudah meninggalkan toko.</p>
            <?php if($is_reprint): ?>
            <p class="reprint-badge">*** CETAK ULANG ***</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Tombol manual jika fitur auto-print terblokir browser -->
    <button id="btn-print-manual" onclick="window.print()" style="margin-top: 20px; width: 100%; padding: 10px; background: #ec4899; color: white; border: none; font-weight: bold; border-radius: 5px; cursor: pointer;">Cetak Struk Sekarang</button>

    <script>
        // Otomatis memicu dialog printer sesaat setelah halaman ini dibuka
        window.onload = function() {
            window.print();
            
            // Event listener saat dialog print ditutup (baik diprint maupun dibatalkan)
            window.addEventListener('afterprint', function() {
                // Jika dibuka di dalam iframe tersembunyi (bukan tab baru)
                if (window.self !== window.top) {
                    // Panggil fungsi notifikasi di halaman utama (Kasir)
                    if (typeof window.parent.onPrintFinished === 'function') {
                        window.parent.onPrintFinished();
                    }
                } else {
                    // Jika terpaksa dibuka di tab baru, langsung tutup tabnya
                    window.close();
                }
            });
        }
    </script>
</body>
</html>