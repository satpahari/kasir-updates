<?php
session_start();
require '../config/koneksi.php';

// Pastikan hanya admin yang bisa melakukan backup
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Akses Ditolak!");
}

$tables = array();
$result = mysqli_query($koneksi, "SHOW TABLES");
while ($row = mysqli_fetch_row($result)) {
    $tables[] = $row[0];
}

$sqlScript = "";
$sqlScript .= "-- POS Berkah Bersama SQL Dump\n";
$sqlScript .= "-- Tanggal Backup: " . date('Y-m-d H:i:s') . "\n\n";
$sqlScript .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

foreach ($tables as $table) {
    // Dapatkan struktur tabel
    $query = "SHOW CREATE TABLE $table";
    $result = mysqli_query($koneksi, $query);
    $row = mysqli_fetch_row($result);
    
    $sqlScript .= "\n-- Struktur tabel untuk `$table`\n";
    $sqlScript .= "DROP TABLE IF EXISTS `$table`;\n";
    $sqlScript .= $row[1] . ";\n\n";
    
    // Dapatkan data tabel
    $query = "SELECT * FROM $table";
    $result = mysqli_query($koneksi, $query);
    $columnCount = mysqli_num_fields($result);
    
    if(mysqli_num_rows($result) > 0) {
        $sqlScript .= "-- Dumping data untuk tabel `$table`\n";
        
        // Membaca setiap baris data
        while ($row = mysqli_fetch_row($result)) {
            $sqlScript .= "INSERT INTO `$table` VALUES(";
            
            // Membaca setiap kolom dalam baris tersebut
            for ($j = 0; $j < $columnCount; $j++) {
                // PERBAIKAN: Mengganti '??' dengan metode isset() klasik agar support semua versi PHP
                $val = isset($row[$j]) ? $row[$j] : '';
                $val = addslashes($val);
                $val = str_replace("\n", "\\n", $val);
                
                $sqlScript .= '"' . $val . '"';
                
                if ($j < ($columnCount - 1)) {
                    $sqlScript .= ',';
                }
            }
            $sqlScript .= ");\n";
        }
        $sqlScript .= "\n";
    }
}

$sqlScript .= "SET FOREIGN_KEY_CHECKS=1;\n";

// Atur header agar browser mendownload file SQL
$backup_file_name = 'Backup_POS_Berkah_' . date('Y-m-d_H-i-s') . '.sql';
header('Content-Type: application/x-sql');
header('Content-Disposition: attachment; filename=' . $backup_file_name);
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

echo $sqlScript;
exit;
?>