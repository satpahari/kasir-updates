<?php
session_start();
require '../config/koneksi.php';

// Pastikan user sudah login dan HANYA ADMIN yang bisa mengakses
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Akses Ditolak! Hanya Administrator yang dapat mengelola akun.");
}

$aksi = isset($_POST['aksi']) ? $_POST['aksi'] : (isset($_GET['aksi']) ? $_GET['aksi'] : '');

if ($aksi == 'tambah') {
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $role = mysqli_real_escape_string($koneksi, $_POST['role']);
    $password_raw = $_POST['password'];
    
    // Cek apakah username sudah ada
    $cek_user = mysqli_query($koneksi, "SELECT id FROM users WHERE username = '$username'");
    if (mysqli_num_rows($cek_user) > 0) {
        header("Location: index.php?tab=akun&pesan=username_duplikat");
        exit;
    }

    // Enkripsi password baru
    $password_hash = password_hash($password_raw, PASSWORD_DEFAULT);

    $query = "INSERT INTO users (nama_lengkap, username, role, password) VALUES ('$nama_lengkap', '$username', '$role', '$password_hash')";
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?tab=akun&pesan=sukses_tambah_akun");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
} 
elseif ($aksi == 'edit') {
    $id = (int)$_POST['id'];
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $role = mysqli_real_escape_string($koneksi, $_POST['role']);
    $password_raw = $_POST['password'];

    // Cek apakah username dipakai orang lain
    $cek_user = mysqli_query($koneksi, "SELECT id FROM users WHERE username = '$username' AND id != $id");
    if (mysqli_num_rows($cek_user) > 0) {
        header("Location: index.php?tab=akun&pesan=username_duplikat");
        exit;
    }

    // Cek apakah password diubah atau dibiarkan kosong
    if (!empty($password_raw)) {
        // Jika diisi, update dengan password baru yang di-hash
        $password_hash = password_hash($password_raw, PASSWORD_DEFAULT);
        $query = "UPDATE users SET nama_lengkap = '$nama_lengkap', username = '$username', role = '$role', password = '$password_hash' WHERE id = $id";
    } else {
        // Jika kosong, update tanpa mengubah kolom password
        $query = "UPDATE users SET nama_lengkap = '$nama_lengkap', username = '$username', role = '$role' WHERE id = $id";
    }

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?tab=akun&pesan=sukses_edit_akun");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
} 
elseif ($aksi == 'hapus') {
    $id = (int)$_GET['id'];
    
    // Mencegah admin menghapus akunnya sendiri yang sedang aktif
    if ($id == $_SESSION['user_id']) {
        header("Location: index.php?tab=akun&pesan=error_hapus_sendiri");
        exit;
    }

    $query = "DELETE FROM users WHERE id = $id";
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?tab=akun&pesan=sukses_hapus_akun");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>