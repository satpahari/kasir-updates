<?php
session_start();
require '../config/koneksi.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    die("Akses Ditolak! Silakan login terlebih dahulu.");
}

// Menangkap nilai 'aksi' baik dari form POST maupun URL GET
$aksi = isset($_POST['aksi']) ? $_POST['aksi'] : (isset($_GET['aksi']) ? $_GET['aksi'] : '');

// PROTEKSI HAK AKSES KASIR:
if ($_SESSION['role'] !== 'admin' && ($aksi == 'edit' || $aksi == 'hapus')) {
    die("Akses Ditolak! Akun Kasir tidak memiliki izin untuk mengubah atau menghapus data barang.");
}

if ($aksi == 'tambah') {
    // Escaping input untuk menghindari SQL Injection
    $kode = mysqli_real_escape_string($koneksi, $_POST['kode']);
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $kategori = mysqli_real_escape_string($koneksi, $_POST['kategori']);
    $stok = (int)$_POST['stok'];
    $harga = (int)$_POST['harga'];
    
    // MENANGKAP HARGA ECERAN, KONVERSI, DAN STOK ECERAN
    $harga_eceran = isset($_POST['harga_eceran']) && $_POST['harga_eceran'] !== '' ? (int)$_POST['harga_eceran'] : 0;
    $konversi = isset($_POST['konversi']) && (int)$_POST['konversi'] > 0 ? (int)$_POST['konversi'] : 1;
    $stok_eceran = isset($_POST['stok_eceran']) && $_POST['stok_eceran'] !== '' ? (int)$_POST['stok_eceran'] : ($stok * $konversi);

    // PENAMBAHAN FITUR DISKON GROSIR BERTINGKAT (OTOMATIS)
    $min_qty_diskon = isset($_POST['min_qty_diskon']) ? (int)$_POST['min_qty_diskon'] : 0;
    $harga_diskon = isset($_POST['harga_diskon']) ? (int)str_replace('.', '', $_POST['harga_diskon']) : 0;

    // CEK KODE BARANG DUPLIKAT SAAT TAMBAH
    $cek_kode = mysqli_query($koneksi, "SELECT id FROM barang WHERE kode = '$kode'");
    if (mysqli_num_rows($cek_kode) > 0) {
        header("Location: index.php?tab=barang&pesan=kode_duplikat");
        exit;
    }

    // Default warna acak untuk kotak produk POS
    $warna_tersedia = ['bg-amber-800', 'bg-yellow-400', 'bg-blue-300', 'bg-orange-200', 'bg-red-500', 'bg-purple-400', 'bg-green-500'];
    $warna_bg = $warna_tersedia[array_rand($warna_tersedia)];

    // EKSEKUSI INSERT DENGAN DATA STOK GANDA DAN DISKON
    $query = "INSERT INTO barang (kode, nama_barang, kategori, stok, harga, harga_eceran, konversi, stok_eceran, min_qty_diskon, harga_diskon, warna_bg) 
              VALUES ('$kode', '$nama', '$kategori', '$stok', '$harga', '$harga_eceran', '$konversi', '$stok_eceran', '$min_qty_diskon', '$harga_diskon', '$warna_bg')";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?tab=barang&pesan=sukses_tambah");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
} 
elseif ($aksi == 'edit') {
    $id = (int)$_POST['id'];
    $kode = mysqli_real_escape_string($koneksi, $_POST['kode']);
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $kategori = mysqli_real_escape_string($koneksi, $_POST['kategori']);
    $stok = (int)$_POST['stok'];
    $harga = (int)$_POST['harga'];
    
    // MENANGKAP HARGA ECERAN, KONVERSI, DAN STOK ECERAN SAAT EDIT
    $harga_eceran = isset($_POST['harga_eceran']) && $_POST['harga_eceran'] !== '' ? (int)$_POST['harga_eceran'] : 0;
    $konversi = isset($_POST['konversi']) && (int)$_POST['konversi'] > 0 ? (int)$_POST['konversi'] : 1;
    $stok_eceran = isset($_POST['stok_eceran']) && $_POST['stok_eceran'] !== '' ? (int)$_POST['stok_eceran'] : ($stok * $konversi);

    // PENAMBAHAN FITUR DISKON GROSIR BERTINGKAT (OTOMATIS)
    $min_qty_diskon = isset($_POST['min_qty_diskon']) ? (int)$_POST['min_qty_diskon'] : 0;
    $harga_diskon = isset($_POST['harga_diskon']) ? (int)str_replace('.', '', $_POST['harga_diskon']) : 0;

    // CEK KODE BARANG DUPLIKAT SAAT EDIT
    $cek_kode = mysqli_query($koneksi, "SELECT id FROM barang WHERE kode = '$kode' AND id != $id");
    if (mysqli_num_rows($cek_kode) > 0) {
        header("Location: index.php?tab=barang&pesan=kode_duplikat");
        exit;
    }

    // EKSEKUSI UPDATE DENGAN DATA STOK GANDA
    $query = "UPDATE barang SET 
                kode = '$kode', 
                nama_barang = '$nama', 
                kategori = '$kategori', 
                stok = '$stok', 
                harga = '$harga',
                harga_eceran = '$harga_eceran',
                konversi = '$konversi',
                stok_eceran = '$stok_eceran',
                min_qty_diskon = '$min_qty_diskon',
                harga_diskon = '$harga_diskon'
              WHERE id = $id";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?tab=barang&pesan=sukses_edit");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
} 
elseif ($aksi == 'hapus') {
    $id = (int)$_GET['id'];
    
    // PERBAIKAN: Proteksi Hapus Barang
    // Cek apakah barang sudah memiliki riwayat di tabel detail_transaksi
    $cek_trx = mysqli_query($koneksi, "SELECT id FROM detail_transaksi WHERE id_barang = $id LIMIT 1");
    if(mysqli_num_rows($cek_trx) > 0) {
        // Jika sudah pernah terjual, batalkan penghapusan dan kirim pesan error
        header("Location: index.php?tab=barang&pesan=error_hapus_terpakai");
        exit;
    }

    $query = "DELETE FROM barang WHERE id = $id";
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?tab=barang&pesan=sukses_hapus");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>