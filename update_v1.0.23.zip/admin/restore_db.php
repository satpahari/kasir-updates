<?php
session_start();
require '../config/koneksi.php';

// Pastikan hanya admin yang bisa melakukan restore
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Akses Ditolak!");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['backup_file'])) {
    
    $file = $_FILES['backup_file']['tmp_name'];
    $file_name = $_FILES['backup_file']['name'];
    
    // Validasi ekstensi
    $ext = pathinfo($file_name, PATHINFO_EXTENSION);
    if(strtolower($ext) !== 'sql') {
        header("Location: index.php?tab=database&pesan=error_format");
        exit;
    }

    $sql = file_get_contents($file);
    if(empty($sql)) {
        header("Location: index.php?tab=database&pesan=error_kosong");
        exit;
    }

    // Eksekusi multi query
    if (mysqli_multi_query($koneksi, $sql)) {
        do {
            // Bersihkan hasil agar tidak terjadi error "Commands out of sync"
            if ($result = mysqli_store_result($koneksi)) {
                mysqli_free_result($result);
            }
        } while (mysqli_more_results($koneksi) && mysqli_next_result($koneksi));
        
        header("Location: index.php?tab=database&pesan=sukses_restore");
    } else {
        header("Location: index.php?tab=database&pesan=error_restore");
    }
} else {
    header("Location: index.php");
}
exit;
?>