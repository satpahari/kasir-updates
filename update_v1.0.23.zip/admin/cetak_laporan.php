<?php
session_start();
require '../config/koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    die("Akses ditolak. Silakan login terlebih dahulu.");
}

// Ambil parameter tanggal
// KEMBALIKAN KE 1 BULAN: Agar selaras jika dicetak secara manual (tombol Cetak PDF)
$tgl_awal = isset($_GET['tgl_awal']) ? $_GET['tgl_awal'] : date('Y-m-01');
$tgl_akhir = isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : date('Y-m-t');

// Ambil data transaksi
$query_transaksi = mysqli_query($koneksi, "
    SELECT t.*, u.nama_lengkap 
    FROM transaksi t 
    JOIN users u ON t.id_user = u.id 
    WHERE t.tanggal >= '$tgl_awal 00:00:00' AND t.tanggal <= '$tgl_akhir 23:59:59'
    ORDER BY t.tanggal ASC
");

// Array nama bulan untuk format Indonesia
$bulan_indo = [
    1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

function formatTanggalIndo($tanggal, $bulan_indo) {
    $pecahkan = explode('-', date('Y-m-d', strtotime($tanggal)));
    return $pecahkan[2] . ' ' . $bulan_indo[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
}

$periode_teks = formatTanggalIndo($tgl_awal, $bulan_indo) . " - " . formatTanggalIndo($tgl_akhir, $bulan_indo);
if ($tgl_awal == $tgl_akhir) {
    $periode_teks = formatTanggalIndo($tgl_awal, $bulan_indo);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan - <?= $periode_teks ?></title>
    <style>
        /* CSS Murni untuk memastikan hasil convert PDF di Google Drive sangat rapi */
        @page { size: A4 portrait; margin: 20mm; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: #222;
            font-size: 12px;
            line-height: 1.5;
            margin: 0;
            padding: 0;
            background-color: #fff;
        }
        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
        }
        
        /* HEADER (KOP SURAT) */
        .header {
            display: table;
            width: 100%;
            border-bottom: 3px solid #111;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .header-left {
            display: table-cell;
            vertical-align: bottom;
            width: 60%;
        }
        .header-right {
            display: table-cell;
            vertical-align: bottom;
            text-align: right;
            width: 40%;
        }
        .toko-title {
            font-size: 24px;
            font-weight: bold;
            text-transform: uppercase;
            margin: 0 0 5px 0;
            color: #111;
            letter-spacing: 1px;
        }
        .toko-address {
            font-size: 11px;
            color: #555;
            margin: 0;
            line-height: 1.4;
        }
        .report-title {
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            margin: 0 0 5px 0;
            color: #111;
        }
        .report-period {
            font-size: 12px;
            font-weight: bold;
            color: #444;
            margin: 0;
            background-color: #f0f0f0;
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
        }

        /* TABEL DATA */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            border: 1px solid #cbd5e1;
            padding: 10px 8px;
            vertical-align: middle;
        }
        th {
            background-color: #f8fafc;
            font-weight: bold;
            text-align: left;
            text-transform: uppercase;
            font-size: 10px;
            color: #475569;
            letter-spacing: 0.5px;
        }
        td { font-size: 11px; }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        
        .rincian-item { color: #555; font-size: 10px; line-height: 1.6; }
        .text-diskon { color: #db2777; font-weight: bold; }
        .metode-qris { color: #2563eb; } /* Warna biru untuk QRIS */
        .metode-tunai { color: #059669; } /* Warna hijau untuk Tunai */
        
        /* Baris Total */
        .total-row td {
            background-color: #f1f5f9;
            font-size: 13px;
            border-top: 2px solid #94a3b8;
        }

        /* FOOTER KETERANGAN PENCETAK DOKUMEN */
        .footer {
            display: table;
            width: 100%;
            margin-top: 20px;
        }
        .footer-left {
            display: table-cell;
            width: 60%;
            vertical-align: bottom;
            font-size: 10px;
            color: #64748b;
        }
        .footer-right {
            display: table-cell;
            width: 40%;
            vertical-align: bottom;
            text-align: right;
        }
        .printer-box {
            display: inline-block;
            text-align: right;
        }
        .printer-label {
            font-size: 10px;
            color: #64748b;
            margin-bottom: 4px;
        }
        .printer-name {
            font-size: 13px;
            font-weight: bold;
            color: #111;
            margin: 0 0 2px 0;
        }
        .printer-role {
            font-size: 10px;
            color: #64748b;
            text-transform: uppercase;
            margin: 0;
            letter-spacing: 0.5px;
        }
        
        /* Instruksi Print Browser (agar tabel tidak terpotong saat pindah halaman) */
        tr { page-break-inside: avoid; }
        thead { display: table-header-group; }
    </style>
</head>
<body>

<div class="container">
    <!-- HEADER -->
    <div class="header">
        <div class="header-left">
            <h1 class="toko-title">Toko Berkah Bersama</h1>
            <p class="toko-address">
                Ruko Jln. Taman Alamanda Blok H7 No. 15<br>
                WhatsApp/Telp: 0856 4803 8353
            </p>
        </div>
        <div class="header-right">
            <h2 class="report-title">Laporan Penjualan</h2>
            <p class="report-period">Periode: <?= $periode_teks ?></p>
        </div>
    </div>

    <!-- TABEL DATA -->
    <table>
        <thead>
            <tr>
                <th class="text-center" style="width: 4%;">No</th>
                <th class="text-center" style="width: 12%;">Waktu Transaksi</th>
                <th class="text-center" style="width: 12%;">ID Transaksi</th>
                <th class="text-center" style="width: 12%;">Kasir</th>
                <th class="text-center" style="width: 26%;">Rincian Barang</th>
                <th class="text-center" style="width: 9%;">Metode</th> <!-- KOLOM BARU -->
                <th class="text-center" style="width: 11%;">Diskon</th>
                <th class="text-center" style="width: 14%;">Total Belanja</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $grand_total = 0;
            
            if (mysqli_num_rows($query_transaksi) > 0) {
                while ($trx = mysqli_fetch_assoc($query_transaksi)) {
                    $grand_total += $trx['total'];
                    $diskon = isset($trx['diskon']) ? (int)$trx['diskon'] : 0;
                    
                    // Format Penamaan Metode Bayar
                    $jenis_bayar = isset($trx['metode']) ? strtolower($trx['metode']) : 'tunai';
                    $teks_metode = ($jenis_bayar == 'qris') ? 'QRIS' : 'TUNAI';
                    $class_metode = ($jenis_bayar == 'qris') ? 'metode-qris' : 'metode-tunai';
                    
                    // Ambil detail barang untuk transaksi ini
                    $id_trx = $trx['id'];
                    $q_detail = mysqli_query($koneksi, "
                        SELECT dt.qty, dt.harga, b.nama_barang, b.harga_eceran AS harga_eceran_db, b.harga_diskon AS harga_diskon_db, b.min_qty_diskon
                        FROM detail_transaksi dt 
                        JOIN barang b ON dt.id_barang = b.id 
                        WHERE dt.id_transaksi = $id_trx
                    ");
                    
                    $rincian_arr = [];
                    while ($dtl = mysqli_fetch_assoc($q_detail)) {
                        // MODIFIKASI: Defaultkan (G) untuk semua barang, ubah jadi (E) jika cocok dengan harga eceran atau harga diskon eceran
                        $tipe_label = ' (G)';
                        $h_eceran = isset($dtl['harga_eceran_db']) ? (int)$dtl['harga_eceran_db'] : 0;
                        $h_diskon = isset($dtl['harga_diskon_db']) ? (int)$dtl['harga_diskon_db'] : 0;
                        $min_qty = isset($dtl['min_qty_diskon']) ? (int)$dtl['min_qty_diskon'] : 0;
                        $h_beli = (int)$dtl['harga'];
                        $qty_beli = (int)$dtl['qty'];

                        if ($h_eceran > 0) {
                            if ($h_beli == $h_eceran) {
                                $tipe_label = ' (E)';
                            } elseif ($h_diskon > 0 && $h_beli == $h_diskon && $qty_beli >= $min_qty) {
                                $tipe_label = ' (E)';
                            }
                        }
                        $rincian_arr[] = $dtl['nama_barang'] . $tipe_label . " (" . $dtl['qty'] . ")";
                    }
                    $rincian_str = implode(", ", $rincian_arr);
                    ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= date('d/m/Y, H:i', strtotime($trx['tanggal'])) ?></td>
                        <td class="font-bold">TRX-<?= str_pad($trx['id'], 5, '0', STR_PAD_LEFT) ?></td>
                        <td><?= htmlspecialchars($trx['nama_lengkap']) ?></td>
                        <td class="rincian-item"><?= strtoupper($rincian_str) ?></td>
                        <td class="text-center font-bold <?= $class_metode ?>"><?= $teks_metode ?></td> <!-- DATA METODE BARU -->
                        <td class="text-right <?= $diskon > 0 ? 'text-diskon' : '' ?>">
                            <?= $diskon > 0 ? '- Rp ' . number_format($diskon, 0, ',', '.') : '-' ?>
                        </td>
                        <td class="text-right font-bold">Rp <?= number_format($trx['total'], 0, ',', '.') ?></td>
                    </tr>
                    <?php
                }
            } else {
                echo '<tr><td colspan="8" class="text-center" style="padding: 30px; color: #888;">Tidak ada data transaksi pada periode ini.</td></tr>';
            }
            ?>
            <!-- BARIS GRAND TOTAL -->
            <tr class="total-row">
                <td colspan="7" class="text-right font-bold" style="text-transform: uppercase;">Total Pendapatan Bersih</td>
                <td class="text-right font-bold" style="color: #db2777;">Rp <?= number_format($grand_total, 0, ',', '.') ?></td>
            </tr>
        </tbody>
    </table>

    <!-- FOOTER (KETERANGAN PENCETAK & TIMESTAMP) -->
    <div class="footer">
        <div class="footer-left">
            <i>Dokumen ini dibuat otomatis oleh sistem pada:<br> 
            <b><?= formatTanggalIndo(date('Y-m-d'), $bulan_indo) ?>, pukul <?= date('H:i') ?> WIB</b></i>
        </div>
        <div class="footer-right">
            <div class="printer-box">
                <div class="printer-label">Dicetak / Dikirim Oleh:</div>
                <!-- Mengambil nama dan role secara otomatis dari session yang sedang login -->
                <div class="printer-name"><?= htmlspecialchars($_SESSION['nama_lengkap']) ?></div>
                <div class="printer-role"><?= htmlspecialchars($_SESSION['role']) ?></div>
            </div>
        </div>
    </div>
</div>

<script>
    // Langsung memunculkan dialog print saat halaman dibuka (berlaku untuk mode Cetak Manual)
    // Script ini otomatis akan dihapus oleh regex di Javascript Kasir saat mode "Sync Drive"
    window.onload = function() {
        window.print();
    }
</script>
</body>
</html>