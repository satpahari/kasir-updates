<?php
session_start();
require '../config/koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// PROSES TAMBAH PENGELUARAN
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['aksi']) && $_POST['aksi'] == 'tambah') {
    $id_user = $_SESSION['user_id'];
    
    // Menangkap input tanggal lampau (backdate) atau gunakan waktu saat ini
    if (isset($_POST['tanggal']) && !empty($_POST['tanggal'])) {
        $raw_tanggal = $_POST['tanggal'];
        // Ubah format HTML datetime-local (YYYY-MM-DDTHH:MM) menjadi format MySQL (YYYY-MM-DD HH:MM:SS)
        $tanggal = str_replace('T', ' ', $raw_tanggal);
        // Tambahkan detik jika formatnya hanya sampai menit
        if (strlen($tanggal) == 16) {
            $tanggal .= ':00';
        }
        $tanggal = mysqli_real_escape_string($koneksi, $tanggal);
    } else {
        $tanggal = date('Y-m-d H:i:s');
    }

    $keterangan = mysqli_real_escape_string($koneksi, $_POST['keterangan']);
    // Hilangkan titik pada nominal (format uang)
    $nominal = (int)str_replace('.', '', $_POST['nominal']);

    $query = "INSERT INTO pengeluaran (id_user, tanggal, keterangan, nominal) VALUES ('$id_user', '$tanggal', '$keterangan', '$nominal')";
    
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?tab=pengeluaran&pesan=sukses_tambah_pengeluaran");
    } else {
        header("Location: index.php?tab=pengeluaran&pesan=error");
    }
    exit;
}

// PROSES HAPUS PENGELUARAN (HANYA ADMIN)
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus' && isset($_GET['id'])) {
    if ($_SESSION['role'] != 'admin') {
        die("Hanya admin yang bisa menghapus data pengeluaran!");
    }
    
    $id = (int)$_GET['id'];
    if (mysqli_query($koneksi, "DELETE FROM pengeluaran WHERE id = '$id'")) {
        header("Location: index.php?tab=pengeluaran&pesan=sukses_hapus_pengeluaran");
    } else {
        header("Location: index.php?tab=pengeluaran&pesan=error");
    }
    exit;
}

header("Location: index.php?tab=pengeluaran");
?>