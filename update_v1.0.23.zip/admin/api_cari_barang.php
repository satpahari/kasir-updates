<?php
session_start();
require '../config/koneksi.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(["error" => "Unauthorized"]));
}

header('Content-Type: application/json');

$keyword = isset($_GET['q']) ? mysqli_real_escape_string($koneksi, $_GET['q']) : '';

// Jika keyword kosong, tampilkan semua (atau dibatasi limit)
if (empty($keyword)) {
    // FITUR: Pastikan mengambil seluruh kolom harga dan diskon
    $query = mysqli_query($koneksi, "
        SELECT id, kode, nama_barang, kategori, stok, harga, harga_eceran, konversi, stok_eceran, min_qty_diskon, harga_diskon, warna_bg 
        FROM barang 
        ORDER BY stok DESC, nama_barang ASC 
        LIMIT 15
    ");
} else {
    // Jika ada keyword, cari berdasarkan kode (barcode) atau nama barang
    // FITUR: Pastikan mengambil seluruh kolom harga dan diskon
    $query = mysqli_query($koneksi, "
        SELECT id, kode, nama_barang, kategori, stok, harga, harga_eceran, konversi, stok_eceran, min_qty_diskon, harga_diskon, warna_bg 
        FROM barang 
        WHERE kode = '$keyword' OR nama_barang LIKE '%$keyword%' OR kode LIKE '%$keyword%'
        ORDER BY 
            CASE 
                WHEN kode = '$keyword' THEN 1 
                WHEN nama_barang LIKE '$keyword%' THEN 2 
                ELSE 3 
            END,
            stok DESC, nama_barang ASC 
        LIMIT 15
    ");
}

$data = [];
if ($query) {
    while ($row = mysqli_fetch_assoc($query)) {
        // Konversi dan validasi tipe data agar mudah dibaca Javascript (JSON)
        $row['id'] = (int)$row['id'];
        $row['stok'] = (int)$row['stok'];
        $row['harga'] = (int)$row['harga'];
        $row['harga_eceran'] = isset($row['harga_eceran']) ? (int)$row['harga_eceran'] : 0;
        $row['konversi'] = isset($row['konversi']) ? (int)$row['konversi'] : 1;
        $row['stok_eceran'] = isset($row['stok_eceran']) ? (int)$row['stok_eceran'] : ($row['stok'] * $row['konversi']);
        
        // MENYEDIAKAN DATA DISKON KE JAVASCRIPT KASIR
        $row['min_qty_diskon'] = isset($row['min_qty_diskon']) ? (int)$row['min_qty_diskon'] : 0;
        $row['harga_diskon'] = isset($row['harga_diskon']) ? (int)$row['harga_diskon'] : 0;
        
        $data[] = $row;
    }
}

echo json_encode($data);
?>