<!-- MODAL TAMBAH & EDIT BARANG -->
<div id="modal-barang" class="fixed inset-0 bg-slate-900/75 hidden z-[60] flex items-center justify-center transition-opacity">
    <div class="bg-white w-full max-w-lg p-6 rounded-3xl shadow-2xl relative animate-fade-in-up m-4 border border-gray-100 max-h-[95vh] flex flex-col">
        <div class="flex justify-between items-center mb-4 border-b border-gray-100 pb-4 shrink-0">
            <h3 id="modal-title" class="text-xl font-black text-gray-800">Form Barang</h3>
            <button type="button" onclick="tutupModalBarang()" class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800 transition"><i class="fa-solid fa-xmark"></i></button>
        </div>
        
        <form action="proses_barang.php" method="POST" class="flex flex-col flex-1 min-h-0" onsubmit="
            document.getElementById('form-harga').value = document.getElementById('form-harga').value.replace(/\./g, '');
            if(document.getElementById('form-harga-eceran')) {
                document.getElementById('form-harga-eceran').value = document.getElementById('form-harga-eceran').value.replace(/\./g, '');
            }
            if(document.getElementById('form-harga-diskon')) {
                document.getElementById('form-harga-diskon').value = document.getElementById('form-harga-diskon').value.replace(/\./g, '');
            }
        ">
            <div class="overflow-y-auto custom-scroll overscroll-contain p-1 pr-2 flex-1">
                <input type="hidden" name="aksi" id="form-aksi" value="tambah">
                <input type="hidden" name="id" id="form-id" value="">
                
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-1.5">Kode Barang</label>
                    <div class="flex gap-2">
                        <input type="text" name="kode" id="form-kode" required class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:bg-white hover:bg-white outline-none font-medium text-sm text-gray-800" autocomplete="off" placeholder="Scan atau buat kode barang otomatis">
                        
                        <button type="button" onclick="generateKode()" class="px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-500 hover:text-gray-700 border border-gray-200 hover:border-gray-300 rounded-xl transition shadow-sm flex items-center justify-center shrink-0 group" title="Buat Kode Otomatis">
                            <i class="fa-solid fa-pencil"></i>
                        </button>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-1.5">Nama Barang</label>
                    <input type="text" name="nama_barang" id="form-nama" required class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:bg-white hover:bg-white outline-none font-medium text-sm text-gray-800" autocomplete="off" placeholder="Masukkan nama barang">
                </div>

                <div class="mb-5" id="kategori-wrapper">
                    <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-1.5">Kategori (Jenis Barang)</label>
                    <div class="relative group">
                        <input type="text" name="kategori" id="form-kategori" required class="absolute inset-0 opacity-0 w-full h-full pointer-events-none z-[-1]" tabindex="-1">

                        <button type="button" id="kategori-trigger" onclick="toggleDropdownKategori(event)" class="w-full pl-4 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 hover:bg-white outline-none font-medium text-sm text-left flex items-center justify-between text-gray-400">
                            <span id="kategori-text" class="truncate">Pilih Kategori Barang</span>
                            <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none transition-colors duration-200 text-gray-400 group-focus-within:text-brand-500">
                                <i id="kategori-icon" class="fa-solid fa-chevron-down text-xs transition-transform duration-300"></i>
                            </div>
                        </button>

                        <div id="kategori-menu" class="absolute z-[70] w-full mt-2 bg-white border border-gray-100 rounded-xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1)] overflow-hidden py-1.5 opacity-0 invisible transform -translate-y-2 transition-all duration-75 ease-out origin-top">
                            <div class="px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 cursor-pointer" onclick="pilihKategori('Sembako')">Sembako</div>
                            <div class="px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 cursor-pointer" onclick="pilihKategori('Plastik')">Plastik</div>
                            <div class="px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 cursor-pointer" onclick="pilihKategori('Makanan')">Makanan</div>
                            <div class="px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 cursor-pointer" onclick="pilihKategori('Minuman')">Minuman</div>
                        </div>
                    </div>
                </div>
                
                <div class="p-4 bg-gray-50 border border-gray-200 rounded-2xl mb-5 transform-gpu">
                    <p class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3"><i class="fa-solid fa-box mr-1"></i> Data Barang Grosir</p>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-[11px] font-bold text-gray-600 mb-1.5">JUMLAH STOK</label>
                            <input type="number" name="stok" id="form-stok" required min="0" class="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 outline-none font-bold text-sm text-gray-800" oninput="hitungOtomatisEceran()">
                        </div>
                        <div>
                            <label class="block text-[11px] font-bold text-gray-600 mb-1.5">HARGA JUAL GROSIR</label>
                            <div class="flex items-stretch rounded-xl overflow-hidden border border-gray-200 bg-white focus-within:border-brand-500 focus-within:ring-2 focus-within:ring-brand-500 shadow-sm">
                                <span class="bg-gray-100 text-gray-500 font-bold text-sm px-3 flex items-center justify-center border-r border-gray-200">Rp</span>
                                <input type="text" inputmode="numeric" name="harga" id="form-harga" class="w-full px-3 py-2.5 bg-transparent outline-none font-bold text-sm text-gray-800" autocomplete="off" placeholder="-" oninput="formatInputUang(this)">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mb-5 bg-brand-50/40 border border-brand-200/80 rounded-2xl p-4 transition-all duration-300 transform-gpu">
                    <div class="flex items-center justify-between cursor-pointer" onclick="document.getElementById('toggle-eceran').click()">
                        <div class="pr-4">
                            <span class="block text-xs font-bold text-brand-700 uppercase tracking-wide"><i class="fa-solid fa-boxes-stacked mr-1"></i> Data Barang Eceran (Opsional)</span>
                            <span class="text-[10px] text-brand-600/70 block mt-1.5 leading-tight">Aktifkan untuk menjual barang ini dalam pecahan kecil (Pcs, Sachet, dll).</span>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer shrink-0" onclick="event.stopPropagation()">
                            <input type="checkbox" id="toggle-eceran" class="sr-only peer" onchange="toggleFormEceran()">
                            <div class="w-11 h-6 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-500 shadow-inner"></div>
                        </label>
                    </div>
                    
                    <div id="container-eceran" class="hidden mt-4 pt-4 border-t border-brand-200/50">
                        <div class="grid grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="block text-[11px] font-bold text-brand-700 uppercase mb-1.5">Isi Per 1 Grosir (Rasio)</label>
                                <div class="relative">
                                    <input type="number" name="konversi" id="form-konversi" value="1" min="1" class="w-full pl-4 pr-10 py-2.5 bg-white border border-brand-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 outline-none font-bold text-sm text-brand-700 shadow-sm" oninput="hitungOtomatisEceran()">
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-[11px] font-bold text-brand-400">Pcs</div>
                                </div>
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-brand-700 uppercase mb-1.5">Harga Jual Eceran</label>
                                <div class="flex items-stretch rounded-xl overflow-hidden border border-brand-200 bg-white shadow-sm focus-within:border-brand-500 focus-within:ring-2 focus-within:ring-brand-500">
                                    <span class="bg-brand-50 text-brand-600 font-bold text-sm px-3 flex items-center justify-center border-r border-brand-200">Rp</span>
                                    <input type="text" inputmode="numeric" name="harga_eceran" id="form-harga-eceran" placeholder="-" class="w-full px-3 py-2.5 bg-transparent outline-none font-bold text-sm text-gray-800" autocomplete="off" oninput="formatInputUang(this)">
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-white border border-brand-100 rounded-xl p-3 mb-4 flex items-center justify-between">
                            <div>
                                <p class="text-[11px] font-bold text-gray-500">Total Stok Eceran Tersedia :</p>
                                <p class="text-[11px] text-gray-400">(Stok Grosir x Rasio Konversi)</p>
                            </div>
                            <input type="number" name="stok_eceran" id="form-stok-eceran" value="0" min="0" class="w-24 px-3 py-1.5 bg-brand-50 border border-brand-200 rounded-lg text-brand-700 font-black text-right outline-none focus:border-brand-500 focus:ring-2">
                        </div>

                        <div class="p-4 bg-emerald-50 border border-emerald-100 rounded-xl">
                            <p class="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-3"><i class="fa-solid fa-tags mr-1"></i> Diskon Pembelian Eceran</p>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-[11px] font-bold text-emerald-600 mb-1.5">MINIMAL QTY PEMBELIAN</label>
                                    <input type="number" name="min_qty_diskon" id="form-min-qty-diskon" min="0" value="0" class="w-full px-4 py-2.5 bg-white border border-emerald-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 outline-none font-bold text-sm text-gray-800" placeholder="0">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-bold text-emerald-600 mb-1.5">HARGA SETELAH DISKON</label>
                                    <div class="flex items-stretch rounded-xl overflow-hidden border border-emerald-200 bg-white focus-within:border-brand-500 focus-within:ring-2 focus-within:ring-brand-500 shadow-sm">
                                        <span class="bg-emerald-100 text-emerald-600 font-bold text-sm px-3 flex items-center justify-center border-r border-emerald-200">Rp</span>
                                        <input type="text" inputmode="numeric" name="harga_diskon" id="form-harga-diskon" class="w-full px-3 py-2.5 bg-transparent outline-none font-bold text-sm text-gray-800" autocomplete="off" placeholder="-" oninput="formatInputUang(this)">
                                    </div>
                                </div>
                            </div>
                            <p class="text-[10px] text-emerald-600/80 mt-2 font-medium leading-relaxed">Otomatis memotong harga satuan eceran saat pelanggan mencapai batas minimum QTY pembelian barang.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="flex justify-end gap-3 pt-4 border-t border-gray-100 bg-white shrink-0 mt-2">
                <button type="button" onclick="tutupModalBarang()" class="px-6 py-2.5 bg-white border border-gray-300 text-gray-700 font-bold rounded-xl hover:bg-gray-50 transition text-sm shadow-sm">Batal</button>
                <button type="submit" class="px-6 py-2.5 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-800 shadow-gray-700/30 transition text-sm">Simpan Data</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL CHECKOUT PEMBAYARAN (Reguler Kasir) -->
<div id="modal-checkout" class="fixed inset-0 bg-slate-900/75 hidden z-[60] flex items-center justify-center transform-gpu">
    <div class="bg-white w-full max-w-lg p-6 sm:p-7 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 flex flex-col max-h-[95vh] transform-gpu">
        <h3 class="text-xl font-black mb-4 text-gray-800 text-center shrink-0">PROSES PEMBAYARAN</h3>
        
        <!-- PREVIEW PESANAN -->
        <div class="mb-4 bg-gray-50 border border-gray-200 rounded-2xl overflow-hidden flex flex-col min-h-0 shrink">
            <div class="px-4 py-2 bg-gray-200/50 border-b border-gray-200 text-[11px] font-bold text-gray-500 uppercase tracking-wider flex justify-between">
                <span>Item Pesanan</span>
                <span>Subtotal</span>
            </div>
            <div class="overflow-y-auto overscroll-contain max-h-56 p-2 custom-scroll">
                <table class="w-full text-sm">
                    <tbody id="checkout-item-list" class="divide-y divide-gray-100">
                    </tbody>
                </table>
            </div>
        </div>

        <!-- SUMMARY COMPACT -->
        <div class="mb-4 bg-brand-50 p-3 sm:px-4 sm:py-3 rounded-2xl border border-brand-100 shrink-0 flex items-center justify-between">
            <div class="flex flex-col gap-1.5 w-1/2 pr-3 sm:pr-4 border-r border-gray-400 border-line">
                <div class="flex justify-between text-xs font-bold text-gray-600">
                    <span>Subtotal</span><span id="checkout-subtotal">Rp 0</span>
                </div>
                <div class="flex justify-between text-xs font-bold text-red-500">
                    <span>Diskon</span><span id="checkout-diskon">Rp 0</span>
                </div>
            </div>
            <div class="w-1/2 pl-3 sm:pl-4 text-right">
                <p class="text-[10px] font-bold text-brand-600 uppercase tracking-widest mb-0.5">Total Tagihan</p>
                <p id="checkout-total-tagihan" class="text-2xl font-black text-gray-900 tracking-tight truncate">Rp 0</p>
            </div>
        </div>
        
        <!-- PILIHAN METODE BAYAR -->
        <div class="mb-4 shrink-0">
            <label class="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Metode Pembayaran</label>
            <div class="grid grid-cols-2 gap-3">
                <label class="cursor-pointer">
                    <input type="radio" name="metode_bayar" value="tunai" class="peer sr-only" checked onchange="toggleMetodeBayar()">
                    <div class="py-2.5 px-4 rounded-xl border-2 border-gray-200 peer-checked:border-brand-500 peer-checked:bg-brand-50 text-center font-bold text-gray-400 peer-checked:text-brand-700 transition flex items-center justify-center gap-2 shadow-sm">
                        <i class="fa-solid fa-money-bill-wave text-lg"></i>
                        <span class="text-xs">Tunai / Cash</span>
                    </div>
                </label>
                <label class="cursor-pointer">
                    <input type="radio" name="metode_bayar" value="qris" class="peer sr-only" onchange="toggleMetodeBayar()">
                    <div class="py-2.5 px-4 rounded-xl border-2 border-gray-200 peer-checked:border-brand-500 peer-checked:bg-brand-50 text-center font-bold text-gray-400 peer-checked:text-brand-700 transition flex items-center justify-center gap-2 shadow-sm">
                        <i class="fa-solid fa-qrcode text-lg"></i>
                        <span class="text-xs">QRIS / e-Wallet</span>
                    </div>
                </label>
            </div>
        </div>
        
        <!-- FORM TUNAI & KEMBALIAN -->
        <div id="container-tunai" class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5 shrink-0 transition-all">
            <div>
                <label class="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Uang Diterima</label>
                <div class="flex items-stretch rounded-xl overflow-hidden border border-gray-200 bg-white focus-within:border-brand-500 focus-within:ring-2 focus-within:ring-brand-500 shadow-sm">
                    <span class="bg-gray-100 text-gray-500 font-bold text-lg px-3 flex items-center justify-center border-r border-gray-200">Rp</span>
                    <input type="text" inputmode="numeric" id="input-bayar" class="w-full px-3 py-2 bg-transparent focus:outline-none text-xl font-black text-gray-900 m-0" autocomplete="off" placeholder="0" oninput="formatInputUang(this); hitungKembalian()">
                </div>
            </div>
            
            <div>
                <label class="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Kembalian</label>
                <div class="flex items-stretch rounded-xl overflow-hidden border border-gray-200 shadow-sm bg-gray-50">
                    <span class="bg-gray-200 text-gray-600 font-bold text-lg px-3 flex items-center justify-center border-r border-gray-200">Rp</span>
                    <input type="text" id="input-kembalian" class="w-full px-3 py-2 bg-transparent text-xl font-black text-gray-800 outline-none cursor-not-allowed text-right" value="0" readonly>
                </div>
            </div>
        </div>
        
        <div class="flex flex-col sm:flex-row justify-end gap-3 pt-4 border-t border-gray-100 shrink-0">
            <button type="button" onclick="tutupModalCheckout()" class="px-6 py-2.5 bg-white border border-gray-300 text-gray-700 font-bold rounded-xl hover:bg-gray-50 transition w-full sm:w-auto shadow-sm text-sm">Batal</button>
            <button type="button" id="btn-konfirmasi-bayar" onclick="konfirmasiPembayaran()" class="px-6 py-2.5 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-800 transition cursor-not-allowed w-full text-sm" disabled>Simpan & Cetak Struk</button>
        </div>
    </div>
</div>

<!-- MODAL DETAIL TRANSAKSI & CETAK ULANG -->
<div id="modal-detail-trx" class="fixed inset-0 bg-slate-900/75 hidden z-[60] flex items-center justify-center transform-gpu">
    <div class="bg-white w-full max-w-lg p-6 sm:p-8 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 transform-gpu">
        <div class="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
            <h3 class="text-xl font-black text-gray-800">Detail <span id="dtl-id" class="text-brand-600"></span></h3>
            <button onclick="tutupDetailTrx()" class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800 transition"><i class="fa-solid fa-xmark"></i></button>
        </div>
        
        <div class="mb-5 text-sm text-gray-600 grid grid-cols-2 sm:grid-cols-3 gap-3 bg-gray-50 p-4 rounded-xl border border-gray-100">
            <div class="col-span-2 sm:col-span-1"><span class="font-bold text-xs text-gray-400 uppercase tracking-wider block mb-0.5">Waktu :</span> <span id="dtl-tgl" class="font-semibold text-gray-800"></span></div>
            <div><span class="font-bold text-xs text-gray-400 uppercase tracking-wider block mb-0.5">Kasir :</span> <span id="dtl-kasir" class="font-semibold text-gray-800"></span></div>
            <div><span class="font-bold text-xs text-gray-400 uppercase tracking-wider block mb-0.5">Pembayaran :</span> <span id="dtl-metode" class="font-bold text-brand-600"></span></div>
        </div>

        <div class="max-h-56 overflow-y-auto overscroll-contain border border-gray-200 rounded-xl mb-5 shadow-inner bg-white custom-scroll">
            <table class="w-full text-sm text-left">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider sticky top-0">
                    <tr>
                        <th class="px-4 py-3 font-bold border-b border-gray-200">Barang</th>
                        <th class="px-4 py-3 font-bold border-b border-gray-200 text-center">Qty</th>
                        <th class="px-4 py-3 font-bold border-b border-gray-200 text-right">Subtotal</th>
                    </tr>
                </thead>
                <tbody id="dtl-items" class="divide-y divide-gray-100"></tbody>
            </table>
        </div>

        <div class="bg-gray-50 p-4 rounded-xl border border-gray-200 mb-6">
            <div class="flex justify-between items-center mb-1 text-sm text-gray-500 font-medium">
                <span>Subtotal :</span>
                <span id="dtl-subtotal" class="text-gray-800 font-bold"></span>
            </div>
            <div class="flex justify-between items-center mb-2 pb-2 border-b border-gray-200 border-dashed text-sm text-red-500 font-medium">
                <span>Diskon :</span>
                <span id="dtl-diskon" class="font-bold"></span>
            </div>
            <div class="flex justify-between items-center mb-2 pb-2 border-b border-gray-200 border-dashed">
                <span class="font-bold text-gray-600 text-sm">Total Tagihan :</span>
                <span id="dtl-total" class="font-black text-xl text-brand-600"></span>
            </div>
            <div class="flex justify-between items-center mb-1 text-sm text-gray-500 font-medium">
                <span>Jumlah Bayar :</span>
                <span id="dtl-tunai" class="text-gray-800 font-bold"></span>
            </div>
            <div class="flex justify-between items-center text-sm text-gray-500 font-medium">
                <span>Kembalian :</span>
                <span id="dtl-kembalian" class="text-gray-800 font-bold"></span>
            </div>
        </div>
        
        <div class="flex flex-col sm:flex-row justify-end gap-3 pt-2">
            <button type="button" onclick="tutupDetailTrx()" class="px-6 py-2.5 bg-white border border-gray-300 text-gray-700 font-bold rounded-xl hover:bg-gray-50 transition shadow-sm w-full sm:w-auto text-sm">Tutup</button>
            <button type="button" id="btn-cetak-ulang" onclick="triggerCetakUlang()" class="px-6 py-2.5 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-800 transition flex items-center justify-center w-full sm:w-auto text-sm">
                <i class="fa-solid fa-print mr-2"></i> Cetak Ulang Struk
            </button>
        </div>
    </div>
</div>

<!-- MODAL PENGATURAN GOOGLE DRIVE -->
<div id="modal-gdrive" class="fixed inset-0 bg-slate-900/75 hidden z-[80] flex items-center justify-center transform-gpu">
    <div class="bg-white w-full max-w-md p-6 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 transform-gpu">
        <div class="flex justify-between items-center mb-5 border-b border-gray-100 pb-4">
            <h3 class="text-xl font-black text-gray-800 flex items-center">
                <i class="fa-brands fa-google-drive text-green-500 mr-2 text-2xl"></i> Setting URL Web App
            </h3>
            <button onclick="tutupModalDrive()" class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800 transition"><i class="fa-solid fa-xmark"></i></button>
        </div>

        <div class="mb-5">
            <p class="text-xs text-blue-700 mb-4 bg-blue-50 p-3 rounded-xl border border-blue-100 leading-relaxed font-medium">
                Masukkan <b>URL Web App</b> dari Google App Script Anda agar sistem dapat mengirimkan laporan PDF secara otomatis ke Google Drive.
            </p>
            <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-2">URL Google App Script</label>
            <div class="relative focus-within:text-green-500 text-gray-400">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none transition-colors">
                    <i class="fa-solid fa-link"></i>
                </div>
                <input type="url" id="input-gas-url" placeholder="https://script.google.com/macros/s/..." class="w-full pl-9 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-500 focus:ring-4 focus:ring-green-500/10 focus:bg-white shadow-sm font-medium text-sm text-gray-800">
            </div>
        </div>

        <div class="flex flex-col sm:flex-row justify-between gap-3 pt-4 border-t border-gray-100">
            <button type="button" id="btn-hapus-url" onclick="hapusUrlDrive()" class="px-5 py-2.5 bg-red-50 text-red-500 font-bold rounded-xl hover:bg-red-500 hover:text-white transition text-sm hidden border border-red-100 w-full sm:w-auto">Hapus Link</button>
            <div class="flex gap-2 w-full sm:w-auto justify-end flex-1">
                <button type="button" onclick="tutupModalDrive()" class="px-5 py-2.5 bg-white border border-gray-300 text-gray-700 font-bold rounded-xl hover:bg-gray-50 transition text-sm w-full sm:w-auto">Batal</button>
                <button type="button" onclick="simpanUrlDrive()" class="px-5 py-2.5 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-800 shadow-gray-700/30 transition text-sm w-full sm:w-auto">Simpan</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL TAMBAH & EDIT AKUN -->
<div id="modal-akun" class="fixed inset-0 bg-slate-900/75 hidden z-[60] flex items-center justify-center transform-gpu">
    <div class="bg-white w-full max-w-md p-6 sm:p-8 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 transform-gpu">
        <div class="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
            <h3 id="modal-title-akun" class="text-xl font-black text-gray-800">Form Akun</h3>
            <button type="button" onclick="tutupModalAkun()" class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800 transition"><i class="fa-solid fa-xmark"></i></button>
        </div>
        
        <form action="proses_akun.php" method="POST">
            <input type="hidden" name="aksi" id="form-aksi-akun" value="tambah">
            <input type="hidden" name="id" id="form-id-akun" value="">
            
            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-1.5">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" id="form-nama-akun" required class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:bg-white hover:bg-white outline-none font-medium text-sm text-gray-800" autocomplete="off" placeholder="Masukkan nama kasir">
            </div>

            <div class="mb-4">
                <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-1.5">Username Login</label>
                <input type="text" name="username" id="form-username-akun" required class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:bg-white hover:bg-white outline-none font-medium text-sm text-gray-800" autocomplete="off" placeholder="Masukkan username login">
            </div>

            <div class="mb-4" id="role-wrapper">
                <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-1.5">Hak Akses (Role)</label>
                <div class="relative group">
                    <input type="text" name="role" id="form-role-akun" required class="absolute inset-0 opacity-0 w-full h-full pointer-events-none z-[-1]" tabindex="-1">

                    <button type="button" id="role-trigger" onclick="toggleDropdownRole(event)" class="w-full pl-4 pr-10 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 hover:bg-white outline-none font-medium text-sm text-left flex items-center justify-between text-gray-800">
                        <span id="role-text" class="truncate">Petugas Kasir</span>
                        <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none transition-colors duration-200 text-gray-400 group-focus-within:text-brand-500">
                            <i id="role-icon" class="fa-solid fa-chevron-down text-xs transition-transform duration-300"></i>
                        </div>
                    </button>

                    <div id="role-menu" class="absolute z-[70] w-full mt-2 bg-white border border-gray-100 rounded-xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1)] overflow-hidden py-1.5 opacity-0 invisible transform -translate-y-2 transition-all duration-75 ease-out origin-top">
                        <div class="px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 cursor-pointer" onclick="pilihRole('kasir', 'Petugas Kasir')">Petugas Kasir</div>
                        <div class="px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 cursor-pointer" onclick="pilihRole('admin', 'Administrator')">Administrator</div>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <div class="flex justify-between items-center mb-1.5">
                    <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide">Password</label>
                    <span id="password-hint" class="text-[10px] font-bold text-brand-500 hidden bg-brand-50 px-2 py-0.5 rounded border border-brand-100">Kosongkan jika tak diubah</span>
                </div>
                <input type="password" name="password" id="form-password-akun" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:bg-white hover:bg-white outline-none font-medium text-sm text-gray-800 tracking-wider" autocomplete="off" placeholder="•••••••••••">
            </div>
            
            <div class="flex justify-end gap-3 pt-4 border-t border-gray-100">
                <button type="button" onclick="tutupModalAkun()" class="px-6 py-3 bg-white border border-gray-300 text-gray-700 font-bold rounded-xl hover:bg-gray-50 transition text-sm shadow-sm w-full sm:w-auto">Batal</button>
                <button type="submit" class="px-6 py-3 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-800 shadow-gray-700/30 transition text-sm w-full sm:w-auto">Simpan Data</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL KONFIRMASI GLOBAL (CUSTOM ALERT) -->
<div id="modal-konfirmasi" class="fixed inset-0 bg-slate-900/75 hidden z-[90] flex items-center justify-center transform-gpu">
    <div class="bg-white w-full max-w-sm p-6 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 text-center transform-gpu">
        <div class="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center text-3xl mx-auto mb-4 border-4 border-red-100">
            <i class="fa-solid fa-triangle-exclamation"></i>
        </div>
        <h3 class="text-xl font-black text-gray-800 mb-2">Konfirmasi</h3>
        <p id="teks-konfirmasi" class="text-sm text-gray-500 mb-6 leading-relaxed">Apakah Anda yakin ingin melanjutkan aksi ini?</p>
        <div class="flex gap-3 justify-center">
            <button type="button" onclick="tutupModalKonfirmasi()" class="px-5 py-2.5 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition text-sm w-full">Batal</button>
            <button type="button" id="btn-eksekusi-konfirmasi" class="px-5 py-2.5 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 shadow-red-500/30 transition text-sm w-full">Ya, Lanjutkan</button>
        </div>
    </div>
</div>

<!-- MODAL UPLOAD CSV -->
<div id="modal-upload-csv" class="fixed inset-0 bg-slate-900/75 hidden z-[65] flex items-center justify-center transform-gpu">
    <div class="bg-white w-full max-w-md p-6 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 transform-gpu">
        <div class="flex justify-between items-center mb-4 border-b border-gray-100 pb-4">
            <h3 class="text-xl font-black text-gray-800">IMPORT DATA BARANG</h3>
            <button type="button" onclick="tutupModalUploadCsv()" class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800 transition"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form action="proses_import.php" method="POST" enctype="multipart/form-data" class="flex flex-col gap-4">
            <div class="bg-blue-50 text-blue-700 p-4 rounded-xl text-xs leading-relaxed border border-blue-100">
                <p class="font-bold mb-1"><i class="fa-solid fa-circle-info mr-1"></i> Format Kolom CSV yang dibutuhkan:</p>
                <p class="font-mono bg-white px-2 py-1.5 rounded border border-blue-200 mt-2 font-bold text-center">Kode Barang, Nama Barang, Kategori, Stok Grosir, Harga Grosir, Harga Eceran, Konversi</p>
                <ul class="list-disc pl-4 mt-3 space-y-1">
                    <li>Baris pertama (header judul kolom) akan <b>diabaikan</b> otomatis.</li>
                    <li>Warna background ikon <i class="fa-solid fa-palette text-blue-500 mx-1"></i> akan dibuat acak oleh sistem.</li>
                    <li>Harga & Stok gunakan format angka bulat (tanpa titik).</li>
                    <li>Jika barang tidak dijual eceran, isi <i>Harga Eceran</i> & <i>Konversi</i> dengan angka <b class="text-blue-800">0</b>.</li>
                </ul>
            </div>
            <div class="mt-2">
                <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Pilih File .CSV Anda</label>
                <input type="file" name="file_csv" accept=".csv" required class="block w-full text-sm text-gray-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-bold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition">
            </div>
            <div class="mt-2 flex gap-3 pt-4 border-t border-gray-100">
                <button type="button" onclick="tutupModalUploadCsv()" class="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition text-sm">Batal</button>
                <button type="submit" class="flex-1 py-3 bg-gray-600 text-white font-bold rounded-xl hover:bg-gray-700 shadow-gray-600/30 transition text-sm flex items-center justify-center">
                    Upload Data
                </button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL SYNC LAPORAN -->
<div id="modal-sync" class="fixed inset-0 bg-slate-900/75 hidden z-[80] flex items-center justify-center transition-opacity">
    <div class="bg-white w-full max-w-md p-6 sm:p-7 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 flex flex-col transition-all duration-300">
        <div class="flex justify-between items-center mb-5 border-b border-gray-100 pb-4 shrink-0">
            <h3 class="text-xl font-black text-gray-800 flex items-center">
                <i class="fa-solid fa-cloud-arrow-up text-brand-500 mr-2"></i> SYNC LAPORAN
            </h3>
            <button onclick="tutupModalSync()" id="btn-close-sync" class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800 transition"><i class="fa-solid fa-xmark"></i></button>
        </div>
        
        <div id="form-sync-container" class="mb-2">
            <p class="text-sm text-gray-500 mb-5 leading-relaxed">
                Silahkan pilih tanggal laporan penjualan yang ingin anda sinkronisasi dan kirimkan ke sistem cloud.
            </p>
            <label class="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Pilih Tanggal Laporan</label>
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <i class="fa-regular fa-calendar"></i>
                </div>
                <input type="date" id="input-tgl-sync" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 shadow-sm font-medium text-sm text-gray-800" value="">
            </div>
        </div>

        <div id="sync-progress-container" class="hidden py-4 w-full">
            <div class="flex justify-between items-center mb-3">
                <span id="sync-status-text" class="text-sm font-bold text-brand-600 animate-pulse">Menghubungkan ke server...</span>
                <span id="sync-percentage" class="text-base font-black text-gray-800">0%</span>
            </div>
            <div class="w-full bg-gray-100 rounded-full h-4 shadow-inner overflow-hidden border border-gray-200 p-[2px]">
                <div id="sync-progress-bar" class="bg-gray-800 h-full rounded-full transition-all duration-300 ease-out" style="width: 0%"></div>
            </div>
        </div>

        <div class="flex gap-3 pt-5 mt-4 border-t border-gray-100" id="sync-action-buttons">
            <button type="button" onclick="tutupModalSync()" class="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition text-sm">Batal</button>
            <button type="button" id="btn-eksekusi-sync" onclick="prosesModalSync()" class="flex-1 py-3 bg-gray-700 text-white font-bold rounded-xl hover:bg-gray-800 shadow-gray-700/30 transition text-sm flex items-center justify-center">
                <i class="fa-solid fa-cloud-arrow-up mr-2"></i> Proses Sync
            </button>
        </div>
    </div>
</div>

<!-- MODAL CATAT PENGELUARAN -->
<div id="modal-pengeluaran" class="fixed inset-0 bg-slate-900/75 hidden z-[60] flex items-center justify-center transform-gpu transition-opacity">
    <div class="bg-white w-full max-w-md p-6 sm:p-8 rounded-3xl shadow-xl relative animate-fade-in-up m-4 border border-gray-100 transform-gpu">
        <div class="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
            <h3 class="text-xl font-black text-gray-800 flex items-center">
                CATAT PENGELUARAN
            </h3>
            <button type="button" onclick="tutupModalPengeluaran()" class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-800 transition"><i class="fa-solid fa-xmark"></i></button>
        </div>
        
        <form action="proses_pengeluaran.php" method="POST">
            <input type="hidden" name="aksi" value="tambah">
            
            <div class="mb-5">
                <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-2">Keperluan Pengeluaran</label>
                <textarea name="keterangan" required class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-rose-500 focus:ring-2 focus:ring-rose-500 focus:bg-white hover:bg-white outline-none font-medium text-sm text-gray-800 h-24 resize-none" placeholder="Contoh: Bayar listrik, Uang makan, Belanja barang..."></textarea>
            </div>

            <!-- TAMBAHAN: Input Tanggal Pengeluaran Lampau (Backdate) -->
            <div class="mb-6">
                <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-2">Tanggal Pengeluaran <span class="text-gray-400 font-medium normal-case ml-1">(Ubah jika transaksi lampau)</span></label>
                <div class="relative">
                    <input type="datetime-local" name="tanggal" id="form-tanggal-pengeluaran" required class="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 font-bold text-gray-700 text-sm shadow-sm cursor-pointer hover:bg-gray-50 transition">
                </div>
            </div>
            <!-- AKHIR TAMBAHAN -->

            <div class="mb-6">
                <label class="block text-xs font-bold text-gray-600 uppercase tracking-wide mb-2">Nominal Biaya Pengeluaran</label>
                <div class="flex items-stretch rounded-xl overflow-hidden border border-gray-200 bg-white focus-within:border-rose-500 focus-within:ring-2 focus-within:ring-rose-500 shadow-sm">
                    <span class="bg-gray-100 text-gray-500 font-bold text-base px-4 flex items-center justify-center border-r border-gray-200">Rp</span>
                    <input type="text" inputmode="numeric" name="nominal" id="form-nominal-pengeluaran" required class="w-full px-4 py-3 bg-transparent outline-none font-black text-lg text-rose-600" autocomplete="off" placeholder="0" oninput="formatInputUang(this)">
                </div>
            </div>
            
            <div class="flex justify-end gap-3 pt-4 border-t border-gray-100">
                <button type="button" onclick="tutupModalPengeluaran()" class="px-6 py-3 bg-white border border-gray-300 text-gray-700 font-bold rounded-xl hover:bg-gray-50 transition text-sm shadow-sm w-full sm:w-auto">Batal</button>
                <button type="submit" class="px-6 py-3 bg-rose-600 text-white font-bold rounded-xl hover:bg-rose-700 shadow-rose-600/30 transition text-sm w-full sm:w-auto">Simpan</button>
            </div>
        </form>
    </div>
</div>