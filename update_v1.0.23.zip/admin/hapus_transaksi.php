<?php
session_start();
require '../config/koneksi.php';

// KEAMANAN: Pastikan hanya ADMIN yang bisa mengeksekusi penghapusan
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Akses Ditolak! Hanya Administrator yang dapat menghapus transaksi.");
}

if (isset($_GET['id'])) {
    $id_trx = (int)$_GET['id'];

    // 1. AMBIL DETAIL BARANG UNTUK MENGEMBALIKAN STOK
    $q_detail = mysqli_query($koneksi, "SELECT id_barang, qty, harga FROM detail_transaksi WHERE id_transaksi = '$id_trx'");

    while ($row = mysqli_fetch_assoc($q_detail)) {
        $id_barang = $row['id_barang'];
        $qty_kembali = (int)$row['qty'];
        $harga_jual = (int)$row['harga']; 

        // Cek data barang saat ini di database
        $q_brg = mysqli_query($koneksi, "SELECT stok, stok_eceran, konversi, harga, harga_eceran, harga_diskon, min_qty_diskon FROM barang WHERE id = '$id_barang'");
        
        if ($brg = mysqli_fetch_assoc($q_brg)) {
            $stok_grosir = (int)$brg['stok'];
            $stok_eceran = (int)$brg['stok_eceran'];
            $konversi = (int)$brg['konversi'] > 0 ? (int)$brg['konversi'] : 1;

            // Deteksi Logika: Apakah waktu itu barang ini dijual secara Eceran atau Grosir?
            $is_eceran = false;
            if ($brg['harga_eceran'] > 0) {
                if ($harga_jual == $brg['harga_eceran']) {
                    $is_eceran = true;
                } elseif ($brg['harga_diskon'] > 0 && $harga_jual == $brg['harga_diskon'] && $qty_kembali >= $brg['min_qty_diskon']) {
                    $is_eceran = true;
                }
            }

            // PROSES PENGEMBALIAN STOK (RESTORE)
            if ($is_eceran) {
                // Jika terjual eceran, kembalikan stok eceran, lalu sinkronkan ulang stok grosirnya
                $stok_eceran_baru = $stok_eceran + $qty_kembali;
                $stok_grosir_baru = floor($stok_eceran_baru / $konversi);
            } else {
                // Jika terjual grosir, kembalikan stok grosir, lalu sinkronkan stok ecerannya
                $stok_grosir_baru = $stok_grosir + $qty_kembali;
                $stok_eceran_baru = $stok_eceran + ($qty_kembali * $konversi);
            }

            // Simpan stok yang sudah dipulihkan kembali ke database barang
            mysqli_query($koneksi, "UPDATE barang SET stok = '$stok_grosir_baru', stok_eceran = '$stok_eceran_baru' WHERE id = '$id_barang'");
        }
    }

    // 2. HAPUS DATA DARI TABEL DETAIL TRANSAKSI
    mysqli_query($koneksi, "DELETE FROM detail_transaksi WHERE id_transaksi = '$id_trx'");

    // 3. HAPUS DATA DARI TABEL TRANSAKSI UTAMA
    mysqli_query($koneksi, "DELETE FROM transaksi WHERE id = '$id_trx'");

    // Redirect kembali ke halaman laporan dengan parameter pesan sukses
    header("Location: index.php?tab=rekap&pesan=hapus_sukses");
    exit;
} else {
    header("Location: index.php?tab=rekap");
    exit;
}
?>