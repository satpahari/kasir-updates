<?php
session_start();
// Sesuaikan '../config/koneksi.php' jika lokasi file koneksi Anda berbeda
require '../config/koneksi.php'; 

// Proteksi: Hanya administrator yang boleh meng-import data massal
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file_csv'])) {
    $filename = $_FILES['file_csv']['name'];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    
    // Cegah upload file palsu (hanya izinkan CSV)
    if (strtolower($ext) !== 'csv') {
        header("Location: index.php?tab=barang&pesan=error_import_ekstensi");
        exit;
    }
    
    // Buka file yang diunggah dalam mode Read (Membaca)
    $file = fopen($_FILES['file_csv']['tmp_name'], "r");
    
    if ($file !== FALSE) {
        // Lewati baris pertama (biasanya dipakai untuk penamaan Header / Judul Kolom di Excel)
        fgetcsv($file, 1000, ",");
        
        // Daftar palet warna Tailwind yang disiapkan oleh sistem
        $warna_pilihan = [
            'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-amber-500', 
            'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500', 
            'bg-orange-500', 'bg-cyan-500', 'bg-rose-500', 'bg-emerald-500'
        ];
        
        // Looping pembacaan baris demi baris dari dokumen CSV
        while (($data = fgetcsv($file, 1000, ",")) !== FALSE) {
            
            // Validasi: Lewati iterasi jika barisnya terdeteksi kosong
            if (count($data) < 2 || empty($data[0])) continue;
            
            // Pemetakan Kolom Berdasarkan Format (0=Kode, 1=Nama, 2=Kategori, 3=Stok, 4=Harga, 5=HargaEceran, 6=Konversi)
            $kode = mysqli_real_escape_string($koneksi, trim($data[0]));
            $nama = mysqli_real_escape_string($koneksi, trim($data[1]));
            $kategori = isset($data[2]) ? mysqli_real_escape_string($koneksi, trim($data[2])) : 'Lainnya';
            
            // Konversi nilai numerik (Pembersihan agar tidak ada spasi terselubung)
            $stok = isset($data[3]) ? (int)$data[3] : 0;
            $harga_grosir = isset($data[4]) ? (int)$data[4] : 0;
            $harga_eceran = isset($data[5]) ? (int)$data[5] : 0;
            $konversi = isset($data[6]) ? (int)$data[6] : 1;
            
            // Jika ada harga eceran, minimal konversi adalah 1 
            // (mencegah error kalkulasi stok jika admin tidak sengaja mengisi konversi = 0 di excel)
            if ($harga_eceran > 0 && $konversi <= 0) {
                $konversi = 1;
            }
            
            // Kalkulasi otomatis stok eceran layaknya sistem form manual
            $stok_eceran = $stok * $konversi;
            
            // MAGIC SCRIPT: Mengundi dan menetapkan satu kelas warna secara otomatis (Gacha system)
            $warna_bg = $warna_pilihan[array_rand($warna_pilihan)];
            
            // Eksekusi Pengecekan Duplikasi (Kode Barang harus Unik)
            $cek_kode = mysqli_query($koneksi, "SELECT id FROM barang WHERE kode = '$kode'");
            if (mysqli_num_rows($cek_kode) == 0) {
                // Jika belum ada di database, Insert barang baru
                $query_insert = "INSERT INTO barang (kode, nama_barang, kategori, stok, stok_eceran, harga, harga_eceran, konversi, warna_bg) 
                                 VALUES ('$kode', '$nama', '$kategori', $stok, $stok_eceran, $harga_grosir, $harga_eceran, $konversi, '$warna_bg')";
                mysqli_query($koneksi, $query_insert);
            }
            // (Abaikan baris ini jika terdeteksi kodenya bentrok / sudah pernah diinput)
        }
        
        fclose($file);
        header("Location: index.php?tab=barang&pesan=sukses_import");
        exit;
    } else {
        // Jika file CSV gagal dibaca
        header("Location: index.php?tab=barang&pesan=error_import_kosong");
        exit;
    }
}
// Jika diakses manual lewat URL tanpa Post Form
header("Location: index.php?tab=barang");
?>