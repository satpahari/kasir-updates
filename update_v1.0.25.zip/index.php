<?php
session_start();
require '../config/koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

// Memuat semua variabel data dari database
require 'includes/data.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Dashboard - Point of Sales</title>
    <link rel="stylesheet" href="../assets/css/fonts.css">
    <script src="../assets/js/tailwindcss.js"></script>
    <link rel="stylesheet" href="../assets/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="../assets/img/kasir.ico">
    <script src="../assets/js/chart.js"></script>
    <script>
        tailwind.config = {
            theme: { 
                extend: {
                    fontFamily: { sans: ['Roboto', 'sans-serif'] }, 
                    colors: { 
                        brand: { 50: '#f3f4f6', 500: '#6b7280', 600: '#4b5563', 700: '#374151' },
                        slate: { 850: '#151f32', 900: '#0f172a' }
                    } 
                } 
            }
        }
    </script>
    <style>
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        .sidebar-scroll::-webkit-scrollbar-thumb { background: #334155; }
        .sidebar-scroll::-webkit-scrollbar-thumb:hover { background: #475569; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up { animation: fadeInUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .tab-content { transition: opacity 0.15s ease-out; }

        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }

        input:focus, 
        select:focus, 
        textarea:focus, 
        .focus-within\:ring-2:focus-within {
            transition: none !important;
            animation: none !important;
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800 font-sans h-screen overflow-hidden flex relative">

    <div id="toast-container" class="fixed top-5 right-5 z-[70] flex flex-col gap-3"></div>
    <div id="sidebar-overlay" onclick="toggleSidebar()" class="fixed inset-0 bg-slate-900/75 z-40 hidden md:hidden transition-opacity"></div>

    <!-- SIDEBAR -->
    <aside id="sidebar" class="fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 text-slate-300 flex flex-col transition-all duration-300 transform -translate-x-full md:relative md:translate-x-0 shadow-2xl md:shadow-none border-r border-slate-800">
        <div class="h-20 flex items-center justify-between md:justify-center px-6 border-b border-slate-800/80 sticky top-0 bg-slate-900 z-10 shrink-0">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-500/30">
                    <i class="fa-solid fa-store text-lg"></i>
                </div>
                <span class="text-xl font-bold text-white tracking-wide">Berkah<span class="text-blue-500">POS</span></span>
            </div>
            <button onclick="toggleSidebar()" class="md:hidden text-slate-400 hover:text-white focus:outline-none bg-slate-800 w-8 h-8 rounded-lg flex items-center justify-center">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        
        <nav class="flex-1 py-6 space-y-1 overflow-y-auto sidebar-scroll px-3">
            <p class="px-4 text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 mt-2">Menu Utama</p>
            
            <button onclick="switchTab('dashboard')" class="w-full flex items-center px-4 py-3 rounded-xl border border-transparent transition-all duration-200 tab-btn text-slate-400 hover:bg-slate-800 hover:text-slate-200" data-target="dashboard">
                <div class="w-6 flex justify-center mr-2"><i class="fa-solid fa-desktop text-lg"></i></div>
                <span class="font-medium tracking-wide">Dashboard</span>
            </button>
            <button onclick="switchTab('transaksi')" class="w-full flex items-center px-4 py-3 rounded-xl border border-transparent transition-all duration-200 tab-btn text-slate-400 hover:bg-slate-800 hover:text-slate-200 mt-1" data-target="transaksi">
                <div class="w-6 flex justify-center mr-2"><i class="fa-solid fa-cash-register text-lg"></i></div>
                <span class="font-medium tracking-wide">Transaksi Kasir</span>
            </button>
            <!-- [BARU] MENU TRANSAKSI LAMPAU -->
            <button onclick="switchTab('backdate')" class="w-full flex items-center px-4 py-3 rounded-xl border border-transparent transition-all duration-200 tab-btn text-slate-400 hover:bg-slate-800 hover:text-slate-200 mt-1" data-target="backdate">
                <div class="w-6 flex justify-center mr-2"><i class="fa-solid fa-clock-rotate-left text-lg"></i></div>
                <span class="font-medium tracking-wide">Transaksi Lampau</span>
            </button>
            
            <p class="px-4 text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 mt-7">Manajemen Data</p>
            
            <!-- DROPDOWN: DATA & LAPORAN -->
            <div class="relative mb-1">
                <button onclick="toggleDropdown('menu-data', 'icon-data')" class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent transition-all duration-200 text-slate-400 hover:bg-slate-800 hover:text-white focus:outline-none z-10 relative group">
                    <div class="flex items-center">
                        <div class="w-6 flex justify-center mr-2 text-slate-400 group-hover:text-brand-400 transition-colors"><i class="fa-solid fa-folder-open text-lg"></i></div>
                        <span class="font-medium tracking-wide">Data & Laporan</span>
                    </div>
                    <i id="icon-data" class="fa-solid fa-chevron-down text-[10px] transition-transform duration-300"></i>
                </button>
                
                <div id="menu-data" class="max-h-0 opacity-0 overflow-hidden transition-all duration-300 ease-in-out">
                    <div class="pt-1.5 pb-2 pl-6 pr-4 space-y-1">
                        <button onclick="switchTab('barang')" class="w-full flex items-center px-4 py-2.5 rounded-xl transition-all duration-300 tab-btn text-slate-400 hover:text-white hover:bg-slate-800/80 text-sm group" data-target="barang">
                            <div class="w-5 flex justify-center mr-3 text-[11px] opacity-60 group-hover:opacity-100 group-hover:text-brand-400 transition-all duration-300">
                                <i class="fa-solid fa-boxes-stacked drop-shadow-none group-hover:drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]"></i>
                            </div>
                            <span class="font-medium tracking-wide">Kelola Barang</span>
                        </button>
                        
                        <button onclick="switchTab('rekap')" class="w-full flex items-center px-4 py-2.5 rounded-xl transition-all duration-300 tab-btn text-slate-400 hover:text-white hover:bg-slate-800/80 text-sm group" data-target="rekap">
                            <div class="w-5 flex justify-center mr-3 text-[11px] opacity-60 group-hover:opacity-100 group-hover:text-brand-400 transition-all duration-300">
                                <i class="fa-solid fa-chart-simple drop-shadow-none group-hover:drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]"></i>
                            </div>
                            <span class="font-medium tracking-wide">Laporan Penjualan</span>
                        </button>

                        <button onclick="switchTab('pengeluaran')" class="w-full flex items-center px-4 py-2.5 rounded-xl transition-all duration-300 tab-btn text-slate-400 hover:text-white hover:bg-slate-800/80 text-sm group" data-target="pengeluaran">
                            <div class="w-5 flex justify-center mr-3 text-[11px] opacity-60 group-hover:opacity-100 group-hover:text-brand-400 transition-all duration-300">
                                <i class="fa-solid fa-money-bill-transfer drop-shadow-none group-hover:drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]"></i>
                            </div>
                            <span class="font-medium tracking-wide">Pengeluaran Toko</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <?php if($_SESSION['role'] == 'admin'): ?>
            <p class="px-4 text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 mt-7">Pengaturan Sistem</p>
            
            <!-- DROPDOWN: KONFIGURASI SISTEM -->
            <div class="relative mb-1">
                <button onclick="toggleDropdown('menu-sistem', 'icon-sistem')" class="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-transparent transition-all duration-200 text-slate-400 hover:bg-slate-800 hover:text-white focus:outline-none z-10 relative group">
                    <div class="flex items-center">
                        <div class="w-6 flex justify-center mr-2 text-slate-400 group-hover:text-brand-400 transition-colors"><i class="fa-solid fa-gear text-lg"></i></div>
                        <span class="font-medium tracking-wide">Konfigurasi Sistem</span>
                    </div>
                    <i id="icon-sistem" class="fa-solid fa-chevron-down text-[10px] transition-transform duration-300"></i>
                </button>
                
                <div id="menu-sistem" class="max-h-0 opacity-0 overflow-hidden transition-all duration-300 ease-in-out">
                    <div class="pt-1.5 pb-2 pl-6 pr-4 space-y-1">
                        <button onclick="switchTab('akun')" class="w-full flex items-center px-4 py-2.5 rounded-xl transition-all duration-300 tab-btn text-slate-400 hover:text-white hover:bg-slate-800/80 text-sm group" data-target="akun">
                            <div class="w-5 flex justify-center mr-3 text-[11px] opacity-60 group-hover:opacity-100 group-hover:text-brand-400 transition-all duration-300">
                                <i class="fa-solid fa-users-gear drop-shadow-none group-hover:drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]"></i>
                            </div>
                            <span class="font-medium tracking-wide">Manajemen Akun</span>
                        </button>
                        
                        <button onclick="switchTab('database')" class="w-full flex items-center px-4 py-2.5 rounded-xl transition-all duration-300 tab-btn text-slate-400 hover:text-white hover:bg-slate-800/80 text-sm group" data-target="database">
                            <div class="w-5 flex justify-center mr-3 text-[11px] opacity-60 group-hover:opacity-100 group-hover:text-brand-400 transition-all duration-300">
                                <i class="fa-solid fa-database drop-shadow-none group-hover:drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]"></i>
                            </div>
                            <span class="font-medium tracking-wide">Backup & Restore</span>
                        </button>
                        
                        <button onclick="switchTab('update')" class="w-full flex items-center px-4 py-2.5 rounded-xl transition-all duration-300 tab-btn text-slate-400 hover:text-white hover:bg-slate-800/80 text-sm group" data-target="update">
                            <div class="w-5 flex justify-center mr-3 text-[11px] opacity-60 group-hover:opacity-100 group-hover:text-brand-400 transition-all duration-300">
                                <i class="fa-solid fa-rotate drop-shadow-none group-hover:drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]"></i>
                            </div>
                            <span class="font-medium tracking-wide">Update Aplikasi</span>
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </nav>
        
        <div class="p-4 border-t border-slate-800/80 bg-slate-850 shrink-0">
            <div class="flex items-center gap-3 px-2 mb-4">
                <div class="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center text-slate-300 font-bold border border-slate-600 shrink-0">
                    <?= strtoupper(substr($_SESSION['nama_lengkap'], 0, 1)) ?>
                </div>
                <div class="overflow-hidden">
                    <p class="text-sm font-bold text-white truncate"><?= htmlspecialchars($_SESSION['nama_lengkap']) ?></p>
                    <p class="text-[11px] text-brand-400 font-medium uppercase tracking-wider"><?= htmlspecialchars($_SESSION['role']) ?></p>
                </div>
            </div>
            <a href="../auth/logout.php" class="w-full flex items-center justify-center py-2.5 px-4 bg-red-600 text-white hover:bg-red-700 rounded-xl transition-all duration-300 font-semibold group shadow-md shadow-red-600/20">
                <i class="fa-solid fa-arrow-right-from-bracket mr-2 group-hover:-translate-x-1 transition-transform"></i> Keluar
            </a>
        </div>
    </aside>

    <!-- MAIN CONTENT AREA -->
    <div class="flex-1 flex flex-col h-screen overflow-hidden min-w-0 bg-[#f4f7f6]">
        
        <!-- HEADER -->
        <header class="bg-white shadow-sm border-b border-gray-100 px-4 md:px-8 h-20 flex justify-between items-center no-print sticky top-0 z-30 shrink-0">
            <div class="flex items-center gap-3 sm:gap-4 flex-1 min-w-0 pr-4">
                <button onclick="toggleSidebar()" class="md:hidden w-10 h-10 rounded-xl bg-white border border-gray-200 text-gray-600 hover:text-brand-500 hover:border-brand-300 shadow-sm flex items-center justify-center focus:outline-none transition shrink-0">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <div class="min-w-0 flex-1">
                    <h2 id="header-title" class="text-lg sm:text-xl md:text-2xl font-bold text-gray-800 tracking-tight truncate">Dashboard</h2>
                    <p class="text-[10px] sm:text-xs md:text-sm text-gray-500 font-medium mt-0.5 truncate" id="date-display"></p>
                </div>
            </div>

            <div class="relative shrink-0">
                <button onclick="toggleNotif()" id="notif-btn-container" class="relative p-2 text-gray-500 hover:text-brand-500 transition focus:outline-none flex items-center justify-center w-10 h-10 rounded-xl hover:bg-gray-100">
                    <i class="fa-solid fa-bell text-xl"></i>
                    <?php if($total_stok_habis > 0): ?>
                    <span class="absolute top-1 right-1 flex h-4 w-4">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-4 w-4 bg-red-500 text-[9px] font-bold text-white items-center justify-center border-2 border-white"><?= $total_stok_habis ?></span>
                    </span>
                    <?php endif; ?>
                </button>

                <div id="notif-dropdown" class="hidden absolute right-[-10px] sm:right-0 mt-3 w-[calc(100vw-2rem)] max-w-sm sm:w-96 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 overflow-hidden origin-top-right transition-all">
                    <div class="px-5 py-4 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
                        <h3 class="font-bold text-gray-800 text-sm">Notifikasi Stok Barang</h3>
                        <span id="notif-header-count" class="bg-red-100 text-red-600 text-[10px] font-bold px-2 py-0.5 rounded-full"><?= $total_stok_habis ?> Barang Habis</span>
                    </div>
                    
                    <div id="notif-list-container" class="max-h-72 overflow-y-auto custom-scroll p-2">
                        <?php if($total_stok_habis > 0): ?>
                            <?php foreach($stok_habis_array as $brg): ?>
                            <div class="p-3 hover:bg-gray-50 rounded-xl transition cursor-default flex items-start gap-3 border-b border-gray-50 last:border-0">
                                <div class="w-8 h-8 rounded-lg bg-red-50 text-red-500 flex items-center justify-center shrink-0 mt-0.5">
                                    <i class="fa-solid fa-triangle-exclamation text-xs"></i>
                                </div>
                                <div>
                                    <p class="text-sm font-bold text-gray-800 leading-tight mb-0.5"><?= htmlspecialchars($brg['nama_barang']) ?></p>
                                    <p class="text-[11px] text-gray-500 font-medium">Kode : <?= htmlspecialchars($brg['kode']) ?> &bull; <span class="text-red-500 font-bold">Segera Restock!</span></p>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="p-8 text-center text-gray-400 flex flex-col items-center">
                                <i class="fa-solid fa-circle-check text-4xl mb-3 text-green-400 opacity-50"></i>
                                <p class="text-sm font-medium">Semua stok barang aman.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="p-2 border-t border-gray-100 bg-gray-50">
                        <button onclick="switchTab('barang'); toggleNotif()" class="w-full py-2.5 text-center text-xs font-bold text-brand-600 hover:text-brand-700 hover:bg-brand-50 rounded-xl transition">
                            Pergi ke Kelola Barang
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <!-- KONTEN HALAMAN UTAMA -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto p-4 md:p-8">
            <?php include 'includes/views.php'; ?>
        </main>

        <?php
        // Mengambil versi lokal aplikasi secara dinamis
        $app_version = "1.0.0";
        if(file_exists('../version.json')) {
            $v_data = json_decode(file_get_contents('../version.json'), true);
            if(isset($v_data['version'])) $app_version = $v_data['version'];
        } else if(file_exists('version.json')) { // Fallback path
            $v_data = json_decode(file_get_contents('version.json'), true);
            if(isset($v_data['version'])) $app_version = $v_data['version'];
        }
        ?>
        <footer class="bg-white border-t border-gray-200 px-4 md:px-8 py-4 text-xs sm:text-sm text-gray-500 no-print flex flex-col sm:flex-row justify-between items-center gap-3 sm:gap-2 shrink-0 z-20 text-center sm:text-left">
            <p class="text-xs">&copy; <?= date('Y') ?> <span class="text-gray-800 font-bold">Created by SatpaDev</span>. All rights reserved.</p>
            <p class="text-xs font-semibold bg-gray-100 px-3 py-1 rounded-full text-gray-600 border border-gray-200">Versi App <span id="local-version-display"><?= $app_version ?></span></p>
        </footer>
    </div>

    <!-- MEMUAT KUMPULAN MODAL POP-UP -->
    <?php include 'includes/modals.php'; ?>

    <!-- MEMUAT JAVASCRIPT -->
    <?php include 'includes/scripts.php'; ?>
    
    <!-- SCRIPT KHUSUS ANIMASI DROPDOWN SIDEBAR -->
    <script>
        // Fungsi untuk membuka / menutup dropdown dengan animasi meluncur
        function toggleDropdown(menuId, iconId) {
            const menu = document.getElementById(menuId);
            const icon = document.getElementById(iconId);
            
            if (menu.classList.contains('max-h-0')) {
                // Membuka (Expand)
                menu.classList.remove('max-h-0', 'opacity-0');
                menu.classList.add('max-h-[500px]', 'opacity-100');
                icon.classList.add('rotate-180');
            } else {
                // Menutup (Collapse)
                menu.classList.add('max-h-0', 'opacity-0');
                menu.classList.remove('max-h-[500px]', 'opacity-100');
                icon.classList.remove('rotate-180');
            }
        }

        // Modifikasi fungsi switchTab bawaan agar bisa membuka otomatis saat refresh/berpindah
        if (typeof window.switchTab === 'function') {
            const functionAsli = window.switchTab;
            
            window.switchTab = function(tabId, isLoad = false) {
                // Cek jika tab yang diklik ada di dalam menu Data & Laporan
                if (tabId === 'barang' || tabId === 'rekap' || tabId === 'pengeluaran') {
                    const menu = document.getElementById('menu-data');
                    if (menu && menu.classList.contains('max-h-0')) {
                        toggleDropdown('menu-data', 'icon-data');
                    }
                } 
                // Cek jika tab yang diklik ada di dalam menu Konfigurasi (Admin)
                else if (tabId === 'akun' || tabId === 'database' || tabId === 'update') {
                    const menu = document.getElementById('menu-sistem');
                    if (menu && menu.classList.contains('max-h-0')) {
                        toggleDropdown('menu-sistem', 'icon-sistem');
                    }
                }
                
                // Lanjutkan jalankan fungsi switchTab yang asli
                functionAsli(tabId, isLoad);
            };
        }
    </script>
</body>
</html>