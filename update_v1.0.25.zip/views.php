<!-- VIEW: DASHBOARD -->
<div id="view-dashboard" class="tab-content hidden flex flex-col gap-5 h-auto lg:h-full min-h-full">
    <!-- Grid Kartu Statistik (Diperkecil & Diberi Aksen Warna Kanan) -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        
        <!-- 1. Pendapatan Harian -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center transition hover:shadow-md hover:-translate-y-1 duration-300 group relative overflow-hidden">
            <div class="absolute right-0 top-0 bottom-0 w-1.5 bg-yellow-500"></div>
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center text-white text-xl mr-4 shadow-lg shadow-yellow-500/30 group-hover:scale-110 transition-transform"><i class="fa-solid fa-hand-holding-dollar"></i></div>
            <div>
                <p class="text-xs text-gray-500 font-medium mb-1 uppercase">Pendapatan Hari Ini</p>
                <p class="text-xl font-black text-gray-800" id="dash-pendapatan-harian" data-value="<?= isset($dash_pendapatan_harian) ? $dash_pendapatan_harian : 0 ?>">Rp <?= number_format(isset($dash_pendapatan_harian) ? $dash_pendapatan_harian : 0, 0, ',', '.') ?></p>
            </div>
        </div>
        
        <!-- 2. Pemasukan Kotor -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center transition hover:shadow-md hover:-translate-y-1 duration-300 group relative overflow-hidden">
            <div class="absolute right-0 top-0 bottom-0 w-1.5 bg-blue-500"></div>
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white text-xl mr-4 shadow-lg shadow-blue-500/30 group-hover:scale-110 transition-transform"><i class="fa-solid fa-sack-dollar"></i></div>
            <div>
                <p class="text-xs text-gray-500 font-medium mb-1 uppercase">Total Pemasukan Bulan Ini</p>
                <p class="text-xl font-black text-gray-800" id="dash-pendapatan-total" data-value="<?= isset($dash_pendapatan) ? $dash_pendapatan : 0 ?>">Rp <?= number_format(isset($dash_pendapatan) ? $dash_pendapatan : 0, 0, ',', '.') ?></p>
            </div>
        </div>
        
        <!-- 3. Pengeluaran -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center transition hover:shadow-md hover:-translate-y-1 duration-300 group relative overflow-hidden">
            <div class="absolute right-0 top-0 bottom-0 w-1.5 bg-rose-500"></div>
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-400 to-rose-600 flex items-center justify-center text-white text-xl mr-4 shadow-lg shadow-rose-500/30 group-hover:scale-110 transition-transform"><i class="fa-solid fa-money-bill-transfer"></i></div>
            <div>
                <p class="text-xs text-gray-500 font-medium mb-1 uppercase">Pengeluaran Toko Bulan Ini</p>
                <p class="text-xl font-black text-gray-800" id="dash-pengeluaran-total" data-value="<?= isset($dash_pengeluaran) ? $dash_pengeluaran : 0 ?>">Rp <?= number_format(isset($dash_pengeluaran) ? $dash_pengeluaran : 0, 0, ',', '.') ?></p>
            </div>
        </div>
        
        <!-- 4. Laba Bersih -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center transition hover:shadow-md hover:-translate-y-1 duration-300 group relative overflow-hidden">
            <div class="absolute right-0 top-0 bottom-0 w-1.5 bg-emerald-500"></div>
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-xl mr-4 shadow-lg shadow-emerald-500/30 group-hover:scale-110 transition-transform"><i class="fa-solid fa-wallet"></i></div>
            <div>
                <p class="text-xs text-gray-500 font-medium mb-1 uppercase">Laba Bersih Bulan Ini</p>
                <p class="text-xl font-black text-gray-800" id="dash-laba-bersih" data-value="<?= isset($dash_laba_bersih) ? $dash_laba_bersih : (isset($dash_pendapatan) ? $dash_pendapatan : 0) ?>">Rp <?= number_format(isset($dash_laba_bersih) ? $dash_laba_bersih : (isset($dash_pendapatan) ? $dash_pendapatan : 0), 0, ',', '.') ?></p>
            </div>
        </div>
        
        <!-- 5. Total Transaksi -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center transition hover:shadow-md hover:-translate-y-1 duration-300 group relative overflow-hidden">
            <div class="absolute right-0 top-0 bottom-0 w-1.5 bg-green-500"></div>
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-green-500 flex items-center justify-center text-white text-xl mr-4 shadow-lg shadow-green-500/30 group-hover:scale-110 transition-transform"><i class="fa-solid fa-receipt"></i></div>
            <div>
                <p class="text-xs text-gray-500 font-medium mb-1 uppercase">Total Transaksi</p>
                <p class="text-xl font-black text-gray-800" id="dash-total-trx" data-value="<?= isset($dash_total_trx) ? $dash_total_trx : 0 ?>"><?= number_format(isset($dash_total_trx) ? $dash_total_trx : 0, 0, ',', '.') ?> <span class="text-[10px] font-bold text-gray-400">STRUK</span></p>
            </div>
        </div>
        
        <!-- 6. Barang Tersimpan -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 flex items-center transition hover:shadow-md hover:-translate-y-1 duration-300 group relative overflow-hidden">
            <div class="absolute right-0 top-0 bottom-0 w-1.5 bg-purple-500"></div>
            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center text-white text-xl mr-4 shadow-lg shadow-purple-500/30 group-hover:scale-110 transition-transform"><i class="fa-solid fa-box-open"></i></div>
            <div>
                <p class="text-xs text-gray-500 font-medium mb-1 uppercase">Barang Tersimpan</p>
                <p class="text-xl font-black text-gray-800" id="total-data-barang" data-value="<?= isset($total_barang_keseluruhan) ? $total_barang_keseluruhan : 0 ?>"><?= number_format(isset($total_barang_keseluruhan) ? $total_barang_keseluruhan : 0, 0, ',', '.') ?> <span class="text-[10px] font-bold text-gray-400">ITEM</span></p>
            </div>
        </div>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 gap-5 flex-1 min-h-0">
        <!-- Area Kiri: Grafik Penjualan -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col lg:col-span-3 xl:col-span-2 min-h-[350px]">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-bold text-lg text-gray-800">Grafik Penjualan Toko <span class="text-sm font-normal text-gray-500 ml-2">(7 Hari Terakhir)</span></h3>
            </div>
            <div class="relative flex-1 w-full h-full"><canvas id="salesChart"></canvas></div>
        </div>
        
        <!-- Area Tengah: Grafik Barang Terlaris (Pie Chart) -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col lg:col-span-1 xl:col-span-1 min-h-[350px]">
            <div class="flex justify-between items-center mb-2">
                <h3 class="font-bold text-lg text-gray-800">Barang Terlaris <span class="text-sm font-normal text-gray-500 ml-1">(Bulan Ini)</span></h3>
            </div>
            <div class="relative flex-1 w-full h-full flex items-center justify-center min-h-[250px]">
                <canvas id="topItemChart"></canvas>
            </div>
        </div>
        
        <!-- Area Kanan: Peringatan Stok Barang Habis -->
        <div class="bg-white rounded-2xl shadow-sm border border-red-100 flex flex-col lg:col-span-2 xl:col-span-1 min-h-[350px] overflow-hidden">
            <div class="p-4 sm:p-5 border-b border-red-100 bg-red-50/50 flex justify-between items-center shrink-0">
                <h3 class="font-bold text-sm flex items-center">
                    Peringatan Stok
                </h3>
                <span class="bg-red-500 text-white text-[10px] font-black px-2 py-1 rounded-md"><?= isset($total_stok_habis) ? $total_stok_habis : 0 ?> Barang Habis</span>
            </div>
            
            <div class="flex-1 overflow-y-auto p-4 custom-scroll space-y-3 bg-gray-50/50">
                <?php if(isset($total_stok_habis) && $total_stok_habis > 0): ?>
                    <?php foreach($stok_habis_array as $sh): ?>
                        <div class="bg-white p-3 rounded-xl border border-gray-100 shadow-sm hover:border-gray-300 transition-colors group">
                            <div class="flex justify-between items-start mb-2">
                                <div class="flex-1 min-w-0 pr-2">
                                    <p class="text-xs font-bold text-gray-800 truncate uppercase" title="<?= htmlspecialchars($sh['nama_barang']) ?>"><?= htmlspecialchars($sh['nama_barang']) ?></p>
                                    <p class="text-[10px] font-mono text-gray-500 uppercase mt-0.5"><?= htmlspecialchars($sh['kode']) ?></p>
                                </div>
                                <button type="button" onclick="editStokLangsung('<?= $sh['kode'] ?>')" class="w-7 h-7 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white rounded-lg flex items-center justify-center transition shrink-0 outline-none" title="Edit Stok">
                                    <i class="fa-solid fa-pen text-[10px]"></i>
                                </button>
                            </div>
                            <div class="flex flex-wrap gap-1.5">
                                <?php if($sh['stok'] <= 0): ?>
                                    <span class="text-[10px] font-bold bg-red-50 text-red-600 px-2 py-0.5 rounded border border-red-200">Grosir Kosong</span>
                                <?php endif; ?>
                                <?php if(isset($sh['stok_eceran']) && $sh['stok_eceran'] <= 0): ?>
                                    <span class="text-[10px] font-bold bg-orange-50 text-orange-600 px-2 py-0.5 rounded border border-orange-200">Eceran Kosong</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="h-full flex flex-col items-center justify-center text-center p-6 text-emerald-600 opacity-80">
                        <i class="fa-solid fa-clipboard-check text-5xl mb-4 text-emerald-400"></i>
                        <h4 class="font-bold text-sm mb-1">Stok Terkendali</h4>
                        <p class="text-[11px] font-medium text-emerald-600/70">Semua persediaan barang Anda saat ini dalam kondisi aman.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if(isset($total_stok_habis) && $total_stok_habis > 0): ?>
            <div class="p-3 border-t border-gray-100 bg-white shrink-0">
                <button type="button" onclick="switchTab('barang')" class="w-full py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold rounded-xl text-xs transition flex items-center justify-center outline-none">
                    Kelola Semua Stok Barang
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- VIEW: TRANSAKSI KASIR -->
<div id="view-transaksi" class="tab-content hidden flex flex-col xl:flex-row gap-4 sm:gap-6 h-auto xl:h-full min-h-full">
    
    <!-- DAFTAR BARANG KASIR -->
    <div class="flex-1 bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col min-h-[600px] xl:min-h-0 xl:h-full">
        <div class="relative mb-5 group shrink-0">
            <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <i class="fa-solid fa-barcode text-gray-400 text-lg group-focus-within:text-brand-500"></i>
            </div>
            <input type="text" id="search-barang-kasir" placeholder="Scan kode barang atau cari nama barang disini . . ." autofocus class="w-full pl-[3.25rem] pr-4 h-[50px] border border-gray-200 bg-gray-50 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 focus:bg-white outline-none shadow-sm text-sm font-medium text-gray-700" autocomplete="off">
        </div>
        
        <div class="flex-1 min-h-0 border border-gray-200 rounded-xl bg-white shadow-sm flex flex-col overflow-hidden">
            <!-- SYNCHRONIZED HEADER -->
            <div class="bg-gray-50 border-b border-gray-200 overflow-hidden shrink-0" id="header-scroll-kasir">
                <div class="pr-[6px]">
                    <table class="w-full text-left border-collapse table-fixed min-w-[700px] xl:min-w-full">
                        <colgroup><col><col class="w-20"><col class="w-20"><col class="w-28"><col class="w-28"><col class="w-14"></colgroup>
                        <thead class="text-gray-500 text-[10px] uppercase tracking-wider">
                            <tr>
                                <th class="py-3 px-3 font-bold">Nama & Kode Barang</th>
                                <th class="py-3 px-2 font-bold text-center" title="Stok Grosir">Stok Grosir</th>
                                <th class="py-3 px-2 font-bold text-center" title="Stok Eceran">Stok Eceran</th>
                                <th class="py-3 px-2 font-bold text-right" title="Harga Grosir">Harga Grosir</th>
                                <th class="py-3 px-2 font-bold text-right" title="Harga Eceran">Harga Eceran</th>
                                <th class="py-3 px-2 font-bold text-center">Aksi</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
            <!-- BODY TABLE -->
            <div class="overflow-y-scroll overflow-x-auto flex-1 bg-white custom-scroll" onscroll="document.getElementById('header-scroll-kasir').scrollLeft = this.scrollLeft">
                <table class="w-full text-left border-collapse table-fixed min-w-[700px] xl:min-w-full">
                    <colgroup><col><col class="w-20"><col class="w-20"><col class="w-28"><col class="w-28"><col class="w-14"></colgroup>
                    <tbody id="product-grid" class="divide-y divide-gray-100">
                        <!-- Dimuat via JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- KERANJANG KASIR -->
    <div class="w-full xl:w-[400px] bg-white p-4 md:p-5 rounded-2xl shadow-sm border border-gray-100 flex flex-col shrink-0 min-h-[500px] xl:min-h-0 xl:h-full" id="cart-area">
        <div class="flex justify-between items-center mb-4 pb-3 border-b border-gray-100 shrink-0">
            <h3 class="font-bold text-gray-800 flex items-center"><i class="fa-solid fa-basket-shopping text-brand-500 mr-2"></i> Keranjang</h3>
            <span class="bg-brand-50 text-brand-600 text-[10px] font-bold px-2 py-1 rounded-md" id="cart-badge">0 Item</span>
        </div>

        <div class="flex-1 overflow-y-auto mb-4 pr-1 custom-scroll">
            <table class="w-full text-sm">
                <thead class="sticky top-0 bg-white z-10 shadow-sm">
                    <tr class="text-left border-b border-gray-100 text-gray-400 text-xs uppercase tracking-wider">
                        <th class="py-2.5 font-semibold bg-white">Item</th>
                        <th class="py-2.5 font-semibold text-center w-24 sm:w-28 bg-white">Qty</th>
                        <th class="py-2.5 font-semibold text-right bg-white">Harga</th>
                        <th class="py-2.5 font-semibold text-center w-10 bg-white"></th>
                    </tr>
                </thead>
                <tbody id="cart-items">
                    <tr>
                        <td colspan="4" class="text-center align-middle">
                            <div class="flex flex-col items-center justify-center h-56 text-gray-400">
                                <i class="fa-solid fa-cart-arrow-down text-5xl mb-4 opacity-20"></i>
                                <span class="font-medium text-sm">Keranjang kosong</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="border-t border-gray-100 pt-4 shrink-0">
            <div class="flex justify-between text-sm mb-1 text-gray-600">
                <span class="font-bold">Subtotal :</span><span id="cart-subtotal" class="font-bold">Rp 0</span>
            </div>
            <div class="flex justify-between items-center mb-2">
                <span class="font-bold text-sm text-gray-600">Diskon (Rp) :</span>
                <input type="text" inputmode="numeric" id="input-diskon-cart" value="0" oninput="formatInputUang(this); updateDiskonCart()" class="w-24 text-right border-b border-gray-300 focus:border-brand-500 outline-none text-sm font-bold text-red-500 bg-transparent" autocomplete="off">
            </div>
            <div class="flex justify-between font-bold text-lg mb-2 pt-2 border-t border-gray-200 border-dashed">
                <span class="text-gray-800">Total Tagihan :</span><span id="cart-total" class="text-brand-600 text-lg font-black">Rp 0</span>
            </div>
            <div class="grid grid-cols-2 gap-3 mt-4">
                <button onclick="clearCart()" class="py-3 bg-red-500 rounded-xl hover:bg-red-600 text-white font-bold text-sm transition-colors duration-200 border border-red-100 border-red-500">Kosongkan</button>
                <button onclick="bukaModalCheckout()" class="py-3 bg-gray-700 text-white rounded-xl hover:bg-gray-800 font-bold text-sm transition-colors duration-200">Proses Bayar</button>
            </div>
        </div>
    </div>
</div>

<!-- VIEW: DATA BARANG -->
<div id="view-barang" class="tab-content hidden flex flex-col h-auto lg:h-full min-h-full">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col min-h-[600px] lg:h-full overflow-hidden">
        <div class="p-5 md:p-6 border-b border-gray-100 flex flex-col sm:flex-row justify-between sm:items-center bg-gray-50/50 gap-4 shrink-0">
            <div>
                <h3 class="font-bold text-xl text-gray-800 tracking-tight">Daftar Barang</h3>
                <p class="text-sm text-gray-500 mt-1 font-medium">Kelola seluruh stok dan harga produk.</p>
            </div>
            
            <div class="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
                <form method="GET" class="w-full sm:w-auto flex items-stretch">
                    <input type="hidden" name="tab" value="barang">
                    <div class="relative flex-1 sm:w-64">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fa-solid fa-magnifying-glass text-gray-400"></i>
                        </div>
                        <input type="text" name="cari_brg" value="<?= isset($_GET['cari_brg']) ? htmlspecialchars($_GET['cari_brg']) : '' ?>" placeholder="Cari nama / kode barang . . ." class="w-full h-full pl-9 pr-4 py-2.5 bg-white border border-gray-200 rounded-l-xl focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 text-sm font-medium m-0" autocomplete="off">
                    </div>
                    <button type="submit" class="bg-gray-100 hover:bg-gray-200 border border-l-0 border-gray-200 px-4 rounded-r-xl text-gray-600 transition flex items-center justify-center shrink-0">
                        <i class="fa-solid fa-arrow-right"></i>
                    </button>
                </form>

                <button onclick="bukaModalUploadCsv()" class="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-sm shadow-emerald-600/20 transition font-semibold flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-upload mr-2"></i> Import Data
                </button>
                <button onclick="bukaModalBarang('tambah')" class="w-full sm:w-auto bg-gray-700 hover:bg-gray-800 text-white px-5 py-2.5 rounded-xl text-sm shadow-gray-700/20 transition font-semibold flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-plus mr-2"></i> Tambah Baru
                </button>
            </div>
        </div>
        
        <!-- PEMISAHAN HEADER & BODY UNTUK SCROLLBAR RAPI (SYNCHRONIZED) -->
        <div class="flex-1 min-h-0 flex flex-col bg-white">
            
            <!-- HEADER TABEL -->
            <div class="bg-white border-b border-gray-100 overflow-hidden shrink-0" id="header-scroll-barang">
                <div class="pr-[6px]">
                    <table class="w-full text-left border-collapse table-fixed min-w-[900px] xl:min-w-full">
                        <colgroup>
                            <col class="w-14">
                            <col class="w-32">
                            <col>
                            <col class="w-28">
                            <col class="w-24">
                            <col class="w-24">
                            <col class="w-32">
                            <col class="w-32">
                            <?php if($_SESSION['role'] == 'admin'): ?>
                            <col class="w-24">
                            <?php endif; ?>
                        </colgroup>
                        <thead class="text-gray-400 text-[11px] uppercase tracking-wider">
                            <tr>
                                <th class="py-3 px-3 font-semibold text-center">No</th>
                                <th class="py-3 px-3 font-semibold">Kode Barang</th>
                                <th class="py-3 px-3 font-semibold">Nama Barang</th>
                                <th class="py-3 px-3 font-semibold">Kategori</th>
                                <th class="py-3 px-3 font-semibold text-center">Stok Grosir</th>
                                <th class="py-3 px-3 font-semibold text-center">Stok Eceran</th>
                                <th class="py-3 px-3 font-semibold text-right">Harga Grosir</th>
                                <th class="py-3 px-3 font-semibold text-right">Harga Eceran</th>
                                <?php if($_SESSION['role'] == 'admin'): ?>
                                <th class="py-3 px-3 font-semibold text-center">Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>

            <!-- BODY TABEL -->
            <div class="overflow-y-scroll overflow-x-auto flex-1 bg-white custom-scroll" onscroll="document.getElementById('header-scroll-barang').scrollLeft = this.scrollLeft">
                <table class="w-full text-left border-collapse table-fixed min-w-[900px] xl:min-w-full">
                    <colgroup>
                        <col class="w-14">
                        <col class="w-32">
                        <col>
                        <col class="w-28">
                        <col class="w-24">
                        <col class="w-24">
                        <col class="w-32">
                        <col class="w-32">
                        <?php if($_SESSION['role'] == 'admin'): ?>
                        <col class="w-24">
                        <?php endif; ?>
                    </colgroup>
                    <tbody id="tbody-data-barang" class="divide-y divide-gray-50">
                        <?php 
                        $col_span_empty = ($_SESSION['role'] == 'admin') ? 9 : 8;
                        if(isset($total_data_barang) && $total_data_barang > 0): 
                        ?>
                            <?php 
                            $no_barang = isset($offset_barang) ? $offset_barang + 1 : 1;
                            while($b = mysqli_fetch_assoc($q_semua_barang)): 
                                $h_grosir = (int)$b['harga'];
                                $h_eceran = isset($b['harga_eceran']) ? (int)$b['harga_eceran'] : 0;
                                $stok_grosir = (int)$b['stok'];
                                
                                $konversi = isset($b['konversi']) ? (int)$b['konversi'] : 1;
                                $stok_eceran = isset($b['stok_eceran']) ? (int)$b['stok_eceran'] : ($stok_grosir * $konversi);
                                
                                $b['konversi'] = $konversi;
                                $b['stok_eceran'] = $stok_eceran;
                            ?>
                            <tr class="hover:bg-gray-50/80 transition bg-white group baris-barang">
                                <td class="py-3 px-3 text-center text-sm text-gray-500 font-medium"><?= $no_barang++ ?></td>
                                <td class="py-3 px-3 text-[13px] font-bold text-gray-600 truncate" title="<?= $b['kode'] ?>"><?= $b['kode'] ?></td>
                                <td class="py-3 px-3 font-medium text-gray-800 text-[13px]">
                                    <div class="flex items-center overflow-hidden">
                                        <div class="w-7 h-7 rounded-lg <?= $b['warna_bg'] ?> mr-2 flex items-center justify-center text-white/80 text-xs shrink-0"><i class="fa-solid fa-box"></i></div>
                                        <span class="truncate uppercase" title="<?= htmlspecialchars($b['nama_barang']) ?>"><?= htmlspecialchars($b['nama_barang']) ?></span>
                                    </div>
                                </td>
                                <td class="py-3 px-3 text-xs text-gray-500 truncate">
                                    <span class="bg-gray-100 px-2 py-1 rounded-md border border-gray-200"><?= htmlspecialchars($b['kategori']) ?></span>
                                </td>
                                
                                <td class="py-3 px-3 text-center" id="stok-grosir-<?= $b['id'] ?>">
                                    <?php if($h_grosir > 0): ?>
                                        <span class="inline-block px-2 py-1 rounded-md text-xs font-bold <?= $stok_grosir <= 0 ? 'bg-red-50 text-red-500 border border-red-100' : 'bg-green-50 text-green-700 border border-green-200' ?>" title="Stok Grosir">
                                            <?= $stok_grosir ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs font-medium">-</span>
                                    <?php endif; ?>
                                </td>

                                <td class="py-3 px-3 text-center" id="stok-eceran-<?= $b['id'] ?>">
                                    <?php if($h_eceran > 0): ?>
                                        <span class="inline-block px-2 py-1 rounded-md text-xs font-bold <?= $stok_eceran <= 0 ? 'bg-red-50 text-red-500 border border-red-100' : 'bg-blue-50 text-blue-600 border border-blue-200' ?>" title="Stok Eceran">
                                            <?= $stok_eceran ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs font-medium">-</span>
                                    <?php endif; ?>
                                </td>

                                <td class="py-3 px-3 text-right">
                                    <?php if($h_grosir > 0): ?>
                                        <div class="text-[13px] font-bold text-brand-600 truncate">Rp <?= number_format($h_grosir, 0, ',', '.') ?></div>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs font-medium">-</span>
                                    <?php endif; ?>
                                </td>

                                <td class="py-3 px-3 text-right">
                                    <?php if($h_eceran > 0): ?>
                                        <div class="text-[13px] font-bold text-brand-600 truncate">Rp <?= number_format($h_eceran, 0, ',', '.') ?></div>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-xs font-medium">-</span>
                                    <?php endif; ?>
                                </td>
                                
                                <?php if($_SESSION['role'] == 'admin'): ?>
                                <td class="py-3 px-3 text-center">
                                    <div class="flex justify-center gap-2 transition">
                                        <button onclick='bukaModalBarang("edit", <?= json_encode($b) ?>)' class="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition flex items-center justify-center shrink-0" title="Edit"><i class="fa-solid fa-pen text-[10px]"></i></button>
                                        <button onclick="bukaModalKonfirmasi('proses_barang.php?aksi=hapus&id=<?= $b['id'] ?>', 'Yakin ingin menghapus barang <b><?= htmlspecialchars(addslashes($b['nama_barang'])) ?></b> dari sistem?')" class="w-7 h-7 rounded-lg bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition flex items-center justify-center shrink-0" title="Hapus"><i class="fa-solid fa-trash-can text-[10px]"></i></button>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endwhile; ?>
                            
                            <tr id="row-kosong-barang" class="hidden"><td colspan="<?= $col_span_empty ?>" class="py-16 text-center text-gray-400">
                                <i class="fa-solid fa-search text-4xl mb-3 opacity-30"></i>
                                <p class="font-medium text-sm">Barang tidak ditemukan.</p>
                            </td></tr>

                        <?php else: ?>
                            <tr><td colspan="<?= $col_span_empty ?>" class="py-16 text-center text-gray-400">
                                <i class="fa-solid fa-box-open text-4xl mb-3 opacity-30"></i>
                                <p class="font-medium text-sm">Belum ada data barang terdaftar / Data tidak ditemukan.</p>
                            </td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="bg-gray-50 p-5 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-4 shrink-0">
            <span class="text-sm text-gray-500">Total <span class="font-bold text-gray-700"><?= isset($total_data_barang) ? $total_data_barang : 0 ?></span> Barang Tersimpan</span>
            
            <?php if(isset($total_page_barang) && $total_page_barang > 1): ?>
            <div class="flex items-center gap-2">
                <div class="flex bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                    <?php 
                    $start_page = max(1, $page_barang - 2);
                    $end_page = min($total_page_barang, $page_barang + 2);
                    
                    if($start_page > 1) echo '<span class="px-3 py-1.5 text-gray-400">...</span>';
                    
                    for($i=$start_page; $i<=$end_page; $i++): 
                        $active_class = $i == $page_barang ? 'bg-gray-800 text-white font-bold' : 'text-gray-600 hover:bg-gray-50';
                        $cari_url = isset($_GET['cari_brg']) ? '&cari_brg='.$_GET['cari_brg'] : '';
                    ?>
                    <a href="?tab=barang&page_barang=<?= $i ?><?= $cari_url ?>" class="px-3.5 py-1.5 text-sm border-r border-gray-200 last:border-0 <?= $active_class ?>"><?= $i ?></a>
                    <?php endfor; 
                    
                    if($end_page < $total_page_barang) echo '<span class="px-3 py-1.5 text-gray-400">...</span>';
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- VIEW: REKAP PENJUALAN -->
<div id="view-rekap" class="tab-content hidden flex flex-col h-auto lg:h-full min-h-full">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col min-h-[600px] lg:h-full overflow-hidden">
        <div class="p-5 md:p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col xl:flex-row justify-between xl:items-center gap-4 shrink-0">
            <div>
                <h3 class="font-bold text-xl text-gray-800 tracking-tight">Laporan Penjualan</h3>
                <p class="text-sm text-gray-500 mt-1 font-medium">Ringkasan transaksi penjualan toko.</p>
            </div>
            
            <div class="flex flex-col sm:flex-row items-end sm:items-center gap-3">
                <form method="GET" class="flex flex-wrap items-center gap-2 bg-white p-1.5 rounded-xl border border-gray-200 shadow-sm">
                    <input type="hidden" name="tab" value="rekap">
                    <div class="flex items-center px-3">
                        <i class="fa-regular fa-calendar text-gray-400 mr-2 text-sm"></i>
                        <input type="date" name="tgl_awal" value="<?= isset($tgl_awal) ? $tgl_awal : date('Y-m-01') ?>" class="text-sm outline-none bg-transparent text-gray-700 font-medium cursor-pointer">
                    </div>
                    <span class="text-gray-300">-</span>
                    <div class="flex items-center px-3">
                        <input type="date" name="tgl_akhir" value="<?= isset($tgl_akhir) ? $tgl_akhir : date('Y-m-t') ?>" class="text-sm outline-none bg-transparent text-gray-700 font-medium cursor-pointer">
                    </div>
                    <button type="submit" class="bg-gray-800 hover:bg-gray-900 text-white px-5 py-1.5 rounded-lg text-sm transition font-semibold">Filter</button>
                </form>
                
                <div class="flex items-center gap-2 w-full sm:w-auto">
                    <a href="cetak_laporan.php?tgl_awal=<?= isset($tgl_awal) ? $tgl_awal : '' ?>&tgl_akhir=<?= isset($tgl_akhir) ? $tgl_akhir : '' ?>" target="_blank" class="bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-300 px-4 py-2.5 rounded-xl text-sm transition font-bold flex-1 sm:flex-none flex items-center justify-center whitespace-nowrap shadow-sm">
                        <i class="fa-solid fa-print mr-2"></i> Cetak
                    </a>
                    <div class="flex rounded-xl shadow-sm flex-1 sm:flex-none">
                        <?php if($_SESSION['role'] == 'admin'): ?>
                        <button type="button" id="btn-sync" onclick="bukaModalSync()" class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2.5 rounded-l-xl text-sm transition font-bold flex-1 flex items-center justify-center whitespace-nowrap border-r border-gray-600/50">
                            <i class="fas fa-sync-alt mr-2"></i> Sync Laporan
                        </button>
                        <button type="button" onclick="bukaModalDrive()" class="bg-gray-700 hover:bg-gray-800 text-white px-3 py-2.5 rounded-r-xl transition flex items-center justify-center" title="Pengaturan Link Google Drive">
                            <i class="fa-solid fa-gear"></i>
                        </button>
                        <?php else: ?>
                        <button type="button" id="btn-sync" onclick="bukaModalSync()" class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2.5 rounded-xl text-sm transition font-bold flex-1 flex items-center justify-center whitespace-nowrap">
                            <i class="fas fa-sync-alt mr-2"></i> Sync Laporan
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="flex-1 min-h-0 flex flex-col bg-white">
            <div class="bg-white border-b border-gray-100 overflow-hidden shrink-0" id="header-scroll-rekap">
                <div class="pr-[6px]">
                    <table class="w-full text-left border-collapse table-fixed min-w-[850px] xl:min-w-full">
                        <colgroup>
                            <col class="w-36">
                            <col class="w-44">
                            <col>
                            <col class="w-32">
                            <col class="w-40">
                            <col class="w-32"> <!-- Lebar kolom aksi disesuaikan agar rapi -->
                        </colgroup>
                        <thead class="text-gray-400 text-xs uppercase tracking-wider bg-white">
                            <tr>
                                <th class="py-4 px-6 font-semibold">ID Transaksi</th>
                                <th class="py-4 px-6 font-semibold">Waktu Transaksi</th>
                                <th class="py-4 px-6 font-semibold">Petugas Kasir</th>
                                <th class="py-4 px-6 font-semibold text-center">Metode</th>
                                <th class="py-4 px-6 font-semibold text-right">Total Belanja</th>
                                <th class="py-4 px-6 font-semibold text-center no-print">Aksi</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>

            <div class="overflow-y-scroll overflow-x-auto flex-1 bg-white custom-scroll" onscroll="document.getElementById('header-scroll-rekap').scrollLeft = this.scrollLeft">
                <table class="w-full text-left border-collapse table-fixed min-w-[850px] xl:min-w-full">
                    <colgroup>
                        <col class="w-36">
                        <col class="w-44">
                        <col>
                        <col class="w-32">
                        <col class="w-40">
                        <col class="w-32">
                    </colgroup>
                    <tbody class="divide-y divide-gray-50" id="tbody-rekap">
                        <?php if(isset($q_rekap) && mysqli_num_rows($q_rekap) > 0): ?>
                            <?php while($r = mysqli_fetch_assoc($q_rekap)): 
                                $metodeBayar = isset($r['metode']) ? strtolower($r['metode']) : 'tunai';
                                if($metodeBayar == 'qris') {
                                    $badgeMetode = '<span class="inline-block px-2.5 py-1 rounded-md text-[11px] font-bold bg-yellow-50 text-yellow-600 border border-yellow-200"><i class="fa-solid fa-qrcode mr-1"></i> QRIS</span>';
                                } else {
                                    $badgeMetode = '<span class="inline-block px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-600 border border-emerald-200"><i class="fa-solid fa-money-bill-wave mr-1"></i> TUNAI</span>';
                                }
                            ?>
                            <tr class="hover:bg-gray-50/80 transition group bg-white">
                                <td class="py-3 px-6 text-sm font-bold text-gray-700 truncate">TRX-<?= str_pad($r['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                <td class="py-3 px-6 text-sm text-gray-500 font-medium truncate"><?= date('d M Y, H:i', strtotime($r['tanggal'])) ?></td>
                                <td class="py-3 px-6 text-sm text-gray-600 flex items-center font-medium overflow-hidden">
                                    <div class="w-6 h-6 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-[10px] mr-2 font-black uppercase shrink-0"><?= substr($r['nama_lengkap'], 0, 1) ?></div>
                                    <span class="truncate"><?= htmlspecialchars($r['nama_lengkap']) ?></span>
                                </td>
                                <td class="py-3 px-6 text-center"><?= $badgeMetode ?></td>
                                <td class="py-3 px-6 text-sm font-bold text-right text-gray-900 truncate">Rp <?= number_format($r['total'], 0, ',', '.') ?></td>
                                <td class="py-3 px-6 text-center no-print">
                                    <div class="flex justify-center items-center gap-2">
                                        <button onclick="bukaDetailTrx(<?= $r['id'] ?>)" class="text-blue-500 hover:text-white hover:bg-blue-600 bg-blue-50 border border-blue-100 shadow-sm px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0">Detail</button>
                                        
                                        <!-- TOMBOL HAPUS (HANYA ADMIN) -->
                                        <?php if($_SESSION['role'] == 'admin'): ?>
                                        <button onclick="bukaModalKonfirmasi('hapus_transaksi.php?id=<?= $r['id'] ?>', 'PERINGATAN KRITIS:<br>Apakah Anda yakin ingin menghapus transaksi <b>TRX-<?= str_pad($r['id'], 5, '0', STR_PAD_LEFT) ?></b>?<br><br>Data tidak dapat dikembalikan. Stok barang akan dipulihkan dan total pendapatan akan otomatis dikurangi.')" class="w-7 h-7 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white border border-red-100 hover:border-red-600 rounded-lg flex items-center justify-center transition shadow-sm shrink-0" title="Hapus Transaksi (Void)">
                                            <i class="fa-solid fa-trash-can text-[10px]"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="py-16 text-center text-gray-400">
                                <i class="fa-regular fa-folder-open text-4xl mb-3 opacity-40"></i>
                                <p class="font-medium text-sm">Tidak ada transaksi pada periode tanggal tersebut.</p>
                            </td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="bg-gray-50 p-5 md:p-6 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-4 shrink-0">
            <div class="text-sm text-gray-500 bg-white px-5 py-2.5 rounded-xl border border-gray-200 shadow-sm">
                Grand Total Pendapatan : <span id="grand-total-rekap" data-value="<?= isset($total_pendapatan_all) ? $total_pendapatan_all : 0 ?>" class="text-xl font-black text-brand-600 ml-2">Rp <?= number_format(isset($total_pendapatan_all) ? $total_pendapatan_all : 0, 0, ',', '.') ?></span>
            </div>
            
            <?php if(isset($total_page_rekap) && $total_page_rekap > 1): ?>
            <div class="flex items-center gap-4">
                <span class="text-xs text-gray-400 font-bold uppercase tracking-wider hidden sm:block"></span>
                <div class="flex bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                    <?php for($i=1; $i<=$total_page_rekap; $i++): ?>
                    <a href="?tab=rekap&tgl_awal=<?= $tgl_awal ?>&tgl_akhir=<?= $tgl_akhir ?>&page_rekap=<?= $i ?>" class="px-3.5 py-1.5 text-sm <?= $i == $page_rekap ? 'bg-gray-800 text-white font-bold border-r border-gray-800 last:border-0' : 'text-gray-600 hover:bg-gray-50 border-r border-gray-200 last:border-0' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- VIEW: LAPORAN PENGELUARAN (BARU) -->
<div id="view-pengeluaran" class="tab-content hidden flex flex-col h-auto lg:h-full min-h-full">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col min-h-[600px] lg:h-full overflow-hidden">
        <div class="p-5 md:p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col xl:flex-row justify-between xl:items-center gap-4 shrink-0">
            <div>
                <h3 class="font-bold text-xl text-gray-800 tracking-tight flex items-center">
                    Pengeluaran Toko
                </h3>
                <p class="text-sm text-gray-500 mt-1 font-medium">Catat biaya operasional untuk memantau Laba Bersih bulanan.</p>
            </div>
            
            <div class="flex flex-col sm:flex-row items-end sm:items-center gap-3">
                <form method="GET" class="flex flex-wrap items-center gap-2 bg-white p-1.5 rounded-xl border border-gray-200 shadow-sm">
                    <input type="hidden" name="tab" value="pengeluaran">
                    <div class="flex items-center px-3">
                        <i class="fa-regular fa-calendar text-gray-400 mr-2 text-sm"></i>
                        <input type="date" name="tgl_awal_pengeluaran" value="<?= isset($tgl_awal_pengeluaran) ? $tgl_awal_pengeluaran : date('Y-m-01') ?>" class="text-sm outline-none bg-transparent text-gray-700 font-medium cursor-pointer">
                    </div>
                    <span class="text-gray-300">-</span>
                    <div class="flex items-center px-3">
                        <input type="date" name="tgl_akhir_pengeluaran" value="<?= isset($tgl_akhir_pengeluaran) ? $tgl_akhir_pengeluaran : date('Y-m-t') ?>" class="text-sm outline-none bg-transparent text-gray-700 font-medium cursor-pointer">
                    </div>
                    <button type="submit" class="bg-gray-800 hover:bg-gray-900 text-white px-5 py-1.5 rounded-lg text-sm transition font-semibold">Filter</button>
                </form>
                
                <button onclick="bukaModalPengeluaran()" class="w-full sm:w-auto bg-rose-600 hover:bg-rose-700 text-white px-6 py-2.5 rounded-xl text-sm shadow-sm shadow-rose-600/20 transition font-bold flex items-center justify-center shrink-0">
                    <i class="fa-solid fa-plus mr-2"></i> Catat Pengeluaran
                </button>
            </div>
        </div>
        
        <div class="flex-1 min-h-0 flex flex-col bg-white">
            <div class="bg-white border-b border-gray-100 overflow-hidden shrink-0" id="header-scroll-pengeluaran">
                <div class="pr-[6px]">
                    <table class="w-full text-left border-collapse table-fixed min-w-[700px] xl:min-w-full">
                        <colgroup>
                            <col class="w-16">
                            <col class="w-44">
                            <col class="w-48">
                            <col>
                            <col class="w-48">
                            <col class="w-24">
                        </colgroup>
                        <thead class="text-gray-400 text-xs uppercase tracking-wider bg-white">
                            <tr>
                                <th class="py-4 px-6 font-semibold text-center">No</th>
                                <th class="py-4 px-6 font-semibold">Waktu Tercatat</th>
                                <th class="py-4 px-6 font-semibold">Pencatat (Kasir)</th>
                                <th class="py-4 px-6 font-semibold">Keterangan / Keperluan</th>
                                <th class="py-4 px-6 font-semibold text-right">Nominal</th>
                                <th class="py-4 px-6 font-semibold text-center">Aksi</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>

            <div class="overflow-y-scroll overflow-x-auto flex-1 bg-white custom-scroll" onscroll="document.getElementById('header-scroll-pengeluaran').scrollLeft = this.scrollLeft">
                <table class="w-full text-left border-collapse table-fixed min-w-[700px] xl:min-w-full">
                    <colgroup>
                        <col class="w-16">
                        <col class="w-44">
                        <col class="w-48">
                        <col>
                        <col class="w-48">
                        <col class="w-24">
                    </colgroup>
                    <tbody class="divide-y divide-gray-50">
                        <?php if(isset($q_pengeluaran) && mysqli_num_rows($q_pengeluaran) > 0): ?>
                            <?php 
                            $no_p = isset($offset_pengeluaran) ? $offset_pengeluaran + 1 : 1;
                            while($p = mysqli_fetch_assoc($q_pengeluaran)): 
                            ?>
                            <tr class="hover:bg-rose-50/40 transition group bg-white">
                                <td class="py-3 px-6 text-center text-sm font-medium text-gray-500"><?= $no_p++ ?></td>
                                <td class="py-3 px-6 text-sm text-gray-500 font-medium"><?= date('d M Y, H:i', strtotime($p['tanggal'])) ?></td>
                                <td class="py-3 px-6 text-sm text-gray-600 flex items-center font-medium overflow-hidden">
                                    <div class="w-6 h-6 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-[10px] mr-2 font-black uppercase shrink-0"><?= substr($p['nama_lengkap'], 0, 1) ?></div>
                                    <span class="truncate"><?= htmlspecialchars($p['nama_lengkap']) ?></span>
                                </td>
                                <td class="py-3 px-6 text-sm font-bold text-gray-800 leading-tight">
                                    <?= htmlspecialchars($p['keterangan']) ?>
                                </td>
                                <td class="py-3 px-6 text-sm font-black text-right text-rose-600 truncate">
                                    Rp <?= number_format($p['nominal'], 0, ',', '.') ?>
                                </td>
                                <td class="py-3 px-6 text-center">
                                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                                    <button onclick="bukaModalKonfirmasi('proses_pengeluaran.php?aksi=hapus&id=<?= $p['id'] ?>', 'Yakin ingin membatalkan/menghapus catatan pengeluaran ini? Nominal akan dikembalikan ke pendapatan.')" class="w-7 h-7 rounded-lg bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition flex items-center justify-center mx-auto shrink-0" title="Hapus Data">
                                        <i class="fa-solid fa-trash-can text-[10px]"></i>
                                    </button>
                                    <?php else: ?>
                                    <span class="text-red-300"><i class="fa-solid fa-ban"></i></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="py-16 text-center text-gray-400">
                                <i class="fa-solid fa-clipboard-check text-4xl mb-3 opacity-30"></i>
                                <p class="font-medium text-sm">Tidak Ada Pengeluaran pada periode ini.</p>
                            </td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="bg-gray-50 p-5 md:p-6 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-4 shrink-0">
            <div class="text-sm text-gray-500 bg-white px-5 py-2.5 rounded-xl border border-rose-100 shadow-sm flex items-center">
                Total Biaya Pengeluaran : <span class="text-xl font-black text-rose-600 ml-3">Rp <?= number_format(isset($total_nominal_pengeluaran) ? $total_nominal_pengeluaran : 0, 0, ',', '.') ?></span>
            </div>
            
            <?php if(isset($total_page_pengeluaran) && $total_page_pengeluaran > 1): ?>
            <div class="flex bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                <?php for($i=1; $i<=$total_page_pengeluaran; $i++): ?>
                <a href="?tab=pengeluaran&tgl_awal_pengeluaran=<?= $tgl_awal_pengeluaran ?>&tgl_akhir_pengeluaran=<?= $tgl_akhir_pengeluaran ?>&page_pengeluaran=<?= $i ?>" class="px-3.5 py-1.5 text-sm <?= $i == $page_pengeluaran ? 'bg-gray-800 text-white font-bold border-r border-gray-800 last:border-0' : 'text-gray-600 hover:bg-gray-50 border-r border-gray-200 last:border-0' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- VIEW: MANAJEMEN AKUN (ADMIN ONLY) -->
<?php if($_SESSION['role'] == 'admin'): ?>
<div id="view-akun" class="tab-content hidden flex flex-col h-auto lg:h-full min-h-full">
    <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 flex flex-col min-h-[600px] lg:h-full overflow-hidden relative">
        
        <!-- Ornamen Background Halus -->
        <div class="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-bl-[100%] pointer-events-none -z-0"></div>

        <!-- HEADER AREA -->
        <div class="p-6 md:p-8 border-b border-gray-100 flex flex-col sm:flex-row justify-between sm:items-center bg-white/50 backdrop-blur-sm gap-5 shrink-0 relative z-10">
            <div class="flex items-center gap-4">
                <div>
                    <h3 class="font-bold text-xl text-gray-800 tracking-tight">Manajemen Akun</h3>
                    <p class="text-sm text-gray-500 mt-1 font-medium">Kelola akses sistem untuk Administrator dan Petugas Kasir.</p>
                </div>
            </div>
            
            <button onclick="bukaModalAkun('tambah')" class="w-full sm:w-auto bg-gray-700 hover:bg-gray-800 text-white px-6 py-2.5 rounded-xl text-sm transition-all duration-300 font-bold flex items-center justify-center shrink-0 group transform">
                <i class="fa-solid fa-user-plus mr-2 transition-transform"></i> Tambah Akun Baru
            </button>
        </div>
        
        <!-- HEADER TABEL -->
        <div class="flex-1 min-h-0 flex flex-col bg-white/80 relative z-10">
            <div class="bg-gray-50/80 border-b border-gray-100 overflow-hidden shrink-0" id="header-scroll-akun">
                <div class="pr-[6px]">
                    <table class="w-full text-left border-collapse table-fixed min-w-[700px] xl:min-w-full">
                        <colgroup>
                            <col class="w-16">
                            <col>
                            <col class="w-56">
                            <col class="w-44">
                            <col class="w-32">
                        </colgroup>
                        <thead class="text-gray-400 text-[11px] uppercase tracking-wider">
                            <tr>
                                <th class="py-4 px-6 font-semibold text-center">No</th>
                                <th class="py-4 px-6 font-semibold">Profil Pengguna</th>
                                <th class="py-4 px-6 font-semibold">Username Login</th>
                                <th class="py-4 px-6 font-semibold text-center">Hak Akses</th>
                                <th class="py-4 px-6 font-semibold text-center">Aksi</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>

            <!-- BODY TABEL -->
            <div class="overflow-y-scroll overflow-x-auto flex-1 custom-scroll" onscroll="document.getElementById('header-scroll-akun').scrollLeft = this.scrollLeft">
                <table class="w-full text-left border-collapse table-fixed min-w-[700px] xl:min-w-full">
                    <colgroup>
                        <col class="w-16">
                        <col>
                        <col class="w-56">
                        <col class="w-44">
                        <col class="w-32">
                    </colgroup>
                    <tbody class="divide-y divide-gray-50">
                        <?php if(isset($total_akun) && $total_akun > 0): ?>
                            <?php 
                            $no_akun = 1;
                            while($a = mysqli_fetch_assoc($q_semua_akun)): 
                                $is_current_user = ($a['id'] == $_SESSION['user_id']);
                                
                                // Pengaturan Tema Berdasarkan Role
                                if ($a['role'] == 'admin') {
                                    $role_bg = 'bg-indigo-50 text-indigo-600 border-indigo-100';
                                    $role_icon = 'fa-shield-halved';
                                    $role_text = 'Administrator';
                                    $avatar_bg = 'bg-gradient-to-br from-indigo-500 to-blue-600';
                                } else {
                                    $role_bg = 'bg-emerald-50 text-emerald-600 border-emerald-100';
                                    $role_icon = 'fa-cash-register';
                                    $role_text = 'Petugas Kasir';
                                    $avatar_bg = 'bg-gradient-to-br from-emerald-400 to-teal-500';
                                }
                            ?>
                            <tr class="hover:bg-indigo-50/30 transition-colors duration-200 group">
                                <td class="py-4 px-6 text-center text-sm text-gray-400 font-medium"><?= $no_akun++ ?></td>
                                <td class="py-4 px-6 overflow-hidden">
                                    <div class="flex items-center">
                                        <div class="relative mr-4 shrink-0">
                                            <div class="w-10 h-10 rounded-xl <?= $avatar_bg ?> text-white flex items-center justify-center text-sm font-black uppercase shadow-md shadow-gray-200">
                                                <?= substr($a['nama_lengkap'], 0, 1) ?>
                                            </div>
                                            <?php if($is_current_user): ?>
                                            <div class="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full" title="Sedang Online (Anda)"></div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="min-w-0">
                                            <p class="font-bold text-gray-800 text-sm truncate flex items-center">
                                                <?= htmlspecialchars($a['nama_lengkap']) ?>
                                                <?php if($is_current_user): ?>
                                                    <span class="ml-2 bg-gray-100 text-gray-500 text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider border border-gray-200 shrink-0">Anda</span>
                                                <?php endif; ?>
                                            </p>
                                            <p class="text-[11px] text-gray-400 font-medium mt-0.5 truncate">Terdaftar dalam sistem</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="inline-flex items-center text-sm font-medium text-gray-600 bg-gray-50 px-2.5 py-1 rounded-lg border border-gray-200">
                                        <span class="text-gray-400 mr-1">@</span><span class="truncate"><?= htmlspecialchars($a['username']) ?></span>
                                    </div>
                                </td>
                                <td class="py-4 px-6 text-center">
                                    <span class="inline-flex items-center px-3 py-1.5 rounded-xl text-xs font-bold <?= $role_bg ?> border">
                                        <i class="fa-solid <?= $role_icon ?> mr-1.5 opacity-80"></i> <?= $role_text ?>
                                    </span>
                                </td>
                                <td class="py-4 px-6 text-center">
                                    <div class="flex justify-center gap-2">
                                        <!-- Tombol Edit -->
                                        <button onclick='bukaModalAkun("edit", <?= json_encode($a) ?>)' class="w-9 h-9 rounded-xl bg-blue-50 text-blue-500 hover:bg-blue-600 hover:text-white transition-all duration-200 flex items-center justify-center shrink-0" title="Edit Akun">
                                            <i class="fa-solid fa-pen text-sm"></i>
                                        </button>
                                        
                                        <!-- Tombol Hapus -->
                                        <?php if(!$is_current_user): ?>
                                        <button onclick="bukaModalKonfirmasi('proses_akun.php?aksi=hapus&id=<?= $a['id'] ?>', 'PERINGATAN:<br>Apakah Anda yakin ingin menghapus akun <b><?= htmlspecialchars(addslashes($a['nama_lengkap'])) ?></b> secara permanen?')" class="w-9 h-9 rounded-xl bg-red-50 text-red-500 hover:bg-red-600 hover:text-white transition-all duration-200 flex items-center justify-center shrink-0" title="Hapus Akun">
                                            <i class="fa-solid fa-trash-can text-sm"></i>
                                        </button>
                                        <?php else: ?>
                                        <div class="w-9 h-9 rounded-xl bg-gray-50 text-gray-300 flex items-center justify-center cursor-not-allowed shrink-0 border border-gray-100" title="Tidak dapat menghapus akun yang sedang dipakai">
                                            <i class="fa-solid fa-ban text-sm"></i>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="py-20 text-center text-gray-400">
                                <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-gray-100">
                                    <i class="fa-solid fa-user-shield text-3xl opacity-30"></i>
                                </div>
                                <p class="font-bold text-gray-500 mb-1">Belum Ada Akun Pengguna</p>
                                <p class="text-xs text-gray-400">Data kasir dan administrator akan muncul di sini.</p>
                            </td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- FOOTER INFO -->
        <div class="bg-gray-50/80 p-5 md:px-8 border-t border-gray-100 flex items-center justify-between shrink-0 relative z-10">
            <div class="flex items-center gap-3">
                <div class="flex -space-x-2">
                    <div class="w-8 h-8 rounded-full bg-indigo-100 border-2 border-white flex items-center justify-center text-indigo-500 text-[10px] font-black"><i class="fa-solid fa-shield-halved"></i></div>
                    <div class="w-8 h-8 rounded-full bg-emerald-100 border-2 border-white flex items-center justify-center text-emerald-500 text-[10px] font-black"><i class="fa-solid fa-cash-register"></i></div>
                </div>
                <span class="text-sm text-gray-500 font-medium">Total <span class="font-black text-gray-800 text-base mx-1"><?= isset($total_akun) ? $total_akun : 0 ?></span> Pengguna Aktif</span>
            </div>
        </div>
        
    </div>
</div>
<?php endif; ?>

<!-- VIEW: BACKUP & RESTORE DATABASE (ADMIN ONLY) -->
<?php if($_SESSION['role'] == 'admin'): ?>
<div id="view-database" class="tab-content hidden flex flex-col h-auto min-h-full">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col flex-1 overflow-hidden">
        
        <div class="p-5 md:p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shrink-0">
            <div>
                <h3 class="font-bold text-xl text-gray-800 flex tracking-tight">
                    Manajemen Database
                </h3>
                <p class="text-sm text-gray-500 mt-1 font-medium">Amankan atau pulihkan data sistem Anda.</p>
            </div>
        </div>

        <div class="p-5 md:p-8 flex-1 bg-white overflow-y-auto custom-scroll">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-5 sm:gap-6 max-w-5xl mx-auto">
                
                <div class="relative overflow-hidden rounded-3xl border border-blue-100 shadow-md bg-gradient-to-b from-blue-50/80 to-white transition-all duration-300 group flex flex-col">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-bl-[100%] -z-0 transition-transform duration-500"></div>
                    
                    <div class="p-6 flex flex-col h-full relative z-10">
                        <div class="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center text-xl mb-4 shadow-md shadow-blue-500/30 transform transition-transform duration-300">
                            <i class="fa-solid fa-download"></i>
                        </div>
                        
                        <h4 class="text-lg font-black text-gray-800 mb-2">BACKUP DATABASE</h4>
                        <p class="text-[13px] text-gray-600 mb-4 leading-relaxed">Unduh salinan lengkap database ke perangkat Anda. Proses ini mengamankan seluruh data, termasuk:</p>
                        
                        <ul class="space-y-2 mb-5 flex-1">
                            <li class="flex items-center text-[13px] text-gray-600 font-medium">
                                <i class="fa-solid fa-circle-check text-blue-500 mr-2 text-base"></i> Data Barang & Persediaan
                            </li>
                            <li class="flex items-center text-[13px] text-gray-600 font-medium">
                                <i class="fa-solid fa-circle-check text-blue-500 mr-2 text-base"></i> Riwayat & Laporan Penjualan
                            </li>
                            <li class="flex items-center text-[13px] text-gray-600 font-medium">
                                <i class="fa-solid fa-circle-check text-blue-500 mr-2 text-base"></i> Akun Pengguna (Kasir & Admin)
                            </li>
                        </ul>
                        
                        <a href="backup_db.php" class="w-full bg-blue-600 hover:bg-blue-700 text-white text-center text-sm font-bold py-2.5 rounded-xl transition-all flex items-center justify-center mt-auto shadow-sm shadow-blue-600/20">
                            <i class="fa-solid fa-download mr-2"></i> Download Database
                        </a>
                    </div>
                </div>

                <div class="relative overflow-hidden rounded-3xl border border-orange-100 shadow-md bg-gradient-to-b from-orange-50/80 to-white transition-all duration-300 group flex flex-col">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-bl-[100%] -z-0 transition-transform duration-500"></div>
                    
                    <div class="p-6 flex flex-col h-full relative z-10">
                        <div class="flex justify-between items-start mb-4">
                            <div class="w-12 h-12 rounded-xl bg-orange-500 text-white flex items-center justify-center text-xl shadow-md shadow-orange-500/30 transform transition-transform duration-300">
                                <i class="fa-solid fa-clock-rotate-left"></i>
                            </div>
                            <span class="bg-red-50 text-red-600 border border-red-200 text-[10px] font-black px-2 py-1 rounded-lg uppercase tracking-wider animate-pulse flex items-center shadow-sm">
                                <i class="fa-solid fa-triangle-exclamation mr-1"></i> Kritis
                            </span>
                        </div>
                        
                        <h4 class="text-lg font-black text-gray-800 mb-2">RESTORE DATABASE</h4>
                        <p class="text-[13px] text-gray-600 mb-4 leading-relaxed">Pulihkan sistem menggunakan file <span class="font-mono text-orange-600 font-bold bg-orange-100 border border-orange-200 px-1 py-0.5 rounded text-[11px]">.sql</span> yang pernah Anda simpan ke komputer.</p>
                        
                        <div class="bg-red-50/80 border border-red-200 rounded-xl p-3 mb-5 text-[11px] sm:text-xs text-red-700 leading-relaxed font-medium shadow-inner flex gap-2.5 items-start flex-1">
                            <i class="fa-solid fa-circle-exclamation text-red-500 mt-0.5 text-base"></i>
                            <div>
                                <span class="font-black text-red-800 block mb-0.5 uppercase tracking-wider text-[10px]">Peringatan Hilang Data!</span>
                                Seluruh data saat ini akan dihapus dan terganti oleh isi dari file backup.
                            </div>
                        </div>
                        
                        <form id="form-restore-db" action="restore_db.php" method="POST" enctype="multipart/form-data" class="flex flex-col gap-3 mt-auto">
                            <div class="relative">
                                <input type="file" name="backup_file" id="backup_file" accept=".sql" required class="block w-full text-xs text-gray-600 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-orange-100 file:text-orange-700 hover:file:bg-orange-200 cursor-pointer bg-white border-2 border-dashed border-orange-200 hover:border-orange-400 rounded-xl transition-colors p-1.5 outline-none focus:ring-2 focus:ring-orange-500/50">
                            </div>
                            
                            <button type="button" onclick="bukaModalKonfirmasiForm('form-restore-db', 'PENTING SEKALI:<br>Apakah Anda yakin ingin memulihkan database? <br><br><span class=\'text-red-600 font-bold\'>Semua data yang ada saat ini akan terhapus secara permanen</span> dan digantikan dengan isi file SQL yang baru saja Anda unggah!')" class="w-full bg-gray-800 hover:bg-gray-900 text-white text-sm font-bold py-2.5 rounded-xl transition-all flex items-center justify-center shadow-sm shadow-gray-800/20">
                                <i class="fa-solid fa-upload mr-2"></i> Proses Restore
                            </button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- VIEW: UPDATE SISTEM (ADMIN ONLY) -->
<div id="view-update" class="tab-content hidden flex flex-col h-auto min-h-full">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col flex-1 overflow-hidden">
        
        <div class="p-5 md:p-8 flex-1 bg-gray-50/30 overflow-y-auto custom-scroll flex items-center justify-center">
            <!-- Diperlebar menjadi max-w-4xl untuk layout dua kolom (menyamping) -->
            <div class="w-full max-w-4xl">
                <div class="relative overflow-hidden rounded-[2rem] border border-emerald-100 bg-white shadow-md group transition-all duration-300">
                    <div class="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-bl-[100%] -z-0 transition-transform duration-500"></div>
                    
                    <!-- Menggunakan CSS Grid untuk membagi 2 kolom pada layar desktop -->
                    <div class="p-6 md:p-8 lg:p-10 relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
                        
                        <!-- KOLOM KIRI: Informasi & Tombol -->
                        <div class="flex flex-col items-center md:items-start text-center md:text-left">
                            <div class="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center text-3xl mb-5 shadow-sm shadow-emerald-500/30 transform transition-transform duration-300">
                                <i class="fa-solid fa-cloud-download"></i>
                            </div>
                            
                            <h4 class="text-xl md:text-2xl font-black text-gray-800 mb-3">AUTO UPDATE SYSTEM</h4>
                            <p class="text-[13px] text-gray-600 mb-4 md:mb-4 leading-relaxed max-w-sm">Sistem akan melakukan update aplikasi dari server cloud secara otomatis. Pastikan komputer Anda memiliki koneksi internet yang stabil.</p>
                            
                            <!-- Tombol Cek Update -->
                            <button type="button" id="btn-cek-update" onclick="cekUpdateAplikasi()" class="w-full px-8 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold py-3.5 rounded-xl transition-all flex items-center justify-center">
                                <i class="fa-solid fa-rotate mr-2"></i> Cek Versi Terbaru
                            </button>
                        </div>
                        
                        <!-- KOLOM KANAN: Status, Peringatan & Progress Bar -->
                        <div class="flex flex-col justify-center w-full">
                            <!-- Area Info Status -->
                            <div id="update-info-area" class="w-full bg-gray-50 border border-emerald-100 rounded-2xl p-6 flex flex-col items-center justify-center text-center transition-all duration-300 shadow-inner">
                                <i class="fa-solid fa-circle-check text-emerald-600 text-4xl mb-3"></i>
                                <p class="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Versi Aplikasi Anda Saat Ini</p>
                                <p class="text-sm font-black bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-md tracking-wider border border-emerald-200">Versi App <span class="app-version-text">...</span></p>
                            </div>
                            
                            <!-- WARNING AREA (Muncul saat ada update) -->
                            <div id="update-warning-area" class="w-full text-left bg-amber-50 border border-amber-200 rounded-xl p-4 shadow-inner hidden mt-4">
                                <h5 class="text-[11px] font-black text-amber-800 uppercase tracking-wider mb-2 flex items-center"><i class="fa-solid fa-triangle-exclamation mr-1.5 text-amber-600 text-sm"></i> Peringatan Sistem</h5>
                                <ul class="text-[11px] text-amber-700/90 font-medium space-y-1.5 list-disc pl-4 leading-relaxed">
                                    <li>Pastikan komputer anda memiliki koneksi internet yang stabil.</li>
                                    <li><b class="text-amber-900">JANGAN</b> menutup aplikasi atau mematikan komputer.</li>
                                    <li>Aplikasi akan memuat ulang (restart) otomatis setelah selesai.</li>
                                </ul>
                            </div>

                            <!-- PROGRESS BAR AREA (Muncul saat proses install) -->
                            <div id="update-progress-container" class="w-full hidden mt-4">
                                <div class="flex justify-between items-center mb-2 px-1">
                                    <span id="update-status-text" class="text-[11px] font-bold text-emerald-600 animate-pulse">Menyiapkan update...</span>
                                    <span id="update-percentage" class="text-sm font-black text-gray-800">0%</span>
                                </div>
                                <div class="w-full bg-gray-100 rounded-full h-3.5 shadow-inner overflow-hidden border border-gray-200 p-[2px]">
                                    <div id="update-progress-bar" class="bg-gradient-to-r from-emerald-400 to-emerald-600 h-full rounded-full transition-all duration-300 ease-out relative" style="width: 0%">
                                        <div class="absolute inset-0 bg-white/20 w-full h-full animate-[pulse_1s_ease-in-out_infinite]"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>